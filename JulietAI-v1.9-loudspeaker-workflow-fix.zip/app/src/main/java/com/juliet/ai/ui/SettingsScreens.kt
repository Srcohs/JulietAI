package com.juliet.ai.ui

import android.Manifest
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.media.projection.MediaProjectionManager
import android.app.Activity
import com.juliet.ai.screen.JulietScreenCaptureService
import com.juliet.ai.screen.ScreenShareBridge
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.juliet.ai.R
import com.juliet.ai.data.*
import com.juliet.ai.vm.JulietViewModel

@Composable
fun SettingsScreen(vm: JulietViewModel) = Page("Settings", null) {
    Group {
        Item("👤", "Profile", vm.s("name")) { vm.navigate(Screen.Profile) }
        Item("🎨", "Look & feel", "Theme, orb, motion") { vm.navigate(Screen.Look) }
        Item("🗣", "Voice & language", "Voice, personality, model") { vm.navigate(Screen.Voice) }
        Item("📱", "Phone control", "Quick actions and access") { vm.navigate(Screen.Phone) }
        Item("🧠", "Memory & Knowledge", "Add information Juliet can use") { vm.navigate(Screen.Knowledge) }
        Item("🔔", "Voice announcements", "Speak app notifications with sender names") { vm.navigate(Screen.Announcements) }
        Item("🎨", "Image & sketch generator", "Create an image using Gemini") { vm.navigate(Screen.ImageTools) }
        Item("📺", "Live screen sharing", "Share screen frames with Gemini Live by consent") { vm.navigate(Screen.ScreenShare) }
        Item("🔑", "Connections", "Gemini and Groq keys") { vm.navigate(Screen.Conn) }
        Item("🛡", "Privacy & data", "What Juliet stores") { vm.navigate(Screen.Privacy) }
        Item("ℹ", "About Juliet", "Version 1.7") { vm.navigate(Screen.About) }
    }
}

@Composable
fun LookScreen(vm: JulietViewModel) = Page("Look & feel", { vm.back() }) {
    Group {
        Item("🎨", "Theme", vm.s("theme")) { vm.cycle("theme", listOf("System", "Light", "Dark")) }
        Item("✦", "Orb style", ORBS[vm.s("orb").toIntOrNull() ?: 0].name) { vm.navigate(Screen.Orb) }
        ToggleItem("♿", "Reduce motion", "Calmer screens with fewer animations", vm.s("reduce") == "1") { vm.set("reduce", if (it) "1" else "0") }
    }
}

@Composable
fun VoiceScreen(vm: JulietViewModel) = Page("Voice & language", { vm.back() }) {
    val p = LocalPal.current
    var dlg by remember { mutableStateOf(false) }
    Group {
        Item("✦", "Assistant name", "Juliet", trailing = {})
        Item("☺", "Personality", vm.s("personality")) { vm.cycle("personality", listOf("Normal", "Friendly", "Playful", "Calm", "Professional")) }
        Item("🌐", "Language", vm.s("language")) { vm.cycle("language", listOf("Auto", "English", "Hindi", "Urdu", "Hinglish")) }
        Item("☰", "Response style", vm.s("style")) { vm.cycle("style", listOf("Balanced", "Short", "Detailed")) }
    }
    Sec("HOW SHE SOUNDS")
    Group {
        Item("🗣", "Voice", vm.s("voice")) { vm.cycle("voice", listOf("Kore", "Aoede", "Puck", "Charon", "Fenrir", "Leda", "Orus", "Zephyr")) }
        Item("✦", "Voice model", vm.s("model")) { dlg = true }
        ToggleItem("🔊", "Use loudspeaker", "Play Juliet's live voice through the phone's main speaker instead of the ear receiver", vm.speakerEnabled()) { vm.setLoudspeaker(it) }
        Column(Modifier.fillMaxWidth().padding(12.dp)) {
            Text("🔊  Juliet voice volume", color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Slider(value = (vm.s("volume").toFloatOrNull() ?: 80f) / 100f, onValueChange = { vm.setVoiceVolume(it) }, valueRange = 0f..1f)
            Text("${vm.s("volume")}% · controls Juliet's live voice playback volume", color = p.mu, fontSize = 12.sp)
        }
    }
    Sec("LISTENING")
    Group { ToggleItem("🎙", "Listen when the app opens", "Starts listening as soon as you open Juliet", vm.s("listen") == "1") { vm.set("listen", if (it) "1" else "0") } }
    if (dlg) AlertDialog(
        onDismissRequest = { dlg = false },
        title = { Text("Voice model") },
        text = {
            Column {
                // Model ids change often. Check ai.google.dev for the current Live API model names.
                listOf("gemini-3.8-live", "gemini-3.8-live-extended-thinking", "gemini-3.1-flash-live-preview", "gemini-2.5-flash-native-audio-preview-12-2025").forEach { m ->
                    TextButton(onClick = { vm.set("model", m); dlg = false }) {
                        Text((if (vm.s("model") == m) "✓ " else "") + m, fontSize = 14.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { dlg = false }) { Text("Close", color = J.Gold) } }
    )
}

@Composable
fun PhoneScreen(vm: JulietViewModel) = Page("Phone control", { vm.back() }) {
    Group {
        Item("✦", "Quick actions", "Set up the tools Juliet can run") { vm.navigate(Screen.Quick) }
        Item("🔒", "App permissions", "Microphone, contacts, calls") { vm.navigate(Screen.Perm) }
    }
}

@Composable
fun QuickScreen(vm: JulietViewModel, onMic: () -> Unit) = Page("Phone control", { vm.back() }) {
    val p = LocalPal.current
    Sub("Tap one to start. Say it the way you would to a friend - Hindi, Urdu, English or both.")
    class Q(val icon: String, val title: String, val sub: String, val example: Boolean, val act: () -> Unit)
    val items = listOf(
        Q("▦", "Open an app", "YouTube kholo", true) { vm.draft = "YouTube kholo"; vm.navigate(Screen.Chat) },
        Q("📞", "Call someone", "Mummy ko call karo", true) { vm.draft = "Mummy ko call karo"; vm.navigate(Screen.Chat) },
        Q("💬", "Send a message", "Papa ko WhatsApp karo", true) { vm.draft = "Papa ko WhatsApp karo"; vm.navigate(Screen.Chat) },
        Q("🌐", "Build a website", "ek cafe ki website banao", true) { vm.draft = "ek cafe ki website banao"; vm.navigate(Screen.Chat) },
        Q("✏", "Sketch a photo", "drawing banao", true) { vm.draft = "drawing banao"; vm.navigate(Screen.Chat) },
        Q("🎙", "Talk to Juliet", "Start a voice conversation", false) { vm.navigate(Screen.Home); onMic() },
        Q("💭", "Ask anything", "Start a text conversation", false) { vm.navigate(Screen.Chat) },
        Q("🔒", "App permissions", "Access configuration", false) { vm.navigate(Screen.Perm) }
    )
    items.chunked(2).forEach { row ->
        Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            row.forEach { q ->
                val sh = RoundedCornerShape(28.dp)
                Column(Modifier.weight(1f).heightIn(min = 150.dp).clip(sh).background(p.card).border(1.dp, p.border, sh).clickable(onClick = q.act).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    TileIcon(q.icon, 52)
                    Text(q.title, color = p.text, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                    Text(if (q.example) "\"${q.sub}\"" else q.sub, color = p.mu, fontSize = 15.sp)
                }
            }
            if (row.size == 1) Spacer(Modifier.weight(1f))
        }
    }
}

@Composable
fun PermScreen(vm: JulietViewModel, askPerm: (String, (Boolean) -> Unit) -> Unit) = Page("Permissions", { vm.back() }) {
    val ctx = LocalContext.current
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.permTick++ }
    vm.permTick
    fun ok(perm: String) = ContextCompat.checkSelfPermission(ctx, perm) == android.content.pm.PackageManager.PERMISSION_GRANTED
    Sub("Allow only what you want Juliet to use. You can change any of these later.")
    @Composable fun row(icon: String, title: String, sub: String, perm: String) {
        val on = ok(perm)
        Item(icon, title, sub, trailing = {
            val bg = if (on) J.Ok.copy(alpha = .15f) else LocalPal.current.card2
            Text(if (on) "Allowed" else "Allow", color = if (on) J.Ok else J.Red, fontSize = 15.sp,
                modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(bg).padding(horizontal = 14.dp, vertical = 8.dp))
            Chevron()
        }, onClick = { if (!on) askPerm(perm) { vm.permTick++ } })
    }
    Group {
        row("🎙", "Microphone", "Needed for voice conversations", Manifest.permission.RECORD_AUDIO)
        row("👤", "Contacts", "Lets Juliet find a number when you say a name", Manifest.permission.READ_CONTACTS)
        row("📞", "Phone Calls", "Juliet can place calls directly", Manifest.permission.CALL_PHONE)
        val nOk = Build.VERSION.SDK_INT < 33 || ok(Manifest.permission.POST_NOTIFICATIONS)
        Item("🔔", "Notifications", "Reminders and alerts from Juliet", trailing = {
            Text(if (nOk) "Allowed" else "Open Settings", color = if (nOk) J.Ok else J.Red, fontSize = 15.sp,
                modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(if (nOk) J.Ok.copy(alpha = .15f) else LocalPal.current.card2).padding(horizontal = 14.dp, vertical = 8.dp))
            Chevron()
        }, onClick = {
            ctx.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        })
    }
}

@Composable
private fun KeyCard(title: String, status: String, desc: String, hint: String, save: String, link: String, url: String, onSave: (String) -> Unit) {
    val p = LocalPal.current
    val uri = LocalUriHandler.current
    var v by remember { mutableStateOf("") }
    val sh = RoundedCornerShape(26.dp)
    Column(Modifier.fillMaxWidth().padding(bottom = 16.dp).clip(sh).background(p.card).border(1.dp, p.border, sh).padding(18.dp)) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text(title, color = p.text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Text(status, color = if (status.startsWith("✔")) J.Ok else p.mu, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        }
        Text(desc, color = p.mu, fontSize = 16.sp, modifier = Modifier.padding(top = 6.dp, bottom = 14.dp))
        OutlinedTextField(v, { v = it }, Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation(),
            placeholder = { Text(hint, color = p.mu) }, shape = RoundedCornerShape(26.dp),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = J.Red, unfocusedBorderColor = p.border, cursorColor = J.Crim, focusedTextColor = p.text, unfocusedTextColor = p.text))
        Spacer(Modifier.height(14.dp))
        GradientButton(save, Modifier.fillMaxWidth()) { if (v.isNotBlank()) { onSave(v); v = "" } }
        Text("$link ↗", color = J.Crim, fontSize = 17.sp, modifier = Modifier.padding(top = 14.dp).clickable { uri.openUri(url) })
    }
}

@Composable
fun ConnScreen(vm: JulietViewModel) = Page("Connections", { vm.back() }) {
    Sub("Juliet talks and chats through your own keys. They are stored only on this phone.")
    KeyCard("Voice - Gemini key", vm.geminiStatus(), "Powers live voice conversations.", "Paste your Gemini API key", "Save Gemini key",
        "Get a free key at Google AI Studio", "https://aistudio.google.com/apikey") { vm.saveGemini(it) }
    KeyCard("Chat - Groq keys", vm.groqStatus(), "Fast typed replies. Add several keys, separated by commas - they take turns if one is rate limited.",
        "gsk_..., gsk_...", "Save Groq keys", "Get a free key at Groq", "https://console.groq.com/keys") { vm.saveGroq(it) }
}

@Composable
fun PrivacyScreen(vm: JulietViewModel) = Page("Privacy & data", { vm.back() }) {
    var confirm by remember { mutableStateOf(false) }
    Sub("Juliet has no account and no server. Your keys, chats and settings are stored encrypted on this phone only. Ahsan Raza never receives your data.")
    Group {
        Item("☰", "What Juliet stores", "Chats, settings and keys, encrypted on this phone", trailing = {})
        Item("🌐", "Where your messages go", "Voice goes to Google Gemini and typed chat to Groq, using your own keys. Contact numbers never leave this phone.", trailing = {})
        Item("⚠", "Free Gemini keys", "Google may use data sent with a free-tier key to improve its products. For stricter privacy use a Gemini key with billing enabled.", trailing = {})
        Item("🔒", "Permissions", "What Juliet can use on this phone") { vm.navigate(Screen.Perm) }
    }
    Sec("RESET")
    Group { Item("🗑", "Clear all app data", "Erases everything Juliet stored here and restarts it") { confirm = true } }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false }, title = { Text("Clear all app data?") },
        text = { Text("This deletes your keys, chats and settings from this phone.") },
        confirmButton = { TextButton(onClick = { confirm = false; vm.clearAll() }) { Text("Clear", color = J.Red) } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } }
    )
}

@Composable
fun ProfileScreen(vm: JulietViewModel) = Page("Profile", { vm.back() }) {
    val p = LocalPal.current
    Image(painterResource(R.drawable.juliet_emblem), "JULIET AI", Modifier.align(Alignment.CenterHorizontally).padding(top = 10.dp).size(124.dp).clip(CircleShape).border(2.dp, p.border, CircleShape), contentScale = ContentScale.Crop)
    Text(vm.s("name"), color = p.text, fontSize = 40.sp, fontFamily = FontFamily.Serif, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp))
    Sec("YOU")
    Group {
        Item("✎", "Your name", vm.s("name"), trailing = {})
        Item("🛡", "Privacy controls") { vm.navigate(Screen.Privacy) }
    }
    Sec("YOUR ASSISTANT")
    Group {
        Item("✦", "Name", "Juliet", trailing = {})
        Item("☺", "Personality", vm.s("personality")) { vm.navigate(Screen.Voice) }
        Item("🌐", "Language", vm.s("language"), trailing = {})
        Item("🗣", "Voice", vm.s("voice"), trailing = {})
    }
}

@Composable
fun OrbScreen(vm: JulietViewModel) = Page("Orb style", { vm.back() }) {
    val p = LocalPal.current
    val cur = vm.s("orb").toIntOrNull() ?: 0
    var mode by remember { mutableIntStateOf(0) }
    val reduce = vm.s("reduce") == "1"
    val sh = RoundedCornerShape(30.dp)
    Column(Modifier.fillMaxWidth().padding(bottom = 16.dp).clip(sh).background(p.card).border(1.dp, p.border, sh).padding(vertical = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        JOrb(cur, Modifier.size(240.dp), mode, !reduce)
        Text(ORBS[cur].name, color = p.text, fontSize = 40.sp, fontFamily = FontFamily.Serif)
        Text(ORBS[cur].sub, color = p.mu, fontSize = 18.sp)
        Row(Modifier.padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("Idle", "Listening", "Speaking").forEachIndexed { i, s ->
                Text(s, color = if (mode == i) Color.White else p.mu, fontSize = 18.sp,
                    modifier = Modifier.clip(RoundedCornerShape(30.dp)).background(if (mode == i) J.Red else p.card2).clickable { mode = i }.padding(horizontal = 20.dp, vertical = 12.dp))
            }
        }
    }
    ORBS.chunked(2).forEachIndexed { r, pair ->
        Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            pair.forEachIndexed { c, o ->
                val i = r * 2 + c; val sel = i == cur; val s2 = RoundedCornerShape(28.dp)
                Column(Modifier.weight(1f).clip(s2).background(p.card).border(if (sel) 2.dp else 1.dp, if (sel) J.Red else p.border, s2)
                    .clickable { vm.set("orb", i.toString()) }.padding(vertical = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    JOrb(i, Modifier.size(96.dp), 0, false)
                    Text(o.name + if (sel) " ✓" else "", color = if (sel) J.Red else p.text, fontSize = 21.sp)
                    Text(o.sub, color = p.mu, fontSize = 16.sp)
                }
            }
        }
    }
}

// Put your real links here. Empty means "not added yet".
private val LINKS = mapOf(
    "YouTube" to "https://youtube.com/@baloch0.5?si=HAm6wVkdKr4dv5sq",
    "Facebook" to "https://www.facebook.com/share/1DwDaEXN97/"
)

@Composable
fun AboutScreen(vm: JulietViewModel) = Page("About Juliet", { vm.back() }) {
    val p = LocalPal.current
    val uri = LocalUriHandler.current
    fun open(n: String) { val u = LINKS[n].orEmpty(); if (u.isBlank()) vm.toast = "Add your $n link in AboutScreen" else uri.openUri(u) }
    Image(painterResource(R.drawable.juliet_logo), "JULIET AI logo", Modifier.fillMaxWidth().padding(bottom = 16.dp).clip(RoundedCornerShape(28.dp)), contentScale = ContentScale.FillWidth)
    Group {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Image(painterResource(R.drawable.juliet_emblem), null, Modifier.size(64.dp).clip(RoundedCornerShape(19.dp)).border(1.dp, p.border, RoundedCornerShape(19.dp)), contentScale = ContentScale.Crop)
            Column {
                Text("JULIET AI", color = p.text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                Text("Your Personal AI Assistant · Smart · Fast · Always With You", color = p.mu, fontSize = 14.sp, lineHeight = 18.sp)
                Text("Version 1.7", color = p.text, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp).border(1.dp, J.Red, RoundedCornerShape(20.dp)).padding(horizontal = 12.dp, vertical = 2.dp))
            }
        }
    }
    Sub("Juliet AI is a voice-first AI assistant designed to make your daily life easier. Talk or type to chat, ask questions, open apps, call and message your contacts, build websites and sketch your photos — all in one place.")
    Sec("DEVELOPER")
    Group {
        Item("👥", "Ahsan Raza", "Developer & Creator of JULIET AI", trailing = {})
        Item("👤", "Ahsan Raza", "Co-Founder of JULIET AI", trailing = {})
        Item("🎓", "Computer Science Student", "Passionate about AI and Software Development", trailing = {})
        Item("📍", "From Lahore, Pakistan", "Turning ideas into real AI solutions", trailing = {})
    }
    Sec("CONNECT WITH ME")
    Row(Modifier.fillMaxWidth().padding(bottom = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("▶️" to "YouTube", "📘" to "Facebook").forEach { (e, n) ->
            val sh = RoundedCornerShape(22.dp)
            Column(Modifier.weight(1f).clip(sh).background(p.card).border(1.dp, p.border, sh).clickable { open(n) }.padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(e, fontSize = 28.sp); Text(n, color = p.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold); Text("Ahsan Raza", color = p.mu, fontSize = 11.sp)
            }
        }
    }
    Sec("APP INFO")
    Group {
        Item("📦", "App Version", null, trailing = { Text("1.7", color = p.mu, fontSize = 18.sp) })
        Item("🛡", "Privacy Policy") { vm.navigate(Screen.Privacy) }
    }
    PersonCard("CEO", { Image(painterResource(R.drawable.ahsan), "Ahsan Raza", Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }, "Ahsan Raza", "@ahsanraza",
        "I build Juliet AI — a voice-first AI assistant that lives on your phone, talks like a person, and helps you get things done hands-free. Thank you for using it. Your feedback shapes what I build next.", true) { open(it) }
    PersonCard("ROMEO", { Image(painterResource(R.drawable.romeo), "Romeo", Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }, "Romeo", "Featured Companion & Experience Strategist",
        "As co-creator of Juliet AI, I help shape the product vision and experience behind it — so Juliet keeps getting smarter, simpler, and more useful for everyone.", false) { open(it) }
}

@Composable
private fun PersonCard(label: String, photo: @Composable BoxScope.() -> Unit, name: String, handle: String, quote: String, links: Boolean, open: (String) -> Unit) {
    val p = LocalPal.current
    val sh = RoundedCornerShape(30.dp)
    Column(Modifier.fillMaxWidth().padding(bottom = 16.dp).clip(sh).background(Brush.verticalGradient(listOf(J.Red.copy(alpha = .12f), p.card)))
        .border(1.dp, p.border, sh).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = J.Red, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 3.sp)
        Spacer(Modifier.height(12.dp))
        Box(Modifier.size(170.dp).clip(CircleShape).border(3.dp, J.Red, CircleShape).background(Color(0xFF1B0610)), Alignment.Center, content = photo)
        Text(name, color = p.text, fontSize = 38.sp, fontFamily = FontFamily.Serif, modifier = Modifier.padding(top = 14.dp))
        Text(handle, color = J.Crim, fontSize = 20.sp, fontFamily = FontFamily.Cursive, textAlign = TextAlign.Center)
        Text(quote, color = p.mu, fontSize = 17.sp, lineHeight = 25.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(vertical = 14.dp))
        if (links) Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("Facebook", "YouTube").forEach { n ->
                Text(n, color = p.text, fontSize = 18.sp, modifier = Modifier.clip(RoundedCornerShape(30.dp)).border(1.dp, J.Red, RoundedCornerShape(30.dp)).clickable { open(n) }.padding(horizontal = 20.dp, vertical = 12.dp))
            }
        }
    }
}


@Composable
fun KnowledgeScreen(vm: JulietViewModel) = Page("Memory & Knowledge", { vm.back() }) {
    val p = LocalPal.current
    var info by remember { mutableStateOf(vm.s("custom_knowledge")) }
    var note by remember { mutableStateOf(vm.s("saved_note")) }
    var code by remember { mutableStateOf(vm.s("saved_code")) }
    Sub("Add facts, preferences, contacts context, or instructions in plain text. Juliet will include this information when answering relevant questions.")
    Group {
        Text("CUSTOM KNOWLEDGE", color = J.Red, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(value = info, onValueChange = { info = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 140.dp), placeholder = { Text("Example: My work hours are 9:30 AM to 5:00 PM…") }, minLines = 5)
        GradientButton("Save Knowledge", Modifier.fillMaxWidth()) { vm.set("custom_knowledge", info.trim()); vm.toast = "Knowledge saved on this phone" }
        Text("Knowledge is added to Juliet's typed-chat instructions. Do not enter passwords, OTPs, or banking PINs.", color = p.mu, fontSize = 13.sp)
    }
    Sec("QUICK NOTES")
    Group {
        OutlinedTextField(value = note, onValueChange = { note = it }, modifier = Modifier.fillMaxWidth(), minLines = 3, placeholder = { Text("Write a note…") })
        GradientButton("Save Note", Modifier.fillMaxWidth()) { vm.set("saved_note", note); vm.toast = "Note saved locally" }
    }
    Sec("CODE / DRAFT PAD")
    Group {
        OutlinedTextField(value = code, onValueChange = { code = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 160.dp), minLines = 6, placeholder = { Text("Write or paste code and drafts here…") })
        GradientButton("Save Draft", Modifier.fillMaxWidth()) { vm.set("saved_code", code); vm.toast = "Draft saved locally" }
        Text("For live AI writing, code generation, and explanations, use Juliet Chat. Copy the result into this pad to save it.", color = p.mu, fontSize = 13.sp)
    }
}


@Composable
fun AnnouncementsScreen(vm: JulietViewModel) = Page("Voice announcements", { vm.back() }) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("juliet_announce", android.content.Context.MODE_PRIVATE) }
    var enabled by remember { mutableStateOf(prefs.getBoolean("enabled", false)) }
    var readContent by remember { mutableStateOf(prefs.getBoolean("read_content", false)) }
    var autoReply by remember { mutableStateOf(prefs.getBoolean("auto_reply_enabled", false)) }
    Sub("Juliet can speak supported Android notifications aloud. Auto-reply is a separate opt-in and only processes WhatsApp notifications with verifiable one-to-one MessagingStyle metadata. If Android does not expose reliable chat-type metadata, Juliet ignores the message.")
    Group {
        ToggleItem("🔔", "Voice announcements", "Announce supported notifications", enabled) { enabled = it; prefs.edit().putBoolean("enabled", it).apply(); vm.toast = if (it) "Announcements enabled; grant notification access below" else "Announcements disabled" }
        ToggleItem("💬", "Read notification content", "May speak the available notification preview aloud", readContent) { readContent = it; prefs.edit().putBoolean("read_content", it).apply() }
        ToggleItem("↩️", "WhatsApp private-chat auto-reply", "Experimental: requires notification access, a Groq key, and a supported Reply action. Group/channel or unverified chats are ignored.", autoReply) { autoReply = it; prefs.edit().putBoolean("auto_reply_enabled", it).apply(); vm.toast = if (it) "Auto-reply enabled; only verified private chats are eligible" else "WhatsApp auto-reply disabled" }
        Item("🔐", "Grant notification access", "Open Android system settings") {
            try { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { vm.toast = "Open Android Settings > Special app access > Notification access" }
        }
        Item("🔊", "Test announcement", "Use Juliet's speech engine") { vm.speak("Juliet voice announcements are ready."); vm.toast = "Testing voice announcement" }
    }
    Sub("Privacy and limitations: Android notification access is required. Eligible private-message text is sent to Groq for reply generation when auto-reply is enabled. Group/channel and unverifiable chat types fail closed before AI processing. Android/WhatsApp may not expose enough metadata or a Reply action; those messages are ignored. A successful reply is not guaranteed.")
}


@Composable
fun ImageToolsScreen(vm: JulietViewModel) = Page("Image & sketch generator", { vm.back() }) {
    val p = LocalPal.current
    val ctx = LocalContext.current
    var prompt by remember { mutableStateOf("") }
    var source by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    val picker = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { uri ->
        source = try { uri?.let { ctx.contentResolver.openInputStream(it)?.use { stream -> android.graphics.BitmapFactory.decodeStream(stream) } } } catch (_: Exception) { null }
        if (uri != null && source == null) vm.toast = "Could not read the selected image"
    }
    Sub("Generate original images or transform a selected photo into a sketch. Juliet uses your Gemini API key. Image output requires a Gemini model with image generation access and may require billing.")
    Group {
        OutlinedTextField(value = prompt, onValueChange = { prompt = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp), minLines = 4, placeholder = { Text("Example: turn this photo into a realistic pencil sketch with soft shading…") })
        OutlinedButton(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) { Text(if (source == null) "Choose photo for editing / sketch" else "Choose a different photo") }
        source?.let { Image(bitmap = it.asImageBitmap(), contentDescription = "Selected source photo", modifier = Modifier.fillMaxWidth().heightIn(max = 280.dp).clip(RoundedCornerShape(18.dp)), contentScale = ContentScale.Fit) }
        GradientButton(if (vm.imageBusy) "Generating…" else if (source == null) "Generate image / sketch" else "Transform photo", Modifier.fillMaxWidth()) { vm.generateImage(prompt, source) }
        if (vm.imageBusy) { CircularProgressIndicator(color = J.Red, modifier = Modifier.align(Alignment.CenterHorizontally)) }
        vm.generatedImage?.let { bitmap ->
            Image(bitmap = bitmap.asImageBitmap(), contentDescription = "Generated image", modifier = Modifier.fillMaxWidth().heightIn(max = 460.dp).clip(RoundedCornerShape(18.dp)), contentScale = ContentScale.Fit)
            Text("Generated image is held in memory for this session; it is not automatically published or saved to your gallery.", color = p.mu, fontSize = 12.sp)
        }
    }
}

@Composable
fun ScreenShareScreen(vm: JulietViewModel) = Page("Live screen sharing", { vm.back() }) {
    val ctx = LocalContext.current
    val p = LocalPal.current
    var active by remember { mutableStateOf(ScreenShareBridge.active) }
    val projectionManager = remember { ctx.getSystemService(android.content.Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager }
    val captureLauncher = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val svc = Intent(ctx, JulietScreenCaptureService::class.java).apply {
                action = JulietScreenCaptureService.ACTION_START
                putExtra(JulietScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(JulietScreenCaptureService.EXTRA_DATA, result.data)
            }
            androidx.core.content.ContextCompat.startForegroundService(ctx, svc)
            active = true
            vm.toast = if (vm.live.state.value == com.juliet.ai.data.VoiceState.Idle) "Screen capture started; start Gemini Live voice to send frames" else "Screen sharing started"
        } else { active = false; vm.toast = "Screen sharing permission was not granted" }
    }
    Sub("Android will show a system consent dialog. While sharing, downsampled screenshots are sent in memory to the active Gemini Live session about once per second. Do not share passwords, private messages, banking screens, or other sensitive content. Screen sharing does not allow Juliet to tap or control other apps.")
    Group {
        Text(if (active) "Screen capture: ACTIVE" else "Screen capture: OFF", color = if (active) J.Red else p.text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Text(if (vm.live.state.value == com.juliet.ai.data.VoiceState.Idle) "Gemini Live voice is not connected. Start voice chat first if you want Juliet to receive frames." else "Gemini Live voice is active; eligible screen frames can be forwarded.", color = p.mu, fontSize = 13.sp)
        GradientButton("Start screen sharing", Modifier.fillMaxWidth()) { captureLauncher.launch(projectionManager.createScreenCaptureIntent()) }
        OutlinedButton(onClick = { ctx.startService(Intent(ctx, JulietScreenCaptureService::class.java).setAction(JulietScreenCaptureService.ACTION_STOP)); active = false }, modifier = Modifier.fillMaxWidth()) { Text("Stop screen sharing") }
    }
}
