package com.juliet.ai.screen

/** In-process bridge: frames are forwarded only while the user has explicitly started screen capture. */
object ScreenShareBridge {
    @Volatile var onFrame: ((ByteArray) -> Unit)? = null
    @Volatile var active: Boolean = false
    fun publish(jpeg: ByteArray) { if (active) onFrame?.invoke(jpeg) }
}
