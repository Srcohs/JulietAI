package com.juliet.ai.phone

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract.CommonDataKinds.Phone
import org.json.JSONArray
import org.json.JSONObject

/** Real device actions. Used by typed commands (route) and by Gemini voice tool calls (execute). */
class PhoneActions(private val ctx: Context) {
    private val known = mapOf(
        "youtube" to "com.google.android.youtube", "whatsapp" to "com.whatsapp",
        "instagram" to "com.instagram.android", "telegram" to "org.telegram.messenger",
        "chrome" to "com.android.chrome", "gmail" to "com.google.android.gm",
        "maps" to "com.google.android.apps.maps", "spotify" to "com.spotify.music",
        "facebook" to "com.facebook.katana", "play store" to "com.android.vending"
    )

    private fun granted(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun start(i: Intent) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i) }

    fun openApp(name: String): String {
        val n = name.lowercase().trim().removeSuffix(" app")
        if (n.isEmpty()) return "Which app should I open?"
        val pm = ctx.packageManager
        var pkg = known.entries.firstOrNull { n.contains(it.key) }?.value
        if (pkg == null || pm.getLaunchIntentForPackage(pkg) == null) {
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pkg = pm.queryIntentActivities(main, 0)
                .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) }?.activityInfo?.packageName
        }
        val intent = pkg?.let { pm.getLaunchIntentForPackage(it) } ?: return "I couldn't find an app called $name."
        start(intent)
        return "Opening $name."
    }

    private fun findNumber(name: String): String? {
        if (!granted(Manifest.permission.READ_CONTACTS)) return null
        val c = ctx.contentResolver.query(
            Phone.CONTENT_URI, arrayOf(Phone.NUMBER),
            "${Phone.DISPLAY_NAME} LIKE ?", arrayOf("%${name.trim()}%"), null
        ) ?: return null
        return c.use { if (it.moveToFirst()) it.getString(0) else null }
    }

    fun call(name: String): String {
        if (!granted(Manifest.permission.READ_CONTACTS)) return "I need Contacts permission to find $name."
        val num = findNumber(name) ?: return "I couldn't find $name in your contacts."
        val action = if (granted(Manifest.permission.CALL_PHONE)) Intent.ACTION_CALL else Intent.ACTION_DIAL
        start(Intent(action, Uri.parse("tel:" + Uri.encode(num))))
        return "Calling $name."
    }

    fun whatsapp(name: String, message: String): String {
        val raw = findNumber(name)?.trim()
        val intl = raw != null && raw.startsWith("+")
        val intent = if (intl) {
            Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${raw!!.filter { it.isDigit() }}?text=${Uri.encode(message)}"))
        } else {
            Intent(Intent.ACTION_SEND).setType("text/plain").setPackage("com.whatsapp").putExtra(Intent.EXTRA_TEXT, message)
        }
        return try {
            start(intent)
            if (intl) "Opening WhatsApp chat with $name." else "Opening WhatsApp. Pick $name to send your message."
        } catch (e: Exception) { "WhatsApp isn't available on this phone." }
    }

    /** Typed commands in English / Hinglish. Returns null when the text is not a phone command. */
    fun route(text: String): String? {
        val t = text.lowercase().trim().trimEnd('.', '!')
        Regex("^(?:open|launch)\\s+(.+)$").find(t)?.let { return openApp(it.groupValues[1]) }
        Regex("^(.+?)\\s+(?:kholo|khol do|kholdo|open karo|chalu karo)$").find(t)?.let { return openApp(it.groupValues[1]) }
        Regex("^call\\s+(.+)$").find(t)?.let { return call(it.groupValues[1]) }
        Regex("^(.+?)\\s+ko\\s+call(?:\\s+(?:karo|kro|kar do))?$").find(t)?.let { return call(it.groupValues[1]) }
        Regex("^(.+?)\\s+ko\\s+whatsapp(?:\\s+(?:karo|kro))?\\s*(.*)$").find(t)?.let { return whatsapp(it.groupValues[1], it.groupValues[2]) }
        return null
    }

    // ---- Gemini Live tool calling ----
    fun execute(name: String, a: JSONObject): String = when (name) {
        "open_app" -> openApp(a.optString("app_name"))
        "call_contact" -> call(a.optString("name"))
        "send_whatsapp" -> whatsapp(a.optString("name"), a.optString("message"))
        else -> "Unknown action $name"
    }

    private fun fn(name: String, desc: String, params: Map<String, String>) = JSONObject()
        .put("name", name).put("description", desc)
        .put("parameters", JSONObject().put("type", "OBJECT")
            .put("properties", JSONObject().also { p ->
                params.forEach { (k, v) -> p.put(k, JSONObject().put("type", "STRING").put("description", v)) }
            })
            .put("required", JSONArray(params.keys.toList())))

    fun declarations(): JSONArray = JSONArray()
        .put(fn("open_app", "Open an app installed on the phone", mapOf("app_name" to "App name, e.g. YouTube")))
        .put(fn("call_contact", "Call a saved contact by name", mapOf("name" to "Contact name")))
        .put(fn("send_whatsapp", "Open WhatsApp with a message for a contact", mapOf("name" to "Contact name", "message" to "Message text")))
}
