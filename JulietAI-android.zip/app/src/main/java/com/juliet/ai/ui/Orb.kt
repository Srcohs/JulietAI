package com.juliet.ai.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer

class OrbDef(val name: String, val sub: String, val glow: Color)

val ORBS = listOf(
    OrbDef("Classic", "Crimson nebula", Color(0xFFFF1E46)),
    OrbDef("Galaxy", "Spiral of stars", Color(0xFFFF3366)),
    OrbDef("Solar", "A burning sun", Color(0xFFFF7A1E)),
    OrbDef("Crystal", "Cut ruby gem", Color(0xFFFF3366)),
    OrbDef("Ocean", "Rolling water", Color(0xFFFF3366)),
    OrbDef("Lava", "Molten rock", Color(0xFFFF4A1E))
)

private fun DrawScope.drawOrb(i: Int, c: Offset, r: Float) {
    val hi = Offset(c.x - r * .32f, c.y - r * .42f)
    fun rad(vararg s: Pair<Float, Color>) = Brush.radialGradient(*s, center = hi, radius = r * 1.5f)
    when (i) {
        0 -> drawCircle(rad(0f to Color.White, .08f to Color(0xFFFFB3C1), .28f to Color(0xFFFF3366), .6f to Color(0xFFC10F33), 1f to Color(0xFF4A0412)), r, c)
        1 -> {
            drawCircle(Brush.radialGradient(0f to Color(0xFF6B0719), .7f to Color(0xFF0B0508), 1f to Color(0xFF0B0508), center = c, radius = r), r, c)
            drawCircle(Brush.sweepGradient(0f to Color.Transparent, .25f to Color(0xB3FF3366), .5f to Color.Transparent, .75f to Color(0x99FFAABE), 1f to Color.Transparent, center = c), r * .92f, c)
            listOf(.3f to .2f, .7f to .3f, .5f to .6f, .25f to .7f, .78f to .72f, .55f to .15f, .15f to .45f, .88f to .5f).forEach { (x, y) ->
                drawCircle(Color.White.copy(alpha = .8f), r * .02f, Offset(c.x - r + x * 2 * r, c.y - r + y * 2 * r))
            }
        }
        2 -> drawCircle(rad(0f to Color(0xFFFFE08A), .3f to Color(0xFFFF8A1E), .65f to Color(0xFFD11A2A), 1f to Color(0xFF4A0412)), r, c)
        3 -> drawCircle(Brush.sweepGradient(0f to Color(0xFFFF8FA3), .2f to Color(0xFF990B24), .4f to Color(0xFFFFC2CD), .6f to Color(0xFFFF1E46), .8f to Color(0xFF4A0412), 1f to Color(0xFFFF8FA3), center = c), r, c)
        4 -> drawCircle(rad(0f to Color(0xFFFF1E46), .12f to Color(0xFF990B24), .22f to Color(0xFF2A0510), .34f to Color(0xFFFF1E46), .46f to Color(0xFF990B24), .6f to Color(0xFF2A0510), 1f to Color(0xFF990B24)), r, c)
        else -> drawCircle(rad(0f to Color(0xFFFF5A2E), .4f to Color(0xFF8F0A22), .8f to Color(0xFF1A0308), 1f to Color(0xFF1A0308)), r, c)
    }
    drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha = .85f), Color.Transparent), hi, r * .28f), r * .28f, hi)
}

/** mode: 0 idle, 1 listening, 2 speaking. bare = fill the box with no glow (used inside the nav). */
@Composable
fun JOrb(index: Int, modifier: Modifier = Modifier, mode: Int = 0, animate: Boolean = true, bare: Boolean = false) {
    val t = rememberInfiniteTransition(label = "orb")
    val pulse by t.animateFloat(1f, 1.07f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "pulse")
    val scale = if (animate && mode == 2) pulse else 1f
    Canvas(modifier.graphicsLayer { scaleX = scale; scaleY = scale }) {
        val c = center
        if (bare) { drawOrb(index, c, size.minDimension / 2); return@Canvas }
        val g = ORBS[index].glow
        val a = when (mode) { 0 -> .35f; 1 -> .6f; else -> .85f }
        drawCircle(Brush.radialGradient(listOf(g.copy(alpha = a), Color.Transparent), c, size.minDimension / 2), size.minDimension / 2, c)
        drawOrb(index, c, size.minDimension * .36f)
    }
}
