package com.juliet.ai.voice

import android.annotation.SuppressLint
import android.media.*
import android.util.Base64
import com.juliet.ai.data.VoiceState
import com.juliet.ai.phone.PhoneActions
import kotlinx.coroutines.flow.MutableStateFlow
import okhttp3.*
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/**
 * Real-time voice with the Gemini Live API (WebSocket).
 * Mic: 16 kHz PCM16 mono up. Reply: 24 kHz PCM16 mono down. Tool calls run PhoneActions.
 */
class GeminiLive(private val phone: PhoneActions) {
    val state = MutableStateFlow(VoiceState.Idle)
    val error = MutableStateFlow<String?>(null)
    var onTranscript: ((role: String, text: String) -> Unit)? = null

    private val http = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).build()
    private var ws: WebSocket? = null
    private var rec: AudioRecord? = null
    private var track: AudioTrack? = null
    private val queue = LinkedBlockingQueue<ByteArray>()
    @Volatile private var running = false
    private var volume = 0.8f
    private val inBuf = StringBuilder()
    private val outBuf = StringBuilder()

    fun start(key: String, model: String, voice: String, system: String, vol: Float) {
        if (state.value != VoiceState.Idle) return
        volume = vol; error.value = null; state.value = VoiceState.Connecting
        val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta." +
            "GenerativeService.BidiGenerateContent?key=$key"
        ws = http.newWebSocket(Request.Builder().url(url).build(), Listener(model, voice, system))
    }

    fun stop() { try { ws?.close(1000, "bye") } catch (e: Exception) {}; teardown() }

    @Synchronized private fun teardown() {
        running = false
        try { rec?.stop() } catch (e: Exception) {}
        try { rec?.release() } catch (e: Exception) {}
        try { track?.stop() } catch (e: Exception) {}
        try { track?.release() } catch (e: Exception) {}
        rec = null; track = null; ws = null
        queue.clear(); inBuf.clear(); outBuf.clear()
        state.value = VoiceState.Idle
    }

    private fun setup(model: String, voice: String, system: String): String = JSONObject().put("setup", JSONObject()
        .put("model", if (model.startsWith("models/")) model else "models/$model")
        .put("generationConfig", JSONObject()
            .put("responseModalities", JSONArray().put("AUDIO"))
            .put("speechConfig", JSONObject().put("voiceConfig",
                JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
        .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
        .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", phone.declarations())))
        .put("inputAudioTranscription", JSONObject())
        .put("outputAudioTranscription", JSONObject())
    ).toString()

    private inner class Listener(val model: String, val voice: String, val system: String) : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) { webSocket.send(setup(model, voice, system)) }
        override fun onMessage(webSocket: WebSocket, text: String) = handle(text)
        override fun onMessage(webSocket: WebSocket, bytes: ByteString) = handle(bytes.utf8())
        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) { webSocket.close(1000, null) }
        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            if (code != 1000 && reason.isNotBlank()) error.value = "Voice closed: $reason"
            teardown()
        }
        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            error.value = "Voice connection failed: ${t.message ?: response?.code}"
            teardown()
        }
    }

    private fun handle(text: String) {
        val j = try { JSONObject(text) } catch (e: Exception) { return }
        if (j.has("setupComplete")) { beginAudio(); return }
        j.optJSONObject("serverContent")?.let { onContent(it) }
        j.optJSONObject("toolCall")?.let { onTool(it) }
        if (j.has("goAway")) error.value = "Voice session is ending. Tap the mic to reconnect."
    }

    private fun onContent(sc: JSONObject) {
        if (sc.optBoolean("interrupted")) flushPlayback()
        sc.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { parts ->
            for (i in 0 until parts.length()) {
                val d = parts.getJSONObject(i).optJSONObject("inlineData")?.optString("data").orEmpty()
                if (d.isNotEmpty()) { queue.put(Base64.decode(d, Base64.DEFAULT)); state.value = VoiceState.Speaking }
            }
        }
        sc.optJSONObject("inputTranscription")?.optString("text")?.let { inBuf.append(it) }
        sc.optJSONObject("outputTranscription")?.optString("text")?.let { outBuf.append(it) }
        if (sc.optBoolean("turnComplete")) {
            if (inBuf.isNotBlank()) onTranscript?.invoke("user", inBuf.toString().trim())
            if (outBuf.isNotBlank()) onTranscript?.invoke("assistant", outBuf.toString().trim())
            inBuf.clear(); outBuf.clear()
            if (running) state.value = VoiceState.Listening
        }
    }

    private fun onTool(o: JSONObject) {
        val calls = o.optJSONArray("functionCalls") ?: return
        val out = JSONArray()
        for (i in 0 until calls.length()) {
            val c = calls.getJSONObject(i)
            val name = c.optString("name")
            val result = try { phone.execute(name, c.optJSONObject("args") ?: JSONObject()) }
            catch (e: Exception) { "Failed: ${e.message}" }
            out.put(JSONObject().put("id", c.optString("id")).put("name", name)
                .put("response", JSONObject().put("result", result)))
        }
        ws?.send(JSONObject().put("toolResponse", JSONObject().put("functionResponses", out)).toString())
    }

    private fun beginAudio() { running = true; startPlayer(); startMic(); state.value = VoiceState.Listening }

    @SuppressLint("MissingPermission")
    private fun startMic() {
        val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, 16000,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 3200) * 2)
        rec = r; r.startRecording()
        thread(name = "juliet-mic") {
            val buf = ByteArray(3200)   // 100 ms
            while (running) {
                val n = r.read(buf, 0, buf.size)
                if (n > 0) ws?.send(JSONObject().put("realtimeInput", JSONObject().put("audio", JSONObject()
                    .put("data", Base64.encodeToString(buf, 0, n, Base64.NO_WRAP))
                    .put("mimeType", "audio/pcm;rate=16000"))).toString())
            }
        }
    }

    private fun startPlayer() {
        val min = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(min * 4).setTransferMode(AudioTrack.MODE_STREAM).build()
        t.setVolume(volume); track = t; t.play()
        thread(name = "juliet-play") {
            while (running) {
                val b = queue.poll(200, TimeUnit.MILLISECONDS) ?: continue
                try { t.write(b, 0, b.size) } catch (e: Exception) {}
            }
        }
    }

    private fun flushPlayback() {
        queue.clear()
        try { track?.pause(); track?.flush(); track?.play() } catch (e: Exception) {}
    }
}
