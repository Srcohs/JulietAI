package com.juliet.ai.data

enum class Screen { Home, Chat, History, Settings, Look, Voice, Phone, Quick, Perm, Conn, Privacy, Profile, Orb, About }
enum class VoiceState { Idle, Connecting, Listening, Speaking }
data class ChatMsg(val role: String, val text: String)   // role: "user" | "assistant"
data class Conv(val id: Long, val title: String, val msgs: List<ChatMsg>)
