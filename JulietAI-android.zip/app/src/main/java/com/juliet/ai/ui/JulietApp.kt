package com.juliet.ai.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.juliet.ai.data.Screen
import com.juliet.ai.data.VoiceState
import com.juliet.ai.vm.JulietViewModel
import kotlinx.coroutines.delay

private val NO_NAV = setOf(Screen.Quick, Screen.Perm, Screen.Privacy, Screen.Profile, Screen.About, Screen.Orb)

@Composable
fun JulietApp(vm: JulietViewModel) {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<((Boolean) -> Unit)?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        pending?.invoke(ok); pending = null; vm.permTick++
    }
    val askPerm: (String, (Boolean) -> Unit) -> Unit = { perm, cb ->
        if (ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED) cb(true)
        else { pending = cb; launcher.launch(perm) }
    }
    var splash by rememberSaveable { mutableStateOf(true) }
    val haptic = LocalHapticFeedback.current
    val vs by vm.live.state.collectAsState()
    val onMic: () -> Unit = {
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        if (vs != VoiceState.Idle) vm.stopVoice()
        else askPerm(Manifest.permission.RECORD_AUDIO) { ok -> if (ok) vm.startVoice() else vm.toast = "Microphone permission is needed" }
    }
    LaunchedEffect(Unit) {
        vm.autoStart(ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    BackHandler(enabled = vm.stack.size > 1 || vm.screen != Screen.Home) { vm.back() }

    val dark = when (vm.s("theme")) { "Dark" -> true; "Light" -> false; else -> isSystemInDarkTheme() }
    val imeUp = WindowInsets.ime.getBottom(LocalDensity.current) > 0

    JulietTheme(dark) {
        val p = LocalPal.current
        Box(Modifier.fillMaxSize().background(p.bg).drawBehind {
            drawRect(Brush.radialGradient(listOf(J.Red.copy(alpha = if (dark) .16f else .10f), Color.Transparent), Offset(size.width / 2, 0f), size.width))
        }.imePadding()) {
            when (vm.screen) {
                Screen.Home -> HomeScreen(vm, onMic)
                Screen.Chat -> ChatScreen(vm, imeUp)
                Screen.History -> HistoryScreen(vm)
                Screen.Settings -> SettingsScreen(vm)
                Screen.Look -> LookScreen(vm)
                Screen.Voice -> VoiceScreen(vm)
                Screen.Phone -> PhoneScreen(vm)
                Screen.Quick -> QuickScreen(vm, onMic)
                Screen.Perm -> PermScreen(vm, askPerm)
                Screen.Conn -> ConnScreen(vm)
                Screen.Privacy -> PrivacyScreen(vm)
                Screen.Profile -> ProfileScreen(vm)
                Screen.Orb -> OrbScreen(vm)
                Screen.About -> AboutScreen(vm)
            }
            if (vm.screen !in NO_NAV && !imeUp) {
                Box(Modifier.align(Alignment.BottomCenter)) {
                    BottomNav(vm.screen, vm.s("orb").toIntOrNull() ?: 0, { vm.navigate(it) }) {
                        vm.navigate(Screen.Home); onMic()
                    }
                }
            }
            vm.toast?.let { msg ->
                LaunchedEffect(msg) { delay(2400); if (vm.toast == msg) vm.toast = null }
                Text(msg, color = p.text, fontSize = 15.sp,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 120.dp).clip(RoundedCornerShape(24.dp)).background(p.card2).padding(horizontal = 18.dp, vertical = 10.dp))
            }
            AnimatedVisibility(splash, exit = fadeOut(tween(450))) { SplashScreen(vm.s("reduce") == "1") { splash = false } }
        }
    }
}
