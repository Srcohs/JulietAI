# JULIET AI - Android (Kotlin + Jetpack Compose)

Updated source version: 1.6 (2026-10-23).

Voice-first assistant by Ahsan Raza.
- Voice: Gemini Live API (WebSocket), phone tools: open app, call, WhatsApp.
- Typed chat: Groq, several keys take turns on rate limits.
- Keys, settings and chats are stored encrypted on the phone.
- Splash with your logo, orb styles, history, permissions.

## Get the APK from GitHub (no Android Studio needed)
1. Create a free account at github.com, then New repository, name it JulietAI (Private is fine), Create.
2. On a computer unzip JulietAI-android.zip. In the folder run:
       git init
       git add .
       git commit -m "Juliet AI"
       git branch -M main
       git remote add origin https://github.com/YOUR_NAME/JulietAI.git
       git push -u origin main
   (No git? Use the repo page: Add file > Upload files, drag everything. Hidden folders such as .github
   are often skipped, so afterwards check that .github/workflows/android.yml exists; if not, use
   Add file > Create new file, type .github/workflows/android.yml and paste the file's text.)
3. Open the repo's Actions tab. "Build Android APK" starts by itself (about 5 to 8 minutes).
4. When it is green, open the run, scroll to Artifacts and download JulietAI-debug-apk. Unzip it to get app-debug.apk.
5. Send the APK to your phone and install it (allow "Install unknown apps" for your file manager or browser).
6. Open Juliet AI > Settings > Connections, paste your Gemini key (aistudio.google.com/apikey) and Groq key(s) (console.groq.com/keys).
7. Optional public download link: tag a release. git tag v1.4.0 && git push origin v1.4.0
   The APK then appears under the repo's Releases.

If the build turns red, open the failed step, copy the error text and send it to Claude to fix.

## Run locally instead
Open the folder in Android Studio (Koala or newer), let Gradle sync, run on a real phone.

## Before you share it
- Model names change: Gemini voice models in VOICE_MODELS (JulietViewModel.kt), Groq models in GroqClient.MODELS. Groq retired llama-3.3-70b-versatile on 16 Aug 2026.
- Privacy: no Juliet server; chats and keys stay encrypted on the phone. Voice goes to Google Gemini and typed chat to Groq with your own keys. Free-tier Gemini keys may be used by Google to improve its products (see ai.google.dev/gemini-api/terms); use a billing-enabled key for stricter privacy.
- A debug APK is fine for your own phones. For Play Store you need a signed release build.
- Built-in keys through local.properties (juliet.gemini, juliet.groq) can be extracted from an APK. Keep them out of public builds.
- Voice pauses if another app opens (Android blocks background microphone).


## Version 1.6 source updates
- Added a local Memory & Knowledge screen; saved owner-provided facts are included in typed-chat system instructions.
- Added local Quick Notes and Code/Draft Pad storage. AI writing/code generation still uses the existing Chat + Groq connection.
- Added an optional Android NotificationListenerService for spoken app notification announcements, with user-controlled enable and content-preview settings. Notification access must be granted in Android Settings.
- Added a separate, off-by-default WhatsApp auto-reply toggle using the existing Groq chat client and saved custom knowledge. It only attempts replies when Android exposes a reply action and a MessagingStyle private conversation that can be verified; it fails closed on Android below 9, group chats, titled/ambiguous conversations, missing sender/text, and unsupported notifications. It cannot guarantee WhatsApp metadata is complete on every device/version.
- Added in-memory duplicate-event protection and checks the current notification again before replying. Manual replies reflected as the latest sender are skipped.
- Typed-chat instructions now include the supplied owner context (Ahsan; usual work hours 9:30 AM–5:00 PM) without forcing a canned response. “Bhenso ki Rani” remains intentionally undefined unless added to custom knowledge.
- Existing chat, voice, history, and phone actions are retained.

## Important implementation status
This archive contains the updated Android source, not a newly built APK. This environment did not have an Android SDK or a usable Gradle installation/wrapper JAR, so compilation and device testing could not be performed here. The provided APK archive is the earlier version and has not been modified. True Gemini image generation/sketch conversion, live MediaProjection screen sharing/control, native call speaker routing, and complete incoming-call identity announcements are not implemented by this source update. WhatsApp auto-reply is an experimental notification-action implementation with strict fail-closed filtering, not a full WhatsApp API integration. It requires a supported notification layout, Android notification access, an available Groq key, and explicit opt-in; verify it carefully on the target phone before relying on it.


## v1.7 additions (source update)
- Added Gemini image generation and optional photo-to-sketch/photo-edit input. Uses the user's Gemini API key; image output depends on current model access and billing. Images remain in memory and are not auto-published.
- Added Android MediaProjection-based live screen capture with explicit system consent, a persistent foreground notification, downsampled JPEG frames, and a stop control. Frames are forwarded to Gemini Live only while the Live session is connected. Capture does not provide remote taps/control and should not be used on sensitive screens.
- Added a live voice playback volume slider. This controls Juliet's audio output, not the cellular-call speaker volume managed by Android's dialer.
- Added basic manual-handover state in the notification auto-reply path. Clearing handover relies on Android/WhatsApp exposing an outgoing MessagingStyle entry marked as the owner.

## Important validation status
This is a source-level update. The project has no Gradle wrapper executable/JAR and this environment does not have an Android SDK installed, so the APK could not be compiled or device-tested here. Run the repository's GitHub Actions Android build and test on a real device before installing. MediaProjection, Gemini Live image input, and Gemini image-generation model support can vary by Android/API/provider model version. Native cellular-call speaker routing is not implemented because the app launches Android's dialer and the dialer owns that call's audio route.


## Loudspeaker routing (v1.8 update)
- Juliet Live voice now prefers the phone loudspeaker by default.
- Settings → Voice & language includes a “Use loudspeaker” toggle to switch between speaker and earpiece.
- The app requests Android communication audio routing and restores the previous audio route when the Live session stops.
- Device/OEM behavior may vary; this controls Juliet's app voice session, not the speakerphone setting of a separate cellular call.


## v1.9 workflow and live-call loudspeaker fix
- GitHub Actions now explicitly installs Android SDK platform 34 and build tools 34.0.0 before compiling.
- Uses Java 17 (matching the Android module) and Gradle 8.7.
- Build logs are always uploaded, and the failure summary includes the tail of the full Gradle log so future failures are diagnosable.
- Gemini Live requests communication audio focus and applies the selected loudspeaker/earpiece route as the live session starts, rather than waiting until Gemini setup completes.
- The default saved preference remains loudspeaker ON; the Settings toggle can switch to the earpiece.

Note: the GitHub Actions workflow has been statically reviewed, but this environment cannot confirm a remote GitHub build or physical-device call routing. Cellular dialer calls are separate from the in-app Gemini Live voice session.


## GitHub Actions build fix (2026-10-23)

This project uses Android Gradle Plugin 8.5.2, Kotlin 1.9.24, Java 17, Gradle 8.7, and Android SDK 34. The workflow does not run `chmod +x ./gradlew`, because this archive has no Gradle wrapper script/JAR. It installs Gradle 8.7 in the runner and builds the located project with `gradle assembleDebug`. It can build either from project files in the repository root or extract the source ZIP if the repository only contains the ZIP.
