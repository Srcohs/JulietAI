# Juliet WhatsApp Category Bot

## What changed
- Removed the hard-coded special-contact persona and bundled contact entry.
- The old saved WhatsApp knowledge is cleared once on upgrade so each installation can add its own facts.
- A greeting such as `Hi` or `Assalam-o-Alaikum` opens the user's category menu.
- A number or category name selects a category, then a subcategory, then an option/reply.
- Free-form messages that do not match a menu choice go to Gemini, with Groq as fallback if configured.
- The Memory & Auto-Reply screen now includes category/subcategory/option management and XML import.

## XML format
Use `whatsapp-categories-template.xml` as a starting point. Supported tags are `category`, `subcategory` (or `sub-category`), and `option` (or `item`). Use `name`, `title`, or `label` for the displayed label, and `answer` or `reply` for the option response. Keep the hierarchy nested as in the sample.

## Important platform limitation
This implementation sends numbered text menus through Android's WhatsApp notification reply action. It does not create native WhatsApp interactive list/button messages; those require the official WhatsApp Business Platform API. The bot only sees/responds to eligible private-message notifications and requires notification access.

## Data scope
Categories and knowledge are stored locally in Juliet's encrypted preferences on that device. The current app does not implement multi-account profiles or cloud syncing between different devices.

## Bot modes and strict answering (v3)
- **Category Menu** (default): `Hi` / `Salam` / first contact shows your categories first. A number or name opens a category; `back` goes up, `menu` restarts. Free text is matched locally against your tree.
- **Auto AI**: Gemini reads the whole chat (last 20 messages) and answers ONLY from your categories + saved knowledge. It must return `grounded: true`; numbers and links in its answer must exist in your saved data, otherwise the reply is blocked.
- Anything not covered gets **no reply** (default) and you get an owner alert (max one per sender per 10 min). Setting "When bot is unsure" can re-send the menu instead.
- Rapid messages from one person are merged (1.8 s) so the bot reads the complete message and none are dropped.
