/**
 * Juliet AI - Application Orchestrator
 * Integrates Chat, Voice Input, Screen Recording, Screen Sharing, and Phone Actions.
 */
document.addEventListener('DOMContentLoaded', () => {
  const chatMessages = document.getElementById('chatMessages');
  const messageInput = document.getElementById('messageInput');
  const sendBtn = document.getElementById('sendBtn');
  const voiceBtn = document.getElementById('voiceBtn');
  const screenRecBtn = document.getElementById('screenRecBtn');
  const screenShareBtn = document.getElementById('screenShareBtn');
  const phoneActionBtn = document.getElementById('phoneActionBtn');
  const recordingBanner = document.getElementById('recordingBanner');
  const recTimer = document.getElementById('recTimer');
  const stopRecBannerBtn = document.getElementById('stopRecBannerBtn');
  const typingIndicator = document.getElementById('typingIndicator');

  // ──────── Helper: Get Formatted Time ────────
  function getTimeString() {
    const now = new Date();
    return now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }

  // ──────── Append User Message ────────
  function appendUserMessage(text) {
    const bubble = document.createElement('div');
    bubble.className = 'message-bubble user';
    bubble.innerHTML = `
      <p>${escapeHtml(text)}</p>
      <div class="meta-info">
        <span class="time">${getTimeString()}</span>
        <span class="checkmarks">✓✓</span>
      </div>
    `;
    chatMessages.insertBefore(bubble, typingIndicator);
    scrollToBottom();
  }

  // ──────── Append Juliet Message ────────
  function appendJulietMessage(data) {
    const bubble = document.createElement('div');
    bubble.className = 'message-bubble juliet';

    let categoryHtml = '';
    if (data.category) {
      categoryHtml = `<span class="category-tag">${escapeHtml(data.category)}</span>`;
    }

    let chipsHtml = '';
    if (data.chips && data.chips.length > 0) {
      chipsHtml = `
        <div class="chips-container">
          ${data.chips.map(chip => `<button class="chip-btn" data-query="${escapeHtml(chip)}">${escapeHtml(chip)}</button>`).join('')}
        </div>
      `;
    }

    // Format newlines to paragraphs
    const formattedText = escapeHtml(data.text).replace(/\n/g, '<br>');

    bubble.innerHTML = `
      ${categoryHtml}
      <p>${formattedText}</p>
      ${chipsHtml}
      <div class="meta-info">
        <span class="time">${getTimeString()}</span>
      </div>
    `;

    chatMessages.insertBefore(bubble, typingIndicator);
    scrollToBottom();
  }

  // ──────── Handle Send Message ────────
  async function handleSend(customText = null) {
    const text = customText || messageInput.value.trim();
    if (!text) return;

    if (!customText) messageInput.value = '';

    // 1. Show user message
    appendUserMessage(text);

    // 2. Show typing indicator
    showTyping(true);

    // Natural human-like reply delay (500ms - 900ms)
    const delay = Math.floor(Math.random() * 400) + 500;
    setTimeout(async () => {
      const response = await window.julietBot.processMessage(text);
      showTyping(false);
      if (response) {
        appendJulietMessage(response);
      }
    }, delay);
  }

  function showTyping(show) {
    if (show) {
      typingIndicator.classList.add('active');
    } else {
      typingIndicator.classList.remove('active');
    }
    scrollToBottom();
  }

  function scrollToBottom() {
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }

  function escapeHtml(string) {
    const div = document.createElement('div');
    div.innerText = string;
    return div.innerHTML;
  }

  // ──────── Event Listeners for Chat ────────
  sendBtn.addEventListener('click', () => handleSend());

  messageInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleSend();
    }
  });

  // Chip click delegation
  chatMessages.addEventListener('click', (e) => {
    if (e.target.classList.contains('chip-btn')) {
      const query = e.target.getAttribute('data-query');
      if (query) handleSend(query);
    }
  });

  // ──────── Voice Input (Web Speech API) ────────
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  let recognition = null;
  let isListening = false;

  if (SpeechRecognition) {
    recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'ur-PK, en-US';

    recognition.onstart = () => {
      isListening = true;
      voiceBtn.classList.add('listening');
      messageInput.placeholder = 'Sun rahi hoon, boliye...';
    };

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      if (transcript) {
        messageInput.value = transcript;
        handleSend(transcript);
      }
    };

    recognition.onerror = (e) => {
      console.warn("Speech recognition error:", e);
      stopListening();
    };

    recognition.onend = () => {
      stopListening();
    };
  }

  function stopListening() {
    isListening = false;
    voiceBtn.classList.remove('listening');
    messageInput.placeholder = 'Message Juliet...';
  }

  voiceBtn.addEventListener('click', () => {
    if (!SpeechRecognition) {
      alert("Voice input is supported in Chrome, Edge, and mobile browsers.");
      return;
    }
    if (isListening) {
      recognition.stop();
    } else {
      recognition.start();
    }
  });

  // ──────── Screen Recording Feature ────────
  const recorder = window.julietScreenRecorder;

  recorder.onStateChange = (recording) => {
    if (recording) {
      screenRecBtn.classList.add('recording');
      screenRecBtn.title = 'Stop Screen Recording';
      recordingBanner.classList.add('active');
    } else {
      screenRecBtn.classList.remove('recording');
      screenRecBtn.title = 'Screen Recorder';
      recordingBanner.classList.remove('active');
    }
  };

  recorder.onTimerUpdate = (formattedTime) => {
    recTimer.innerText = formattedTime;
  };

  screenRecBtn.addEventListener('click', async () => {
    if (recorder.isRecording) {
      recorder.stopRecording();
      appendJulietMessage({
        category: "Screen Recorder",
        text: "Screen recording finish ho gayi hai aur aapki video file (.webm) download folder mein save ho gayi hai! 🎥"
      });
    } else {
      const res = await recorder.startRecording();
      if (!res.success) {
        alert("Screen recording permission denied ya browser support nahi karta.");
      }
    }
  });

  stopRecBannerBtn.addEventListener('click', () => {
    recorder.stopRecording();
    appendJulietMessage({
      category: "Screen Recorder",
      text: "Recording saved! File aapke browser downloads mein save ho chuki hai. ✔"
    });
  });

  // ──────── Screen Vision & Share Feature ────────
  screenShareBtn.addEventListener('click', async () => {
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
      appendJulietMessage({
        category: "Screen Vision",
        text: "Screen share active ho gaya hai! Main aapki screen dekh sakti hoon aur guide kar sakti hoon. Jab kaam ho jaye to browser stop share button dabayein."
      });
      stream.getVideoTracks()[0].onended = () => {
        appendJulietMessage({
          category: "Screen Vision",
          text: "Screen share disconnect ho gaya hai. Agli bar zaroorat ho to dobara start karein!"
        });
      };
    } catch (err) {
      console.warn("Screen share cancelled:", err);
    }
  });

  // ──────── Phone Automation Action ────────
  phoneActionBtn.addEventListener('click', () => {
    appendJulietMessage({
      category: "Phone Control",
      text: "Phone dialer ready hai! Aap bol kar ya likh kar kisi bhi contact ya number ko call milwa sakte hain (e.g., 'Call Papa')."
    });
  });
});
