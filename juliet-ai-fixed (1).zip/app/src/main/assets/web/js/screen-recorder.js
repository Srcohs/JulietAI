/**
 * Juliet AI - Screen Recording Engine
 * Uses navigator.mediaDevices.getDisplayMedia + MediaRecorder with live timer and WebM download.
 */
class JulietScreenRecorder {
  constructor() {
    this.mediaRecorder = null;
    this.recordedChunks = [];
    this.isRecording = false;
    this.timerInterval = null;
    this.secondsElapsed = 0;
    this.stream = null;
    this.micStream = null;
    this.includeMic = false;

    this.onStateChange = null;
    this.onTimerUpdate = null;
  }

  setIncludeMic(val) {
    this.includeMic = !!val;
  }

  async startRecording() {
    if (this.isRecording) return;
    try {
      this.recordedChunks = [];
      this.secondsElapsed = 0;

      // 1. Get Screen Display Stream
      const displayStream = await navigator.mediaDevices.getDisplayMedia({
        video: { cursor: "always" },
        audio: true
      });

      let combinedStream = displayStream;

      // 2. Mix in Mic if enabled
      if (this.includeMic) {
        try {
          this.micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
          const audioContext = new AudioContext();
          const destination = audioContext.createMediaStreamDestination();

          if (displayStream.getAudioTracks().length > 0) {
            const displayAudioSource = audioContext.createMediaStreamSource(displayStream);
            displayAudioSource.connect(destination);
          }
          const micAudioSource = audioContext.createMediaStreamSource(this.micStream);
          micAudioSource.connect(destination);

          combinedStream = new MediaStream([
            ...displayStream.getVideoTracks(),
            ...destination.stream.getAudioTracks()
          ]);
        } catch (e) {
          console.warn("Could not capture mic audio:", e);
        }
      }

      this.stream = combinedStream;

      // Handle user stopping stream from native browser banner
      displayStream.getVideoTracks()[0].onended = () => {
        if (this.isRecording) {
          this.stopRecording();
        }
      };

      // 3. Setup MediaRecorder
      const mimeType = MediaRecorder.isTypeSupported('video/webm; codecs=vp9,opus')
        ? 'video/webm; codecs=vp9,opus'
        : 'video/webm';

      this.mediaRecorder = new MediaRecorder(combinedStream, { mimeType });

      this.mediaRecorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          this.recordedChunks.push(event.data);
        }
      };

      this.mediaRecorder.onstop = () => {
        this.saveAndDownloadRecording();
        this.cleanupStreams();
      };

      this.mediaRecorder.start(1000); // 1-second chunks
      this.isRecording = true;

      // 4. Start Timer
      this.timerInterval = setInterval(() => {
        this.secondsElapsed++;
        if (this.onTimerUpdate) {
          this.onTimerUpdate(this.formatTimer(this.secondsElapsed));
        }
      }, 1000);

      if (this.onStateChange) this.onStateChange(true);
      if (this.onTimerUpdate) this.onTimerUpdate(this.formatTimer(0));

      return { success: true };
    } catch (err) {
      console.error("Screen recording initiation failed:", err);
      this.cleanupStreams();
      return { success: false, error: err.message };
    }
  }

  stopRecording() {
    if (!this.isRecording) return;
    this.isRecording = false;

    if (this.timerInterval) {
      clearInterval(this.timerInterval);
      this.timerInterval = null;
    }

    if (this.mediaRecorder && this.mediaRecorder.state !== "inactive") {
      this.mediaRecorder.stop();
    }

    if (this.onStateChange) this.onStateChange(false);
  }

  saveAndDownloadRecording() {
    if (this.recordedChunks.length === 0) return;
    const blob = new Blob(this.recordedChunks, { type: 'video/webm' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = url;
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    a.download = `juliet_recording_${timestamp}.webm`;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    }, 100);
  }

  cleanupStreams() {
    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop());
      this.stream = null;
    }
    if (this.micStream) {
      this.micStream.getTracks().forEach(track => track.stop());
      this.micStream = null;
    }
  }

  formatTimer(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  }
}

window.julietScreenRecorder = new JulietScreenRecorder();
