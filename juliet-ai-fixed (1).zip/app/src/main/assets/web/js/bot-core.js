/**
 * Juliet AI - Bot Core Engine
 * Handles greeting priority, knowledge retrieval, and natural conversational responses.
 */
class JulietBot {
  constructor() {
    this.greetings = [
      "hello", "hey", "hi", "aoa", "assalamualaikum", "assalam o alaikum",
      "salam", "hi there", "kese ho", "kaise ho", "kaisa hai", "good morning",
      "good afternoon", "good evening", "good night", "hie"
    ];

    this.greetingReplies = [
      "Walaikum Assalam! Main bilkul theek hoon. Aap sunayein, kaisa chal raha hai sab? Aaj main aapki kya madad kar sakti hoon? ❤️",
      "Hey there! Main Juliet hoon. Kaho, aaj kya plan hai? Kaise help karun main aapki? 😊",
      "Assalam o Alaikum! Aapse baat karke bohat acha laga. Batayein aaj hum kya karein? 💕",
      "Hello! Main hamesha ki tarah ready hoon aapke saath baat karne ke liye. Kaisi rahi aapki din ki shuruat?"
    ];

    this.smartFallbacks = [
      "Main samajh rahi hoon aapki baat. Thoda aur detail se batao taake main sahi se guide kar sakoon? 😊",
      "Yeh to bohat interesting baat hai! Is par aur baat karein? Main sun rahi hoon.",
      "Theek hai, main is par dhyan de rahi hoon. Agar aap chahein to main screen vision ya phone automation se bhi isay hal kar sakti hoon!",
      "Aap bilkul befikr rahein, main har waqt aapke sath hoon. Batayein aage kya karna hai?"
    ];
  }

  isGreeting(text) {
    if (!text) return false;
    const clean = text.toLowerCase().replace(/[!.,?]/g, '').trim();
    return this.greetings.some(g => clean === g || clean.startsWith(g + " "));
  }

  async processMessage(userText) {
    const text = userText.trim();
    if (!text) return null;

    // 1. PRIORITY GREETING CHECK
    if (this.isGreeting(text)) {
      const reply = this.greetingReplies[Math.floor(Math.random() * this.greetingReplies.length)];
      return {
        type: "greeting",
        text: reply,
        chips: ["Banking", "Education", "Health", "Phone Actions", "Chai time ☕"]
      };
    }

    // 2. CHECK OFFLINE KNOWLEDGE (js/knowledge.js)
    if (typeof findKnowledgeAnswer === "function") {
      const match = findKnowledgeAnswer(text);
      if (match.found) {
        return {
          type: "knowledge",
          category: match.category,
          title: match.title,
          text: match.reply,
          chips: ["Aur madad chahiye", "Back to categories"]
        };
      }
    }

    // 3. PHONE / AUTOMATION COMMAND CHECK
    const lower = text.toLowerCase();
    if (lower.startsWith("call ") || lower.includes("ko call karo")) {
      const target = text.replace(/call|ko call karo/gi, "").trim();
      return {
        type: "action",
        actionType: "call",
        target: target || "Contact",
        text: `Main ${target || "contact"} ko call milane ke liye dialer prepare kar rahi hoon... 📞`
      };
    }

    if (lower.includes("screen share") || lower.includes("share screen")) {
      return {
        type: "action",
        actionType: "screenshare",
        text: "Screen sharing start karne ke liye top bar mein Screen Share button tap karein!"
      };
    }

    if (lower.includes("record screen") || lower.includes("recording")) {
      return {
        type: "action",
        actionType: "screenrecord",
        text: "Screen recording feature ready hai! Top bar mein Record button tap karke start karein."
      };
    }

    // 4. NATURAL HUMAN-LIKE DYNAMIC RESPONSE
    const fallback = this.smartFallbacks[Math.floor(Math.random() * this.smartFallbacks.length)];
    return {
      type: "chat",
      text: fallback,
      chips: ["Kuch aur pucho", "Help chahiye"]
    };
  }
}

window.julietBot = new JulietBot();
