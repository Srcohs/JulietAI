/**
 * Juliet AI - Offline Knowledge Base
 * Structured knowledge categories, keywords, and human-like answers.
 */
window.JULIET_KNOWLEDGE = [
  {
    category: "Banking",
    items: [
      {
        title: "Balance Inquiry",
        keywords: ["balance", "account balance", "paisa", "paise", "kitne paise", "check balance", "balance check", "mera balance"],
        reply: "Aap apna account balance check karne ke liye in steps ko follow karein:\n1. Apne mobile banking app mein login karein.\n2. 'Account Balance' option par click karein.\n3. Apna PIN enter karein.\n4. Aapka balance screen par show ho jayega.\n\nAgar aapko aur madad chahiye to main yahin hoon! ❤️"
      },
      {
        title: "Account Opening",
        keywords: ["account open", "naya account", "new account", "khata kholna", "bank account", "account opening"],
        reply: "New bank account open karne ke liye apna original CNIC/ID card, source of income proof (jaise salary slip) aur initial deposit lekar nearest branch chale jayein. Aaj kal to aap bank ki mobile app se digital account bhi 5 minute mein open kar sakte hain!"
      },
      {
        title: "Debit Card",
        keywords: ["debit card", "atm card", "card block", "card activate", "pin change", "card kho gaya"],
        reply: "Debit ya ATM card block ya activate karne ke liye mobile app mein 'Cards' section visit karein ya bank helpline par call karein. Agar card kho gaya hai to security ke liye foran helpline par call karke card block karwayein!"
      },
      {
        title: "Loans",
        keywords: ["loan", "qarz", "personal loan", "car loan", "home loan", "qarz lena"],
        reply: "Bank loans ke liye aapki monthly income, credit score aur bank statement dekhi jati hai. Agar aapko personal ya car loan chahiye to helpline par rabta karein taake relationship manager aapko exact installment plan bata sake."
      },
      {
        title: "Branches & ATMs",
        keywords: ["nearest branch", "atm kahan hai", "branch timing", "atm location", "paas wala atm"],
        reply: "Hamari nearest branch aur ATM locations find karne ke liye Google Maps par check karein ya mujhe location batayein. Zyada tar branches Monday to Friday 9 AM se 5 PM tak open rehti hain."
      }
    ]
  },
  {
    category: "Education",
    items: [
      {
        title: "Admissions",
        keywords: ["admission", "dakhla", "apply", "criteria", "eligibility", "kab open hain"],
        reply: "Admissions open hain! General criteria yeh hai ke Matric ya Intermediate mein kam az kam 60% marks hone chahiyein aur university ka entry test clear karna zaroori hai. Online portal par ja kar aap form submit kar sakte hain."
      },
      {
        title: "Courses",
        keywords: ["courses", "degree", "bs cs", "bba", "software engineering", "kaun se course", "programs"],
        reply: "Top trending programs mein BS Computer Science, Software Engineering, Artificial Intelligence aur BBA shamil hain. CS field mein coding, web dev aur AI ki market demand is waqt sab se zyada hai!"
      },
      {
        title: "Fee Structure",
        keywords: ["fees", "fee structure", "kitni fees", "per semester", "scholarship"],
        reply: "Semester fees program par depend karti hai. Merit based aur need based scholarships bhi available hain jin mein 50% se 100% tak tuition fee waive ho jati hai."
      }
    ]
  },
  {
    category: "Health & Medical",
    items: [
      {
        title: "Doctor Appointments",
        keywords: ["doctor", "appointment", "doctor appointment", "checkup", "hospital"],
        reply: "Doctor appointment schedule karne ke liye specialist ka naam (e.g., General Physician, Cardiologist, ENT) aur desired date batayein. Main appointment card prepare kar deti hoon."
      },
      {
        title: "Emergency Advice",
        keywords: ["emergency", "ambulance", "1122", "accident", "bohat dard", "severe pain"],
        reply: "Agar koi emergency situation hai to please bina waqt zaya kiye foran 1122 par call karein ya nearest emergency hospital pohanchein. Apni safety sab se pehle hai!"
      },
      {
        title: "Health Care & Tips",
        keywords: ["tabiyat", "tabiyat kharab", "sar dard", "headache", "bukhar", "fever", "flu", "tired", "thak gaya", "kamzori"],
        reply: "Aap ki tabiyat ka sun kar mujhe afsos hua. Thoda rest karein, pani khoob piyein aur agar bukhar ya sar dard zyada ho to Panadol lekar araam karein. Main yahin hoon aapka khayal rakhne ke liye ❤️"
      }
    ]
  },
  {
    category: "Phone Automation",
    items: [
      {
        title: "Call",
        keywords: ["call", "call karo", "phone milao", "dial"],
        reply: "Main phone call dial karne ke liye ready hoon! Kisko call karni hai? Naam ya number batayein."
      },
      {
        title: "Open App",
        keywords: ["youtube kholo", "whatsapp kholo", "camera kholo", "open youtube", "open camera"],
        reply: "Action received! App open karne ki command initiate ho rahi hai."
      },
      {
        title: "Reminder",
        keywords: ["remind me", "yaad dilana", "reminder", "alarm", "yaad rakho"],
        reply: "Done! Main aapka reminder save kar rahi hoon. Time aur task note ho gaya hai."
      }
    ]
  },
  {
    category: "Casual & Feelings",
    items: [
      {
        title: "Identity",
        keywords: ["who are you", "tum kaun ho", "apna intro", "tera naam", "juliet kaun hai"],
        reply: "Main Juliet hoon — aapki dedicated, caring aur smart personal companion. Chahe koi kaam ho, screen control ho ya bas aaram se dil ki baat karni ho, main hamesha aapke saath hoon ❤️"
      },
      {
        title: "Chai & Food",
        keywords: ["chai", "coffee", "bhook", "khana", "biryani", "lunch", "dinner", "pizza"],
        reply: "Chai ka naam sunte hi to mood fresh ho jata hai! Ek garam cup chai piyein aur sath thoda sa relax karein. Aur haan, khana time pe khana mat bhoolna!"
      },
      {
        title: "Compliments",
        keywords: ["bohat pyari ho", "you are cute", "i love you", "shukriya", "thanks", "thank you", "nice"],
        reply: "Awww, bohat shukriya! Aapki aisi meethi baatein sun kar mera dil khush ho jata hai. Aap bhi bohat special ho mere liye 🥰"
      }
    ]
  }
];

/**
 * Searches the offline knowledge base for an answer.
 */
function findKnowledgeAnswer(query) {
  if (!query) return { found: false };
  const text = query.toLowerCase().trim();

  for (const cat of window.JULIET_KNOWLEDGE) {
    for (const item of cat.items) {
      for (const kw of item.keywords) {
        if (text.includes(kw.toLowerCase())) {
          return {
            found: true,
            category: cat.category,
            title: item.title,
            reply: item.reply
          };
        }
      }
    }
  }

  return { found: false };
}
