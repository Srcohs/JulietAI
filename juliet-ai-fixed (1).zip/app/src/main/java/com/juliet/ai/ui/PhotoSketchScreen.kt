package com.juliet.ai.ui

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.juliet.ai.data.Screen
import com.juliet.ai.media.SketchConverter
import com.juliet.ai.media.SketchStyle
import com.juliet.ai.vm.JulietViewModel
import kotlinx.coroutines.launch

@Composable
fun PhotoSketchScreen(vm: JulietViewModel) {
    val ctx = LocalContext.current
    val p = LocalPal.current
    val scope = rememberCoroutineScope()

    var sourceUri by remember { mutableStateOf<Uri?>(null) }
    var sourceBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var sketchBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var selectedStyle by remember { mutableStateOf(SketchStyle.Pencil) }
    var blurRadius by remember { mutableFloatStateOf(6f) }
    var contrast by remember { mutableFloatStateOf(1.1f) }
    var isProcessing by remember { mutableStateOf(false) }
    var showOriginal by remember { mutableStateOf(false) }
    var cachedUri by remember { mutableStateOf<Uri?>(null) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            sourceUri = uri
            sketchBitmap = null
            cachedUri = null
            scope.launch {
                isProcessing = true
                val bmp = SketchConverter.loadBitmapFromUri(ctx, uri)
                sourceBitmap = bmp
                if (bmp != null) {
                    val res: Bitmap = if (selectedStyle == SketchStyle.AiSketch) {
                        val key = vm.geminiKey()
                        if (key.isNotBlank()) {
                            val aiRes = vm.generateAiSketch(bmp)
                            val aiBmp = aiRes.getOrNull()
                            if (aiBmp != null) {
                                aiBmp
                            } else {
                                val err = aiRes.exceptionOrNull()?.message ?: "Model error"
                                vm.toast = "AI model note: $err. Applied artistic sketch."
                                SketchConverter.processSketch(bmp, SketchStyle.AiSketch, blurRadius.toInt(), contrast)
                            }
                        } else {
                            vm.toast = "Gemini key not configured. Applied artistic sketch."
                            SketchConverter.processSketch(bmp, SketchStyle.AiSketch, blurRadius.toInt(), contrast)
                        }
                    } else {
                        SketchConverter.processSketch(bmp, selectedStyle, blurRadius.toInt(), contrast)
                    }
                    sketchBitmap = res
                    cachedUri = SketchConverter.saveBitmapToCache(ctx, res)
                }
                isProcessing = false
            }
        }
    }

    fun reprocess() {
        val src = sourceBitmap ?: return
        scope.launch {
            isProcessing = true
            val res: Bitmap = if (selectedStyle == SketchStyle.AiSketch) {
                val key = vm.geminiKey()
                if (key.isNotBlank()) {
                    val aiRes = vm.generateAiSketch(src)
                    val aiBmp = aiRes.getOrNull()
                    if (aiBmp != null) {
                        aiBmp
                    } else {
                        val err = aiRes.exceptionOrNull()?.message ?: "Model error"
                        vm.toast = "AI model note: $err. Applied artistic sketch."
                        SketchConverter.processSketch(src, SketchStyle.AiSketch, blurRadius.toInt(), contrast)
                    }
                } else {
                    vm.toast = "Gemini key not configured. Applied artistic sketch."
                    SketchConverter.processSketch(src, SketchStyle.AiSketch, blurRadius.toInt(), contrast)
                }
            } else {
                SketchConverter.processSketch(src, selectedStyle, blurRadius.toInt(), contrast)
            }
            sketchBitmap = res
            cachedUri = SketchConverter.saveBitmapToCache(ctx, res)
            isProcessing = false
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(bottom = 16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Top App Bar
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(p.card)
                    .clickable { vm.back() },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back", tint = p.text)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    "Photo Sketch Studio",
                    color = p.text,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Turn any picture into handcrafted artwork",
                    color = p.mu,
                    fontSize = 12.sp
                )
            }
            Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(J.Tile)
                    .clickable {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.AddPhotoAlternate, "Upload Photo", tint = androidx.compose.ui.graphics.Color.White)
            }
        }

        // Image Preview Area
        Box(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .height(320.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(p.card)
                .border(1.dp, p.border, RoundedCornerShape(24.dp)),
            contentAlignment = Alignment.Center
        ) {
            val displayBitmap = if (showOriginal) sourceBitmap else (sketchBitmap ?: sourceBitmap)

            if (displayBitmap != null) {
                Image(
                    bitmap = displayBitmap.asImageBitmap(),
                    contentDescription = "Sketch Preview",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit
                )

                // Before / After Toggle overlay
                if (sketchBitmap != null && sourceBitmap != null) {
                    Box(
                        Modifier
                            .align(Alignment.BottomEnd)
                            .padding(12.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(p.bg.copy(alpha = 0.85f))
                            .border(1.dp, p.border, RoundedCornerShape(16.dp))
                            .clickable { showOriginal = !showOriginal }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            if (showOriginal) "Original (Tap for Sketch)" else "Sketch (Tap for Original)",
                            color = J.Red,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            } else {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .clickable {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        }
                        .padding(24.dp)
                ) {
                    Box(
                        Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(p.card2),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Rounded.AddPhotoAlternate,
                            contentDescription = "Upload",
                            tint = J.Red,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                    Spacer(Modifier.height(14.dp))
                    Text(
                        "Upload or Select a Photo",
                        color = p.text,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Tap to browse your device gallery\nSupports Portraits, Landscapes, Objects & Anime",
                        color = p.mu,
                        fontSize = 13.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }

            if (isProcessing) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(p.bg.copy(alpha = 0.7f)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = J.Red)
                        Spacer(Modifier.height(12.dp))
                        Text(if (selectedStyle == SketchStyle.AiSketch) "Generating AI Sketch with Gemini…" else "Creating sketch…", color = p.text, fontSize = 14.sp)
                    }
                }
            }
        }

        // Upload Button (Always Visible)
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = {
                    photoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("upload_photo_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = J.Red),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Rounded.PhotoLibrary, "Gallery", Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text(if (sourceBitmap == null) "Select Photo from Gallery" else "Change Photo")
            }
        }

        // Style Selector Chips
        Spacer(Modifier.height(10.dp))
        Text(
            "ARTISTIC STYLES",
            color = p.mu,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SketchStyle.values().forEach { style ->
                val isSel = style == selectedStyle
                val chipSh = RoundedCornerShape(20.dp)
                Box(
                    Modifier
                        .clip(chipSh)
                        .background(if (isSel) J.Red else p.card)
                        .border(1.dp, if (isSel) J.Red else p.border, chipSh)
                        .clickable {
                            selectedStyle = style
                            reprocess()
                        }
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Text(
                        style.label,
                        color = if (isSel) androidx.compose.ui.graphics.Color.White else p.text,
                        fontSize = 14.sp,
                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }

        // Sliders for Fine-Tuning
        AnimatedVisibility(sourceBitmap != null) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(p.card)
                    .border(1.dp, p.border, RoundedCornerShape(20.dp))
                    .padding(16.dp)
            ) {
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                    Text("Pencil Shading / Softness", color = p.text, fontSize = 14.sp)
                    Text("${blurRadius.toInt()} px", color = J.Red, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = blurRadius,
                    onValueChange = { blurRadius = it },
                    onValueChangeFinished = { reprocess() },
                    valueRange = 2f..16f,
                    steps = 14,
                    colors = SliderDefaults.colors(thumbColor = J.Red, activeTrackColor = J.Red)
                )

                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                    Text("Line Contrast & Depth", color = p.text, fontSize = 14.sp)
                    Text(String.format("%.1fx", contrast), color = J.Red, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = contrast,
                    onValueChange = { contrast = it },
                    onValueChangeFinished = { reprocess() },
                    valueRange = 0.6f..2.0f,
                    colors = SliderDefaults.colors(thumbColor = J.Red, activeTrackColor = J.Red)
                )
            }
        }

        // Action Buttons: Save, Share, Send to Juliet Chat
        AnimatedVisibility(sketchBitmap != null) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Save to Gallery
                    Button(
                        onClick = {
                            val bmp = sketchBitmap ?: return@Button
                            scope.launch {
                                val uri = SketchConverter.saveBitmapToGallery(ctx, bmp, "Juliet Sketch")
                                vm.toast = if (uri != null) "Sketch saved to Pictures/JulietSketches ✔" else "Failed to save to gallery"
                            }
                        },
                        modifier = Modifier.weight(1f).height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = p.card2),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(Icons.Rounded.SaveAlt, "Save", Modifier.size(18.dp), tint = p.text)
                        Spacer(Modifier.width(8.dp))
                        Text("Save to Gallery", color = p.text, fontSize = 13.sp)
                    }

                    // Share
                    Button(
                        onClick = {
                            val uri = cachedUri ?: return@Button
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "image/jpeg"
                                putExtra(Intent.EXTRA_STREAM, uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            ctx.startActivity(Intent.createChooser(shareIntent, "Share Juliet Sketch"))
                        },
                        modifier = Modifier.weight(1f).height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = p.card2),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(Icons.Rounded.Share, "Share", Modifier.size(18.dp), tint = p.text)
                        Spacer(Modifier.width(8.dp))
                        Text("Share Sketch", color = p.text, fontSize = 13.sp)
                    }
                }

                // Send to Chat with Juliet
                Button(
                    onClick = {
                        val uri = cachedUri ?: return@Button
                        vm.sendImageChat(uri, "Turned my photo into a ${selectedStyle.label}!", isSketch = true)
                        vm.navigate(Screen.Chat)
                    },
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = J.Red),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Rounded.Chat, "Chat", Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Send to Juliet Chat", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
