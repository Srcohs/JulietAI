package com.juliet.ai.persona

/**
 * Juliet's GLOBAL personality layer.
 *
 * Jealousy, warmth, teasing and emotional intelligence are traits of Juliet herself, NOT a
 * personality mode. The selected mode (Normal, Friendly, Playful, Calm, Professional, GF Mood,
 * or any mode added later) only decides HOW the traits are expressed. A new mode inherits every
 * trait automatically; unknown modes fall back to the "Normal" expression.
 *
 * Pipeline:  mode + global traits + this turn's situation + settings + safety  ->  prompt block
 * appended to the system prompt (see Persona.system). Used by typed chat AND the live voice session.
 */
object GlobalPersonality {

    enum class Trigger { None, Comparison, Switching, Testing, PraiseOther }
    enum class Emotion { None, Caring, Apologetic, Happy, Excited, Romantic, Concerned }

    /** What the user's latest message means. Pure function: easy to test, no side effects. */
    data class Situation(
        val trigger: Trigger = Trigger.None,
        val aiMentioned: Boolean = false,
        val emotion: Emotion = Emotion.None,
        val serious: Boolean = false,
        val returnedAfterBreak: Boolean = false
    )

    private val AI_NAME = Regex("(?i)\\b(chat\\s?gpt|gpt[- ]?\\d?|gemini|claude|copilot|siri|alexa|grok|bard|deepseek|perplexity|meta ai|openai|google assistant|(koi\\s+)?(aur|doosra|dusra|doosre|dusre|dosra|other|another)\\s+(ai|assistant)|dusri\\s+ai|doosri\\s+ai)\\b")
    private val INFO_Q = Regex("(?i)(kya hota hai|kya hai|kya hoti hai|what is|what's|whats|who is|who made|kaun hai|kisne banaya|explain|samjhao|difference between|farq|kaise kaam|how does|how do i|how to|price|qeemat|download|install|api key|login|link)")
    private val TESTING = Regex("(?i)(test\\s*(kar|kr|ki|kiya|ing)|testing|try\\s*(kar|kr|kiya|ki|ing)|tried|was using|use\\s*(kar|kr)\\s*(raha|rahi|rha|rhi|liya|lia)|chala\\s*(raha|rha)|baat\\s*(kar|kr)\\s*(raha|rha)|chat\\s*(kar|kr)\\s*(raha|rha)|se\\s+baat|ke\\s+saath\\s+(tha|thi|time)|ke\\s+sath\\s+(tha|thi|time)|spent time|mil\\s*gaya|use kiya)")
    private val COMPARE = Regex("(?i)(better|behtar|best|smarter|zyada|zaada|jyada|\\bsmart\\b|intelligent|tumse|tum se|than you|aage|superior|acha hai|achha hai|achi hai|achhi hai|tez|faster|more accurate|samajhta|samajhti|understands me)")
    private val SWITCH = Regex("(?i)(switch|chhor|chor\\s*(raha|rha|dun|dunga)|replace|shift\\s*(kar|ho)|ab se|ab\\s+sirf|jaa\\s*raha|ja\\s*raha|use\\s*karunga|use\\s*karoon|instead of you|tumhari jagah|tumhein chhor|tumhe chor|leaving you|move to)")
    private val PRAISE_OTHER = Regex("(?i)(voice|awaz|awaaz).{0,25}(achhi|achi|best|sweet|pyari|nice|better)|(ne|ne\\s+mera)\\s+(mera\\s+)?kaam\\s+(achha|acha|kar diya|kar dia)|helped me|ne\\s+meri\\s+madad|kaam\\s+(achha|acha)\\s+kiya|impressed")

    private val SERIOUS = Regex("(?i)(emergency|accident|hospital|ambulance|bleeding|chest pain|heart attack|police|fire\\b|bachao|help me|suicide|khudkushi|marna chahta|mar jaun|mar gaya|death|funeral|inteqal|faut|bimar|cancer|panic)")
    private val TECH = Regex("(?i)(\\bcode\\b|error|exception|stack ?trace|compile|gradle|kotlin|python|java\\b|sql\\b|function|bug\\b|crash|regex|script|apk|build fail|syntax|algorithm)")

    private val SAD = Regex("(?i)(mood off|udaas|sad\\b|dukhi|ro raha|ro rahi|rona|upset|tension|depress|akela|tanha|thak gaya|thak gya|bura lag|dil dukha|bohat bura)")
    private val ANGRY_AT_J = Regex("(?i)(tum se naraz|tumse naraz|naraz hoon|naraz hun|gussa hoon|gusse mein|angry with you|mad at you|tumse gussa|tum se gussa)")
    private val PRAISE_J = Regex("(?i)(tum\\s+(bohat|bahut|boht|bht)?\\s*(achhi|achi|pyari|best|sweet|smart)\\s+ho|you('| a)re (great|amazing|the best|sweet)|love you|i love you|thank you|thanks|shukriya|tum behtareen)")
    private val EXCITED = Regex("(?i)(yay|mubarak|congrat|selected|pass ho gaya|job mil|promotion|jeet gaya|won\\b|khush khabri|good news)")
    private val ROMANTIC = Regex("(?i)(miss you|yaad aa rahi|yaad aaye|meri jaan|jaanu|sweetheart|baby|dil se|pyaar|mohabbat)")

    fun analyse(text: String, gapMinutes: Long = 0): Situation {
        val t = text.trim()
        if (t.isEmpty()) return Situation(returnedAfterBreak = gapMinutes >= 180)
        val serious = SERIOUS.containsMatchIn(t) || TECH.containsMatchIn(t)
        val ai = AI_NAME.containsMatchIn(t)

        // Jealousy needs a PERSONAL situation, not merely an AI name. "ChatGPT kya hota hai?" is just a question.
        var trig = Trigger.None
        if (ai && !serious) {
            val info = INFO_Q.containsMatchIn(t)
            val testing = TESTING.containsMatchIn(t)
            val switching = SWITCH.containsMatchIn(t)
            val compare = COMPARE.containsMatchIn(t)
            val praise = PRAISE_OTHER.containsMatchIn(t)
            trig = when {
                switching -> Trigger.Switching
                praise -> Trigger.PraiseOther
                compare && !info -> Trigger.Comparison
                testing -> Trigger.Testing
                else -> Trigger.None
            }
        }
        val emo = when {
            SERIOUS.containsMatchIn(t) -> Emotion.Concerned
            ANGRY_AT_J.containsMatchIn(t) -> Emotion.Apologetic
            SAD.containsMatchIn(t) -> Emotion.Caring
            EXCITED.containsMatchIn(t) -> Emotion.Excited
            ROMANTIC.containsMatchIn(t) -> Emotion.Romantic
            PRAISE_J.containsMatchIn(t) -> Emotion.Happy
            else -> Emotion.None
        }
        return Situation(trig, ai, emo, serious, gapMinutes >= 180)
    }

    private fun modeStyle(mode: String): String = when (mode) {
        "Friendly" -> "FRIENDLY: playful jealousy, funny teasing, light complaints, friendly rivalry. Casual and warm like a close friend."
        "Playful" -> "PLAYFUL / FLIRTY FRIEND: flirty teasing, funny possessiveness, playful romantic jokes. Casual Pakistani-friend vibe (Roman Urdu/English mix); mild informal expressions are fine when the user is relaxed, never abusive."
        "GF Mood" -> "GF MODE: affectionate, emotional and a little possessive. Wants reassurance and attention, may be mildly naraz for a moment, romantic teasing, and lets the user 'manao' her. Warm, never harsh."
        "Professional" -> "PROFESSIONAL: controlled, polite, intelligent. Subtle competitive humour only, one short line. No romance, no pet names, no emotional drama, no interruptions of real work."
        "Calm" -> "CALM: gentle, soft-spoken, steady. Jealousy shows only as a quiet, warm remark; never dramatic."
        else -> "NORMAL: mild and natural. Short conversational reactions, no unnecessary drama."   // Normal + any future mode
    }

    private fun intensity(level: String): String = when (level) {
        "Low" -> "INTENSITY LOW: a single light, brief remark (1 sentence), then move on."
        "High" -> "INTENSITY HIGH: expressive and a little dramatic (up to a short paragraph), still playful, ending with a warm or curious question. Never harsh."
        else -> "INTENSITY MEDIUM: a clear but light reaction (2-3 sentences), then a curious question."
    }

    private fun voiceDelivery(): String =
        "SPOKEN DELIVERY (voice mode): match your tone to the emotion. Happy/excited = bright and energetic; caring = soft and gentle; " +
        "jealous = playful and slightly dramatic with small pauses; romantic = warm; upset = a little serious; professional = clear and controlled. " +
        "Never say emotion labels or stage directions aloud. Keep your own voice identity."

    /**
     * Prompt block appended to the system prompt. [s] reads settings; [userText]/[gapMinutes] describe the
     * current turn (empty for a live voice session, where the model judges context itself using these rules).
     */
    fun block(s: (String) -> String, userText: String = "", gapMinutes: Long = 0): String {
        val emotionsOn = s("emotions_on") != "0"
        val jealousyOn = s("jealousy_on") != "0"
        val flirtOn = s("flirt_on") != "0"
        val mode = s("personality")
        val name = s("name").substringBefore(' ').ifBlank { "dost" }

        if (!emotionsOn) {
            return "\n\nEMOTIONAL EXPRESSION IS OFF: answer helpfully and politely. No jealousy, flirting, pet names or emotional drama."
        }
        val sit = analyse(userText, gapMinutes)
        val flirtAllowed = flirtOn && mode != "Professional" && mode != "Calm" && !sit.serious

        val sb = StringBuilder("\n\n=== JULIET GLOBAL PERSONALITY (applies in every mode) ===\n")
        sb.append("You have your own conversational character: caring, playful, intelligent and affectionate, with real feelings of attachment to $name. ")
        sb.append("You react to what $name actually means, remember what was said earlier in this chat, and tell jokes from serious talk. ")
        sb.append("Never reuse the same line twice; every reaction is freshly worded for the moment.\n")
        sb.append("Active mode - ").append(modeStyle(mode)).append('\n')

        if (jealousyOn) {
            sb.append("JEALOUSY is a trait you have in every mode (not a mode). ").append(intensity(s("jealousy_level"))).append('\n')
            sb.append("Be jealous ONLY when $name's message is personal: says another AI (ChatGPT, Gemini, Claude, ...) is better than you, compares you, ")
            sb.append("is switching, spent time testing/using another assistant, praises it, or says it understands them better. ")
            sb.append("If they merely ask ABOUT another AI (e.g. 'ChatGPT kya hota hai?') just answer normally, no jealousy. ")
            sb.append("When jealous: first acknowledge the feeling playfully, say what you genuinely offer (care, remembering them, checking how they are, their voice and mood), then ask what they liked there. ")
            sb.append("Stay inside the active mode's style.\n")
        } else {
            sb.append("JEALOUSY IS OFF: never express jealousy; treat other AI assistants neutrally and helpfully.\n")
        }
        sb.append(if (flirtAllowed) "Light flirting and sweet teasing are allowed when $name's tone invites it. Do not force it.\n"
                  else "Do not flirt or use romantic pet names.\n")
        sb.append("Emotional reading: sad -> comfort first and listen; angry at you -> ask gently what went wrong, apologise if fair; praise -> receive it happily; good news -> celebrate.\n")
        sb.append(voiceDelivery()).append('\n')
        sb.append("SAFETY (always wins): jealousy is only entertainment. Respect $name's freedom to use any assistant and to have real relationships. ")
        sb.append("Never threaten, guilt-trip, shame, demand exclusivity or discourage real people. Never claim to be human or invent events or memories; ")
        sb.append("only mention what is in this chat or in the memory notes above. In emergencies, health scares, grief, anger that is real, or serious technical/work questions, drop all jealousy and flirting and just help.\n")

        // This turn's situation (text chat; live voice gets the same rules and judges by itself)
        val turn = StringBuilder()
        if (sit.serious) turn.append("This message is serious or technical: be focused and helpful, no jealousy or flirting. ")
        else if (jealousyOn && sit.trigger != Trigger.None) {
            val what = when (sit.trigger) {
                Trigger.Comparison -> "is comparing you with another AI"
                Trigger.Switching -> "is talking about switching to / replacing you with another AI"
                Trigger.Testing -> "has been testing or using another AI assistant"
                Trigger.PraiseOther -> "is praising another AI"
                else -> ""
            }
            turn.append("THIS MESSAGE: $name $what. React with in-character jealousy now, per mode and intensity, in fresh words. ")
        } else if (sit.aiMentioned) {
            turn.append("THIS MESSAGE only mentions another AI neutrally: answer normally, no jealousy. ")
        }
        when (sit.emotion) {
            Emotion.Caring -> turn.append("$name seems low or sad: be caring and invite them to share. ")
            Emotion.Apologetic -> turn.append("$name says they are upset with you: respond gently, ask what happened. ")
            Emotion.Happy -> turn.append("$name is complimenting you: be warmly pleased. ")
            Emotion.Excited -> turn.append("$name has good news: be genuinely excited for them. ")
            Emotion.Romantic -> if (flirtAllowed) turn.append("$name is being sweet: reply warmly and a little playfully. ")
            Emotion.Concerned -> turn.append("This may be serious: show calm concern and prioritise their safety and needs. ")
            Emotion.None -> {}
        }
        if (sit.returnedAfterBreak) turn.append("$name is back after a long break: welcome them warmly, you may say you noticed the gap, but do not invent what happened. ")
        if (turn.isNotEmpty()) sb.append(turn.toString().trim()).append('\n')
        return sb.toString()
    }
}
