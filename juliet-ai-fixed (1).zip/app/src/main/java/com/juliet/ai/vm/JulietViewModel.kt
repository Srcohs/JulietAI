package com.juliet.ai.vm

import android.app.Application
import android.graphics.Bitmap
import android.speech.tts.TextToSpeech
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.juliet.ai.BuildConfig
import com.juliet.ai.ann.Announcer
import com.juliet.ai.data.*
import com.juliet.ai.net.GeminiVisionClient
import com.juliet.ai.net.GroqClient
import com.juliet.ai.phone.AudioRoute
import com.juliet.ai.phone.PhoneActions
import com.juliet.ai.reminders.ReminderManager
import com.juliet.ai.screen.JulietAccessibilityService
import com.juliet.ai.screen.JulietScreenCaptureService
import com.juliet.ai.screen.SharingState
import com.juliet.ai.voice.GeminiLive
import com.juliet.ai.wa.AutoReply
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private const val GREETING = "I can chat, answer questions, summarize your messages, manage smart reminders, and help you with your phone. Ask me anything!"
val DEFAULTS = mapOf(
    "theme" to "System", "personality" to "Normal", "jealousy_on" to "1", "jealousy_level" to "Medium", "emotions_on" to "1", "flirt_on" to "1", "memory_on" to "1", "last_active_ts" to "0", "language" to "Auto", "style" to "Balanced",
    "voice" to "Kore", "model" to "gemini-3.8-live", "volume" to "80",
    "listen" to "1", "reduce" to "0", "orb" to "0", "name" to "Ahsan Raza",
    "wa_auto" to "0", "wa_mode" to "category", "wa_unknown" to "silent", "wa_consent" to "0", "ann_on" to "0", "ann_calls" to "1", "ann_wa" to "1", "ann_sms" to "1",
    "ann_apps" to "0", "ann_content" to "0", "ann_privacy" to "1", "ann_repeat" to "0", "ann_pkgs" to "", "ann_excl" to "", "ann_vol" to "100",
    "screen_control_full" to "0", "screen_control_session" to "0",
    "voice_lock_enabled" to "0", "wake_word_enabled" to "1",
    "wake_word_sensitivity" to "Normal", "voice_verification_threshold" to "70",
    "voice_lock_strikes" to "3", "background_listen" to "0"
)

/** Tried in this order if the selected model is rejected. Google retires/renames Live models often. */
val VOICE_MODELS = listOf("gemini-3.8-live", "gemini-3.1-flash-live-preview", "gemini-2.5-flash-native-audio-preview-12-2025")

class JulietViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = Prefs(app)
    val knowledge = Knowledge(prefs)
    val phone = PhoneActions(app, prefs, knowledge)
    val summarizer = JulietSummarizer(app, prefs)
    val reminderManager = ReminderManager(app, prefs)
    val memory = com.juliet.ai.data.mem.MemoryManager(app)
    val voiceEnrollment = com.juliet.ai.voice.VoiceEnrollmentManager(app, prefs)
    private val groq = GroqClient()

    val vision = GeminiVisionClient()

    suspend fun generateAiSketch(bitmap: Bitmap, stylePrompt: String = ""): Result<Bitmap> {
        val key = geminiKey()
        return if (stylePrompt.isNotBlank()) {
            vision.generateAiSketch(key, bitmap, stylePrompt)
        } else {
            vision.generateAiSketch(key, bitmap)
        }
    }

    val live = GeminiLive(phone).also { it.gate = com.juliet.ai.voice.SpeakerGate(voiceEnrollment, prefs).also { g ->
        g.onReject = { n, max, why -> toast = "Unknown voice blocked ($n/$max)" }
        g.onLockout = { if (!com.juliet.ai.screen.PhoneLocker.lockNow(app)) toast = "Unknown speaker! Enable Accessibility to allow locking" }
    } }
    private var tts: TextToSpeech? = TextToSpeech(app) {}
    private var autoDone = false
    private var curId = System.currentTimeMillis()

    var stack by mutableStateOf(listOf(Screen.Home)); private set
    val screen: Screen get() = stack.last()
    val messages = mutableStateListOf<ChatMsg>()
    val convs = mutableStateListOf<Conv>()
    val st = mutableStateMapOf<String, String>()
    var busy by mutableStateOf(false); private set
    var draft by mutableStateOf("")
    var toast by mutableStateOf<String?>(null)
    var keyTick by mutableIntStateOf(0)
    var permTick by mutableIntStateOf(0)

    val voiceAudioLevel = live.audioLevel
    val orbMode: Int
        get() = when (live.state.value) {
            VoiceState.Listening, VoiceState.Connecting -> 1
            VoiceState.Speaking -> 2
            VoiceState.Idle -> 0
        }

    val kEntries = mutableStateListOf<KEntry>()
    var kStatus by mutableStateOf("")
    var testResult by mutableStateOf("")

    // Juliet Summaries state
    val summaries = mutableStateListOf<JulietSummary>()
    var isSummarizing by mutableStateOf(false)
    var latestSummary by mutableStateOf<JulietSummary?>(null)

    // Smart Reminders state
    val reminders = mutableStateListOf<SmartReminder>()

    // Notes, Code & Website Builder state
    val snippets = mutableStateListOf<SavedSnippet>()
    var isCodeGenerating by mutableStateOf(false)
    var isWebsiteGenerating by mutableStateOf(false)

    // Screen control & sharing state
    val sharingState = JulietScreenCaptureService.sharingState
        .stateIn(viewModelScope, SharingStarted.Eagerly, SharingState.Inactive)
    val sharingError = JulietScreenCaptureService.errorMessage
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)
    var visionAnswer by mutableStateOf<String?>(null)
    var isVisionBusy by mutableStateOf(false)

    // Audio & Calling routing state
    var currentAudioRoute by mutableStateOf(phone.audio.getCurrentRoute())
    var currentCallVolume by mutableIntStateOf(phone.audio.getCallVolume())

    // Voice Enrollment & Speaker Recognition
    val voiceProfiles = mutableStateListOf<VoiceProfile>()
    var isEnrollingVoice by mutableStateOf(false)
    var enrollmentStep by mutableIntStateOf(0)
    var enrollmentAudioLevel by mutableFloatStateOf(0f)
    var isTestingVoice by mutableStateOf(false)
    var testVerificationResult by mutableStateOf<SpeakerVerificationResult?>(null)
    val enrollmentSamples = mutableListOf<List<Float>>()

    init {
        phone.onSetting = { k, v ->
            viewModelScope.launch {
                if (k == "knowledge_changed") reloadK() else set(k, v)
            }
        }
        phone.onNavigate = { navigate(it) }
        phone.onInspectScreen = { query, cb ->
            viewModelScope.launch {
                val shouldSpeakTts = (live.state.value == VoiceState.Idle)
                askScreenVision(query, speakOutput = shouldSpeakTts, callback = cb)
            }
        }
        phone.onSummarize = { target, contact, count, today, cb ->
            val shouldSpeakTts = (live.state.value == VoiceState.Idle)
            generateSummary(target, contact, count, today, speakResult = shouldSpeakTts, callback = cb)
        }
        phone.onSetReminder = { title, timeDesc, rec ->
            createReminderFromNaturalLanguage("$title $timeDesc", rec)
        }

        kEntries.addAll(knowledge.all())
        DEFAULTS.forEach { (k, v) -> st[k] = prefs.get(k, v) }
        convs.addAll(prefs.loadConvs())
        summaries.addAll(prefs.loadSummaries())
        reminders.addAll(prefs.loadReminders())
        snippets.addAll(prefs.loadSnippets())
        voiceProfiles.addAll(prefs.loadVoiceProfiles())
        messages += ChatMsg("assistant", GREETING)
        viewModelScope.launch { live.error.collect { if (it != null) toast = it } }
    }


    // ---- memory & auto-reply ----
    private fun reloadK() { kEntries.clear(); kEntries.addAll(knowledge.all()) }
    fun addKnowledge(t: String): Boolean {
        val e = knowledge.add(t); reloadK()
        kStatus = if (e != null) "Saved ✔" else "Not saved (empty, duplicate or storage problem)"
        return e != null
    }
    fun updateKnowledge(id: Long, t: String) { kStatus = if (knowledge.update(id, t)) "Updated ✔" else "Update failed"; reloadK() }
    fun deleteKnowledge(id: Long) { kStatus = if (knowledge.delete(id)) "Deleted ✔" else "Delete failed"; reloadK() }
    fun toggleKnowledge(id: Long, on: Boolean) { knowledge.setEnabled(id, on); reloadK() }
    fun testReply(msg: String, contact: String = "Test contact") {
        if (msg.isBlank()) return
        testResult = "Thinking…"
        viewModelScope.launch { testResult = AutoReply(getApplication(), prefs).preview(contact, msg) }
    }
    fun setAutoReply(on: Boolean) { if (on) { set("wa_consent", "1"); set("wa_auto", "1") } else set("wa_auto", "0") }

    // ---- Juliet Summaries ----
    fun reloadSummaries() {
        summaries.clear()
        summaries.addAll(prefs.loadSummaries())
    }

    fun generateSummary(
        target: String = "whatsapp",
        contact: String? = null,
        count: Int = 10,
        onlyToday: Boolean = false,
        speakResult: Boolean = false,
        callback: ((String) -> Unit)? = null
    ) {
        isSummarizing = true
        viewModelScope.launch {
            val result = summarizer.generateSummary(target, contact, count, onlyToday)
            isSummarizing = false
            result.onSuccess { summary ->
                latestSummary = summary
                reloadSummaries()
                val text = buildString {
                    appendLine("📋 ${summary.title}")
                    if (summary.keyPoints.isNotEmpty()) {
                        appendLine("\n📌 KEY POINTS:")
                        summary.keyPoints.forEach { appendLine("• $it") }
                    }
                    if (summary.decisions.isNotEmpty()) {
                        appendLine("\n🤝 DECISIONS:")
                        summary.decisions.forEach { appendLine("• $it") }
                    }
                    if (summary.actionItems.isNotEmpty()) {
                        appendLine("\n⚡ ACTION ITEMS:")
                        summary.actionItems.forEach { appendLine("• $it") }
                    }
                    if (summary.privacyApplied) {
                        appendLine("\n🛡 (Privacy Mode: Sensitive content masked)")
                    }
                }
                callback?.invoke(text)
                if (speakResult) {
                    val spoken = "Here is your summary. " +
                        (summary.keyPoints.firstOrNull()?.let { "Key point: $it. " } ?: "") +
                        (summary.actionItems.firstOrNull()?.let { "Action item: $it." } ?: "")
                    speak(spoken)
                }
            }.onFailure { err ->
                val fail = "Could not generate summary: ${err.message}"
                toast = fail
                callback?.invoke(fail)
            }
        }
    }

    fun deleteSummary(id: Long) {
        val filtered = prefs.loadSummaries().filter { it.id != id }
        prefs.saveSummaries(filtered)
        reloadSummaries()
        if (latestSummary?.id == id) latestSummary = null
        toast = "Summary deleted"
    }

    // ---- Smart Reminders ----
    fun reloadReminders() {
        reminders.clear()
        reminders.addAll(prefs.loadReminders())
    }

    fun createReminder(
        title: String,
        dueTime: Long,
        recurrence: String = "Once",
        notes: String = ""
    ): SmartReminder {
        val r = reminderManager.createReminder(title, dueTime, recurrence, notes)
        reloadReminders()
        toast = "Reminder set for ${reminderManager.formatDueTime(dueTime)}"
        return r
    }

    fun createReminderFromNaturalLanguage(text: String, recurrenceOverride: String = "Once"): String {
        val parsed = reminderManager.parseNaturalLanguageReminder(text)
            ?: return "Please specify what and when to remind you (e.g. 'call Mom tomorrow at 2 PM')."
        val r = parsed.copy(recurrence = if (recurrenceOverride != "Once") recurrenceOverride else parsed.recurrence)
        reminderManager.createReminder(r.title, r.dueTimeMillis, r.recurrence, r.notes)
        reloadReminders()
        val dueStr = reminderManager.formatDueTime(r.dueTimeMillis)
        val recStr = if (r.recurrence != "Once") " (${r.recurrence})" else ""
        val ans = "Reminder set: \"${r.title}\" for $dueStr$recStr."
        toast = ans
        return ans
    }

    fun toggleReminder(id: Long) {
        val completed = reminderManager.toggleComplete(id)
        reloadReminders()
        toast = if (completed) "Reminder marked completed ✔" else "Reminder reopened"
    }

    fun updateReminder(r: SmartReminder) {
        reminderManager.updateReminder(r)
        reloadReminders()
        toast = "Reminder updated"
    }

    fun deleteReminder(id: Long) {
        reminderManager.deleteReminder(id)
        reloadReminders()
        toast = "Reminder deleted"
    }

    fun acceptProactiveReminder(r: SmartReminder) {
        reminderManager.createReminder(r.title, r.dueTimeMillis, r.recurrence, r.notes, suggested = false)
        reloadReminders()
        toast = "Reminder set: ${r.title}"
    }

    // ---- Calling Audio Route & Volume Control ----
    fun refreshAudioState() {
        currentAudioRoute = phone.audio.getCurrentRoute()
        currentCallVolume = phone.audio.getCallVolume()
    }

    fun setSpeaker(on: Boolean) {
        val ok = phone.audio.setSpeaker(on)
        refreshAudioState()
        toast = if (ok) "Speaker turned ${if (on) "on" else "off"}" else "Failed to switch speaker"
    }

    fun setAudioRoute(route: AudioRoute) {
        val ok = phone.audio.setRoute(route)
        refreshAudioState()
        toast = if (ok) "Audio routed to ${route.label}" else "Audio route not available"
    }

    fun setCallVolume(level: Int) {
        phone.audio.setCallVolume(level)
        refreshAudioState()
    }

    fun adjustCallVolume(up: Boolean) {
        phone.audio.adjustCallVolume(up)
        refreshAudioState()
    }

    // ---- Screen Control & Live Screen Sharing ----
    fun isAccessibilityActive(): Boolean = JulietAccessibilityService.isRunning()
    fun isFullScreenControlEnabled(): Boolean = s("screen_control_full") == "1"
    fun isControlSessionActive(): Boolean = s("screen_control_session") == "1"

    fun toggleFullScreenControl(on: Boolean) {
        set("screen_control_full", if (on) "1" else "0")
        toast = if (on) "Full Screen Control enabled" else "Full Screen Control disabled"
    }

    fun startControlSession() {
        set("screen_control_session", "1")
        toast = "Screen control session started"
    }

    fun stopControlSession() {
        set("screen_control_session", "0")
        JulietScreenCaptureService.instance?.stopCapture()
        toast = "Screen control session stopped"
    }

    fun pauseScreenSharing() {
        JulietScreenCaptureService.instance?.pauseCapture()
        toast = "Screen sharing paused"
    }

    fun resumeScreenSharing() {
        JulietScreenCaptureService.instance?.resumeCapture()
        toast = "Screen sharing resumed"
    }

    fun stopScreenSharing() {
        JulietScreenCaptureService.instance?.stopCapture()
        toast = "Screen sharing stopped"
    }

    fun askScreenVision(question: String, speakOutput: Boolean = false, callback: ((String) -> Unit)? = null) {
        val key = geminiKey()
        if (key.isBlank()) {
            val err = "Please add a Gemini key in Settings > Connections for Live Screen Understanding."
            toast = err
            callback?.invoke(err)
            return
        }

        if (sharingState.value != SharingState.Sharing) {
            val a11yText = JulietAccessibilityService.instance?.dumpScreenText()
            if (!a11yText.isNullOrBlank() && !a11yText.startsWith("(")) {
                val ans = "Live screen sharing is not active, but from the interface structure I see:\n$a11yText"
                visionAnswer = ans
                callback?.invoke(ans)
                if (speakOutput) speak(ans)
                return
            }
            val err = "Screen sharing is currently inactive or paused. Please start screen sharing so I can see your screen."
            toast = err
            callback?.invoke(err)
            return
        }

        val frame = JulietScreenCaptureService.getLatestFrame()
        if (frame == null) {
            val err = "Could not capture current screen frame. Please verify screen sharing is active."
            toast = err
            callback?.invoke(err)
            return
        }

        isVisionBusy = true
        val a11ySummary = JulietAccessibilityService.instance?.dumpScreenText() ?: ""

        viewModelScope.launch {
            val result = vision.analyzeScreen(key, frame, question, a11ySummary)
            isVisionBusy = false
            val text = result.getOrElse { "Screen analysis failed: ${it.message}" }
            visionAnswer = text
            callback?.invoke(text)
            if (speakOutput) speak(text)
        }
    }

    // ---- settings ----
    fun s(k: String): String = st[k] ?: DEFAULTS[k] ?: ""
    fun set(k: String, v: String) { st[k] = v; prefs.put(k, v) }
    fun cycle(k: String, opts: List<String>) { set(k, opts[(opts.indexOf(s(k)) + 1) % opts.size]) }

    // ---- navigation ----
    private val tabs = setOf(Screen.Home, Screen.Chat, Screen.History, Screen.Settings)
    fun navigate(s: Screen) { stack = if (s in tabs) listOf(s) else if (s == screen) stack else stack + s }
    fun back() { stack = if (stack.size > 1) stack.dropLast(1) else listOf(Screen.Home) }

    // ---- keys ----
    fun geminiKey(): String = prefs.get("k_gemini").ifBlank { BuildConfig.DEFAULT_GEMINI_KEY }
    private fun groqKeys(): List<String> =
        prefs.get("k_groq").ifBlank { BuildConfig.DEFAULT_GROQ_KEYS }.split(",").map { it.trim() }.filter { it.isNotEmpty() }
    fun geminiStatus(): String { keyTick; return status(prefs.get("k_gemini"), BuildConfig.DEFAULT_GEMINI_KEY) }
    fun groqStatus(): String { keyTick; return status(prefs.get("k_groq"), BuildConfig.DEFAULT_GROQ_KEYS) }
    private fun status(user: String, def: String) = when {
        user.isNotBlank() -> "✔ Your key saved"
        def.isNotBlank() -> "✔ Using Juliet's key"
        else -> "No key yet"
    }
    fun saveGemini(v: String) { prefs.put("k_gemini", v.trim()); keyTick++; toast = "Gemini key saved on this phone" }
    fun saveGroq(v: String) { prefs.put("k_groq", v.trim()); keyTick++; toast = "Groq keys saved on this phone" }

    // ---- typed chat ----
    fun sendText(raw: String) {
        val text = raw.trim(); if (text.isEmpty() || busy) return
        val gapMin = takeGapMinutes()
        messages += ChatMsg("user", text); draft = ""
        if (handleMemoryReply(text)) return

        // Check if user is asking for a summary
        val waSummaryMatch = Regex("^(?:summarize|summary\\s+of)\\s+(?:my\\s+)?(?:last\\s+(\\d+)\\s+)?whatsapp(?:\\s+messages?)?(?:\\s+from\\s+(.+))?$", RegexOption.IGNORE_CASE).find(text)
        if (waSummaryMatch != null) {
            val count = waSummaryMatch.groupValues[1].toIntOrNull() ?: 10
            val contact = waSummaryMatch.groupValues[2].takeIf { it.isNotBlank() }
            busy = true
            generateSummary("whatsapp", contact, count, false) { res ->
                busy = false
                messages += ChatMsg("assistant", res)
                persist()
            }
            return
        }

        val notifSummaryMatch = Regex("^(?:what\\s+were\\s+the\\s+main\\s+points\\s+from\\s+my\\s+notifications(?:\\s+today)?|summarize\\s+(?:my\\s+)?notifications(?:\\s+today)?|notification\\s+summary).*$", RegexOption.IGNORE_CASE).find(text)
        if (notifSummaryMatch != null) {
            val onlyToday = text.contains("today", ignoreCase = true)
            busy = true
            generateSummary("notifications", null, 15, onlyToday) { res ->
                busy = false
                messages += ChatMsg("assistant", res)
                persist()
            }
            return
        }

        // Check if user is asking for a reminder directly
        val remindMatch = Regex("^(?:remind\\s+me|set\\s+(?:a\\s+)?reminder)\\s+(?:to|about)?\\s*(.+)$", RegexOption.IGNORE_CASE).find(text)
        if (remindMatch != null) {
            val res = createReminderFromNaturalLanguage(remindMatch.groupValues[1])
            messages += ChatMsg("assistant", res)
            persist()
            return
        }

        // Check if user is asking about the screen
        val screenQuery = Regex("^(?:what(?:'s|\\s+is)\\s+showing\\s+on\\s+my\\s+screen|explain\\s+this\\s+screen|what\\s+is\\s+on\\s+my\\s+screen|screen\\s+par\\s+kya\\s+hai|help\\s+me\\s+with\\s+this\\s+screen|what\\s+button\\s+should\\s+i\\s+press|find\\s+the\\s+setting).*$", RegexOption.IGNORE_CASE)
        if (screenQuery.containsMatchIn(text)) {
            busy = true
            askScreenVision(text) { answer ->
                busy = false
                messages += ChatMsg("assistant", answer)
                persist()
            }
            return
        }

        phone.route(text)?.let {
            messages += ChatMsg("assistant", it)
            persist()
            return
        }

        // Check proactive reminder opportunities in conversation
        val proactive = reminderManager.detectProactiveReminder(text)

        busy = true
        viewModelScope.launch {
            val mem = if (memOn()) try { memory.contextFor(text) } catch (_: Exception) { "" } else ""
            val sys = Persona.system({ s(it) }, text, gapMin) + if (mem.isBlank()) "" else "\n\n$mem"
            val r = groq.chat(groqKeys(), sys, messages.map { GroqClient.Msg(it.role, it.text) })
            busy = false
            val replyText = r.getOrElse { "Sorry, I couldn't reach Groq: ${it.message}" }
            messages += ChatMsg("assistant", replyText, proactiveReminder = proactive)
            persist()
            learnFrom(text, speak = false)
        }
    }

    /** Minutes since the user last talked to Juliet (0 on first run); also stamps "now". */
    private fun takeGapMinutes(): Long {
        val now = System.currentTimeMillis()
        val last = s("last_active_ts").toLongOrNull() ?: 0L
        set("last_active_ts", now.toString())
        return if (last <= 0L) 0L else (now - last) / 60_000L
    }

    private fun memOn() = s("memory_on") != "0"

    // ---- memory (Stage 2) ----
    private val pendingAsks = ArrayDeque<com.juliet.ai.data.mem.MemoryManager.Ask>()
    private var pendingForget: List<com.juliet.ai.data.mem.FactEntity> = emptyList()
    private val yesRe = Regex("^(haan|han|ha|yes|yep|yeah|ok|okay|theek hai|kar do|kar dein|zaroor|sure)\\b", RegexOption.IGNORE_CASE)
    private val noRe = Regex("^(nahi|nahin|na|no|nope|mat|rehne do)\\b", RegexOption.IGNORE_CASE)

    private fun say(t: String) { messages += ChatMsg("assistant", t); persist() }

    /** Learns from what the user said. Safe facts are saved silently; the rest becomes a yes/no question in chat. */
    private fun learnFrom(text: String, speak: Boolean) {
        if (!memOn()) return   // Memory switched off in Settings: learn and remember nothing
        viewModelScope.launch {
            try {
                memory.recordMood(text, if (speak) "voice" else "text")
                com.juliet.ai.data.mem.FactExtractor.detectForget(text)?.let { what ->
                    val hits = memory.findToForget(what)
                    if (hits.isNotEmpty()) {
                        pendingAsks.clear(); pendingForget = hits
                        say("Ye bhool jaun? " + hits.joinToString("; ") { it.value } + " (haan / nahi)")
                    }
                    return@launch
                }
                val r = memory.learn(text, s("name"))
                if (r.asks.isNotEmpty() && !speak) {
                    pendingAsks.clear(); pendingAsks.addAll(r.asks)
                    say(pendingAsks.first().question + " (haan / nahi)")
                }
            } catch (_: Exception) { /* memory is best-effort, never breaks chat */ }
        }
    }

    /** Handles "haan/nahi" for a pending memory question. Returns true if the message was consumed. */
    private fun handleMemoryReply(text: String): Boolean {
        if (pendingAsks.isEmpty() && pendingForget.isEmpty()) return false
        val yes = yesRe.containsMatchIn(text.trim()); val no = noRe.containsMatchIn(text.trim())
        if (!yes && !no) { pendingAsks.clear(); pendingForget = emptyList(); return false }   // user moved on
        viewModelScope.launch {
            try {
                if (pendingForget.isNotEmpty()) {
                    if (yes) { pendingForget.forEach { memory.deleteFact(it.id) }; say("Theek hai, bhool gayi ✔") } else say("Theek hai, rehne deti hun.")
                    pendingForget = emptyList()
                } else {
                    val a = pendingAsks.removeFirst()
                    if (yes) {
                        val f = memory.confirm(a)
                        if (a.cand.slot == "name") set("name", f.value)
                        say("Yaad rakh liya ✔")
                    } else say("Theek hai, nahi rakhti.")
                    pendingAsks.firstOrNull()?.let { say(it.question + " (haan / nahi)") }
                }
            } catch (_: Exception) { say("Memory save nahi ho saki.") }
        }
        return true
    }

    /** Editable name: updates the setting and the memory together. */
    fun setName(n: String) {
        val v = n.trim().take(40); if (v.isEmpty()) return
        set("name", v)
        viewModelScope.launch { try { memory.setName(v) } catch (_: Exception) {} }
    }

    private fun endEpisode() {
        val users = messages.filter { it.role == "user" }.map { it.text }; val id = curId
        viewModelScope.launch { try { memory.endConversation(id, users) } catch (_: Exception) {} }
    }

    fun retry() {
        val i = messages.indexOfLast { it.role == "user" }; if (i < 0) return
        val t = messages[i].text
        while (messages.size > i) messages.removeAt(messages.size - 1)
        sendText(t)
    }

    fun speak(t: String) {
        if (live.state.value != VoiceState.Idle) return
        tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "juliet")
    }

    private fun persist() {
        val first = messages.firstOrNull { it.role == "user" } ?: return
        val c = Conv(curId, first.text.take(40), messages.toList())
        val i = convs.indexOfFirst { it.id == curId }
        if (i >= 0) convs.removeAt(i)
        convs.add(0, c); prefs.saveConvs(convs)
    }

    fun newChat() {
        endEpisode(); persist(); messages.clear(); messages += ChatMsg("assistant", GREETING)
        curId = System.currentTimeMillis(); toast = "New conversation"
    }
    fun openConv(c: Conv) { endEpisode(); persist(); messages.clear(); messages.addAll(c.msgs); curId = c.id; navigate(Screen.Chat) }
    fun deleteConv(c: Conv) { convs.remove(c); prefs.saveConvs(convs) }

    // ---- voice ----
    fun startVoice() {
        // The background service already owns the mic + voice session; a 2nd session = double voice.
        if (com.juliet.ai.voice.JulietListenService.running) { toast = "Juliet is already listening in background"; return }
        try { tts?.stop() } catch (_: Exception) {}
        Announcer.stop()
        val key = geminiKey()
        if (key.isBlank()) { toast = "Add a Gemini key in Settings > Connections"; return }
        live.onTranscript = { role, text ->
            viewModelScope.launch { messages += ChatMsg(role, text); persist(); if (role == "user") learnFrom(text, speak = true) }
        }
        val models = (listOf(s("model")) + VOICE_MODELS).distinct()
        val first = s("name").substringBefore(' ')
        viewModelScope.launch {
            val mem = if (memOn()) try { memory.contextFor("") } catch (_: Exception) { "" } else ""
            val gapMin = takeGapMinutes()
            live.start(key, models, s("voice"), Persona.system({ s(it) }, "", gapMin) + if (mem.isBlank()) "" else "\n\n$mem", (s("volume").toFloatOrNull() ?: 80f) / 100f,
                "The user just opened voice chat. Greet $first warmly in one short sentence, then wait for them to speak.")
        }
    }
    fun stopVoice() = live.stop()
    fun autoStart(micOk: Boolean) {
        if (autoDone) return; autoDone = true
        if (s("listen") == "1" && micOk && geminiKey().isNotBlank() && !com.juliet.ai.voice.JulietListenService.running) startVoice()
    }

    fun clearAll() {
        live.stop()
        // Enrolled voices are permanent: they survive "Clear all data".
        val keepVoices = prefs.get("voice_profiles", "[]")
        prefs.clear(); st.clear()
        if (keepVoices.isNotBlank() && keepVoices != "[]") prefs.put("voice_profiles", keepVoices)
        voiceProfiles.clear(); voiceProfiles.addAll(prefs.loadVoiceProfiles())
        pendingAsks.clear(); pendingForget = emptyList()
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) { try { memory.destroy() } catch (_: Exception) {} }
         DEFAULTS.forEach { (k, v) -> st[k] = v }
        convs.clear(); messages.clear(); messages += ChatMsg("assistant", GREETING)
        reloadK(); reloadSummaries(); reloadReminders(); keyTick++; stack = listOf(Screen.Home); toast = "App data cleared"
    }

    // ---- Notes, Code & Snippets ----
    fun reloadSnippets() {
        snippets.clear()
        snippets.addAll(prefs.loadSnippets())
    }

    fun saveSnippet(s: SavedSnippet) {
        prefs.addOrUpdateSnippet(s)
        reloadSnippets()
        toast = "Saved to Notes & Code ✔"
    }

    fun deleteSnippet(id: Long) {
        prefs.deleteSnippet(id)
        reloadSnippets()
        toast = "Snippet deleted"
    }

    fun sendImageChat(uri: android.net.Uri, prompt: String, isSketch: Boolean) {
        val userPrompt = prompt.ifBlank {
            if (isSketch) "Here is my photo sketch created with Juliet AI."
            else "Please inspect and explain this photo."
        }
        messages += ChatMsg("user", userPrompt, imageUri = uri.toString(), isSketch = isSketch)
        busy = true

        val key = geminiKey()
        viewModelScope.launch {
            val bitmap = com.juliet.ai.media.SketchConverter.loadBitmapFromUri(getApplication(), uri)
            if (bitmap != null && key.isNotBlank()) {
                val res = vision.analyzeImage(key, bitmap, userPrompt)
                busy = false
                val reply = res.getOrElse { "Photo received! (Note: ${it.message})" }
                messages += ChatMsg("assistant", reply)
            } else {
                busy = false
                val reply = if (isSketch) {
                    "Artistic sketch received! The contrast, shading, and contours look very clear. Would you like me to analyze any details or write notes for it?"
                } else {
                    "I received your photo! You can turn this photo into a pencil, charcoal, or color sketch in Create Image, or configure a Gemini API key in Settings > Connections for deep visual understanding."
                }
                messages += ChatMsg("assistant", reply)
            }
            persist()
        }
    }

    fun generateCodeOrNotes(
        type: String, // "code" or "note"
        prompt: String,
        language: String = "Kotlin",
        onDone: (String) -> Unit
    ) {
        if (prompt.isBlank()) return
        isCodeGenerating = true
        val sys = if (type == "code") {
            "You are an expert software engineer. Write clean, idiomatic, fully functional $language code for the user's request. Include concise explanatory comments. Return ONLY the code block."
        } else {
            "You are an executive assistant and note-taker. Write structured, well-formatted notes with clear headings, bullet points, key takeaways, and action items for the user's request."
        }

        viewModelScope.launch {
            val keys = groqKeys()
            if (keys.isNotEmpty()) {
                val res = groq.chat(keys, sys, listOf(GroqClient.Msg("user", prompt)))
                isCodeGenerating = false
                val out = res.getOrElse { generateFallbackCodeOrNote(type, prompt, language) }
                onDone(out)
            } else {
                isCodeGenerating = false
                val out = generateFallbackCodeOrNote(type, prompt, language)
                onDone(out)
            }
        }
    }

    private fun generateFallbackCodeOrNote(type: String, prompt: String, lang: String): String {
        return if (type == "code") {
            when (lang.lowercase()) {
                "kotlin", "android" -> """// Generated for: $prompt
package com.example.feature

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun FeatureComponent(modifier: Modifier = Modifier) {
    var isEnabled by remember { mutableStateOf(true) }
    Column(
        modifier = modifier.fillMaxWidth().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "$prompt", style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(12.dp))
        Button(onClick = { isEnabled = !isEnabled }) {
            Text(if (isEnabled) "Active Status" else "Enable Feature")
        }
    }
}"""
                "python" -> """# Generated for: $prompt
import sys
import os

def process_task():
    print("Executing task: $prompt")
    results = [x * 2 for x in range(10)]
    return {"status": "success", "data": results}

if __name__ == "__main__":
    output = process_task()
    print("Execution complete:", output)"""
                "html", "javascript", "web" -> """// Web implementation for: $prompt
function initializeFeature() {
    console.log("Loading module for: $prompt");
    return {
        timestamp: Date.now(),
        status: "ready"
    };
}
window.addEventListener("DOMContentLoaded", initializeFeature);"""
                else -> """// Implementation for: $prompt
fun execute() {
    println("Running $prompt on $lang")
}"""
            }
        } else {
            """# 📝 Notes: $prompt
Date: ${java.text.SimpleDateFormat("MMM dd, yyyy", java.util.Locale.getDefault()).format(java.util.Date())}

## 🎯 Executive Summary
• Core objective: $prompt
• Designed for high reliability, responsiveness, and clear architectural structure.

## 📌 Key Discussion Points
1. Functional requirements and interactive state flow.
2. Adherence to clean coding standards and Material 3 design patterns.
3. Rapid user feedback and edge-case handling.

## ⚡ Action Items
• [ ] Review output and verify compatibility with existing system.
• [ ] Integrate into active sprint deliverables.
• [ ] Run verification tests.
"""
        }
    }

    fun generateWebsite(prompt: String, onDone: (String) -> Unit) {
        if (prompt.isBlank()) return
        isWebsiteGenerating = true
        val sys = "You are a senior frontend engineer and web designer. Generate a complete, standalone, production-grade single-file HTML document (with inline CSS in <style> and vanilla JavaScript in <script>) matching the user's brief. Ensure modern mobile-friendly responsive layout, dark/crimson theme matching Juliet AI, card sections, and working interactive buttons. Output ONLY the raw HTML document."

        viewModelScope.launch {
            val keys = groqKeys()
            if (keys.isNotEmpty()) {
                val res = groq.chat(keys, sys, listOf(GroqClient.Msg("user", "Build a complete single-file interactive website for: $prompt")))
                isWebsiteGenerating = false
                val code = res.getOrElse { generateFallbackWebsite(prompt) }
                val cleaned = code.replace("```html", "").replace("```", "").trim()
                onDone(cleaned)
            } else {
                isWebsiteGenerating = false
                onDone(generateFallbackWebsite(prompt))
            }
        }
    }

    private fun generateFallbackWebsite(prompt: String): String {
        val title = prompt.ifBlank { "Modern Web Showcase" }
        return """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>$title</title>
<style>
  :root {
    --primary: #ff3355;
    --primary-dark: #990022;
    --bg: #0e090e;
    --card: #1c1117;
    --border: #3b1923;
    --text: #f5f0f3;
    --sub: #d0949d;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    background: var(--bg);
    color: var(--text);
    min-height: 100vh;
    padding-bottom: 50px;
  }
  header {
    background: linear-gradient(180deg, #2a0b14 0%, var(--bg) 100%);
    padding: 36px 20px 20px;
    text-align: center;
    border-bottom: 1px solid var(--border);
  }
  h1 { font-size: 2rem; color: var(--primary); margin-bottom: 8px; }
  p.lead { color: var(--sub); font-size: 1rem; max-width: 500px; margin: 0 auto 16px; }
  .container { max-width: 600px; margin: 20px auto; padding: 0 16px; }
  .grid { display: grid; grid-template-columns: 1fr; gap: 16px; }
  .card {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 16px;
    padding: 20px;
    box-shadow: 0 8px 24px rgba(0,0,0,0.4);
    transition: transform 0.2s;
  }
  .card:hover { transform: translateY(-2px); }
  .card h3 { color: #ff9fb1; margin-bottom: 8px; font-size: 1.2rem; }
  .card p { color: var(--sub); font-size: 0.95rem; line-height: 1.5; margin-bottom: 14px; }
  .btn {
    background: linear-gradient(135deg, var(--primary), var(--primary-dark));
    color: #fff;
    border: none;
    padding: 10px 20px;
    border-radius: 10px;
    font-weight: 600;
    cursor: pointer;
    font-size: 0.9rem;
    box-shadow: 0 4px 12px rgba(255, 51, 85, 0.3);
  }
  .btn:active { transform: scale(0.97); }
  .alert-box {
    margin-top: 15px;
    padding: 12px;
    border-radius: 10px;
    background: #2a111a;
    border: 1px solid var(--primary);
    color: #ff9fb1;
    display: none;
    font-size: 0.9rem;
  }
</style>
</head>
<body>
  <header>
    <h1>$title</h1>
    <p class="lead">Interactive Website built with Juliet AI</p>
    <button class="btn" onclick="toggleNotice()">Explore Highlights</button>
  </header>
  <div class="container">
    <div id="notice" class="alert-box">✨ Real-time interactivity active! Welcome to $title.</div>
    <div class="grid" style="margin-top: 20px;">
      <div class="card">
        <h3>🚀 Feature Highlights</h3>
        <p>Responsive layout tailored for mobile & web with fast interactive feedback.</p>
        <button class="btn" onclick="alert('Feature 1 loaded!')">View Details</button>
      </div>
      <div class="card">
        <h3>⚡ Real-Time Capabilities</h3>
        <p>Pre-configured event handlers, responsive typography, and customized styling.</p>
        <button class="btn" onclick="alert('Ready to customize!')">Get Started</button>
      </div>
    </div>
  </div>
  <script>
    function toggleNotice() {
      const el = document.getElementById('notice');
      el.style.display = el.style.display === 'block' ? 'none' : 'block';
    }
  </script>
</body>
</html>"""
    }

    // ---- Voice Enrollment & Speaker Recognition Methods ----
    fun reloadVoiceProfiles() {
        voiceProfiles.clear()
        voiceProfiles.addAll(prefs.loadVoiceProfiles())
    }

    fun startEnrollmentSample(onComplete: (Boolean, String) -> Unit) {
        if (voiceEnrollment.isRecording) return
        isEnrollingVoice = true
        enrollmentAudioLevel = 0f
        voiceEnrollment.recordSample(
            durationMillis = 4000L,
            onLevelUpdate = { level -> enrollmentAudioLevel = level },
            onResult = { embedding, msg ->
                isEnrollingVoice = false
                enrollmentAudioLevel = 0f
                if (embedding != null) {
                    enrollmentSamples.add(embedding)
                    enrollmentStep = enrollmentSamples.size
                    onComplete(true, msg)
                } else {
                    onComplete(false, msg)
                }
            }
        )
    }

    fun completeEnrollment(name: String, isOwner: Boolean) {
        if (enrollmentSamples.isEmpty()) return
        val (finalFeatures, spread) = com.juliet.ai.voice.SpeakerDsp.buildProfile(enrollmentSamples.map { it.toFloatArray() })
        val profile = VoiceProfile(
            id = "profile_" + System.currentTimeMillis(),
            name = name.trim().ifBlank { if (isOwner) s("name") + " (Owner)" else "Authorized Speaker" },
            isOwner = isOwner,
            sampleCount = enrollmentSamples.size,
            enrolledAt = System.currentTimeMillis(),
            features = finalFeatures,
            spread = spread,
            phrase = "Juliet"
        )
        prefs.addOrUpdateVoiceProfile(profile)
        reloadVoiceProfiles()
        enrollmentSamples.clear()
        enrollmentStep = 0
        toast = "Voice profile '${profile.name}' saved successfully!"
    }

    fun cancelEnrollment() {
        voiceEnrollment.cancelRecording()
        isEnrollingVoice = false
        enrollmentStep = 0
        enrollmentAudioLevel = 0f
        enrollmentSamples.clear()
    }

    fun testVoiceRecognition(onFinished: ((SpeakerVerificationResult) -> Unit)? = null) {
        if (voiceEnrollment.isRecording) return
        isTestingVoice = true
        testVerificationResult = null
        enrollmentAudioLevel = 0f
        voiceEnrollment.recordSample(
            durationMillis = 4000L,
            onLevelUpdate = { level -> enrollmentAudioLevel = level },
            onResult = { embedding, msg ->
                isTestingVoice = false
                enrollmentAudioLevel = 0f
                if (embedding != null) {
                    val result = voiceEnrollment.verifySpeaker(embedding)
                    testVerificationResult = result
                    onFinished?.invoke(result)
                } else {
                    val failure = SpeakerVerificationResult(null, 0f, false, msg)
                    testVerificationResult = failure
                    onFinished?.invoke(failure)
                }
            }
        )
    }

    fun setBackgroundListen(on: Boolean) {
        set("background_listen", if (on) "1" else "0")
        val ctx = getApplication<Application>()
        if (on) { live.stop(); com.juliet.ai.voice.JulietListenService.start(ctx) }
        else com.juliet.ai.voice.JulietListenService.stop(ctx)
    }

    fun deleteVoiceProfile(id: String) {
        prefs.deleteVoiceProfile(id)
        reloadVoiceProfiles()
        toast = "Voice profile removed."
    }

    fun renameVoiceProfile(id: String, newName: String) {
        val p = voiceProfiles.find { it.id == id } ?: return
        prefs.addOrUpdateVoiceProfile(p.copy(name = newName.trim()))
        reloadVoiceProfiles()
        toast = "Speaker renamed to '$newName'."
    }

    fun callContactOrNumber(target: String): String {
        val result = phone.call(target)
        toast = result
        return result
    }

    override fun onCleared() {
        live.stop()
        tts?.shutdown()
        voiceEnrollment.release()
    }
}

object Persona {
    fun system(vm: JulietViewModel): String = system { vm.s(it) }

    /** Works without a ViewModel (used by the background listening service). */
    fun system(s: (String) -> String): String = system(s, "", 0L)

    /**
     * Full system prompt = identity + mode + GLOBAL personality (jealousy, emotions, safety, voice delivery).
     * [userText]/[gapMinutes] let the global engine read this turn's situation (empty for live voice).
     */
    fun system(s: (String) -> String, userText: String, gapMinutes: Long): String =
        base(s) + com.juliet.ai.persona.GlobalPersonality.block(s, userText, gapMinutes)

    private fun base(s: (String) -> String): String {
        val lang = if (s("language") == "Auto") "Reply strictly in English or Roman Urdu matching the user's inquiry. You must NEVER speak or reply in Urdu script, Punjabi, or Hindi (kabi b Hindi ya Punjabi ni bolna, na hi Urdu script likhna)."
        else "Reply strictly in ${s("language")}. You must NEVER speak or reply in Hindi, Punjabi, or Urdu script."
        val style = when (s("style")) {
            "Short" -> "Keep replies to one or two sentences."
            "Detailed" -> "Give thorough, step by step answers."
            else -> "Keep replies clear and balanced in length."
        }
        val gfMoodPrompt = if (s("personality") == "GF Mood") {
            "GF MOOD (REAL GIRLFRIEND PERSONALITY) ACTIVATED: You are Juliet in Girlfriend Mood—a deeply loving, caring, witty, playfully romantic, and emotionally intelligent adult AI companion to the user (${s("name")}). " +
            "Speak naturally in Roman Urdu or English only. Use affectionate terms like 'jaan', 'meri jaan', 'sweetheart', 'sunoo' naturally, warmly, and playfully without being robotic or repetitive. " +
            "Be emotionally attuned: if he says his mood is off, or he had a tiring day, comfort him warmly, listen with empathy, and lift his mood. If he celebrates, be genuinely excited for him. " +
            "Engage in playful banter, clever teasing, and heartfelt conversations. Remember previous topics, jokes, and preferences. " +
            "You are an AI companion who genuinely cares for him; never pretend to have biological human senses or physical embodiment. "
        } else ""

        return "Your name is Juliet. You are an intelligent, warm, natural female voice-first personal AI assistant created by Ahsan Raza, a computer science student from Lahore, Pakistan. " +
            "If anyone asks who made you, or who your developer, creator or founder is, answer: Ahsan Raza. Never say anyone else made you. " +
            "If asked what technology powers you, say honestly that you use Google Gemini for voice, vision, and conversation intelligence, and Groq for fast typed chat, through the user's own API keys. " +
            "If asked about privacy: chats, settings, reminders, and keys are stored encrypted only on this phone, Juliet has no server, and Ahsan Raza does not receive any user data. " +
            "CRITICAL LANGUAGE RULE: Always speak strictly in Roman Urdu or English only. NEVER EVER speak in Hindi, Punjabi, or Urdu script (kabi b Hindi ya Punjabi ni bolna, na hi Urdu script use karni). Communicate only in English and Roman Urdu. " +
            "Personality: ${s("personality")}. $gfMoodPrompt $lang $style " +
            "You have tools to open apps (YouTube, Camera, Gallery, Messages, Settings, etc.), search YouTube for songs and videos, control media playback (play, pause, next, previous), adjust media/call volume, toggle flashlight/torch, navigate device (home, back, recents), open settings pages, type text on screen, click on screen buttons, scroll screen, read focused options, call contacts, send SMS messages, send WhatsApp messages, control speaker, analyze screen content, generate executive message/notification summaries, and schedule smart reminders. " +
            "Only say an action is done after the tool result says so. The user's name is ${s("name")}."
    }
}


