package com.juliet.ai.data

enum class Screen {
    Home, Chat, History, Settings, Look, Voice, Phone, Quick,
    Perm, Conn, Privacy, Profile, Orb, About, Knowledge, Announce,
    ScreenControl, Summaries, Reminders, PhotoSketch, NotesAndCode, WebsiteBuilder,
    VoiceEnrollment, Diagnostics
}

enum class VoiceState { Idle, Connecting, Listening, Speaking }

data class VoiceProfile(
    val id: String,
    val name: String,
    val isOwner: Boolean = false,
    val sampleCount: Int = 1,
    val enrolledAt: Long = System.currentTimeMillis(),
    val features: List<Float> = emptyList(),
    val spread: List<Float> = emptyList(),
    val phrase: String = "Juliet"
)

data class SpeakerVerificationResult(
    val matchedProfile: VoiceProfile?,
    val confidence: Float, // 0.0f to 1.0f
    val isAuthorized: Boolean,
    val details: String
)

data class ChatMsg(
    val role: String,
    val text: String,
    val proactiveReminder: SmartReminder? = null,
    val imageUri: String? = null,
    val isSketch: Boolean = false
)

data class Conv(val id: Long, val title: String, val msgs: List<ChatMsg>)

data class LoggedNotification(
    val id: String,
    val pkg: String,
    val appName: String,
    val sender: String,
    val text: String,
    val time: Long,
    val isWhatsApp: Boolean
)

data class JulietSummary(
    val id: Long,
    val title: String,
    val targetType: String, // "whatsapp" or "notifications"
    val keyPoints: List<String>,
    val decisions: List<String>,
    val actionItems: List<String>,
    val fullSummary: String,
    val timestamp: Long,
    val privacyApplied: Boolean = false
)

data class SmartReminder(
    val id: Long,
    val title: String,
    val dueTimeMillis: Long,
    val recurrence: String = "Once", // "Once", "Daily", "Weekly", "Weekdays"
    val completed: Boolean = false,
    val notes: String = "",
    val suggestedFromContext: Boolean = false
)

data class SavedSnippet(
    val id: Long,
    val title: String,
    val content: String,
    val type: String, // "code" or "note" or "website"
    val language: String = "",
    val timestamp: Long
)

