package com.juliet.ai.reminders

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.juliet.ai.data.Prefs
import com.juliet.ai.data.SmartReminder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class ReminderManager(private val ctx: Context, private val prefs: Prefs) {

    private val alarmManager = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun scheduleAlarm(reminder: SmartReminder) {
        if (reminder.completed || reminder.dueTimeMillis <= System.currentTimeMillis()) return

        val intent = Intent(ctx, ReminderReceiver::class.java).apply {
            action = ReminderReceiver.ACTION_TRIGGER
            putExtra(ReminderReceiver.EXTRA_ID, reminder.id)
            putExtra(ReminderReceiver.EXTRA_TITLE, reminder.title)
            putExtra(ReminderReceiver.EXTRA_RECURRENCE, reminder.recurrence)
        }

        val pending = PendingIntent.getBroadcast(
            ctx, reminder.id.toInt(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    if (alarmManager.canScheduleExactAlarms()) {
                        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, reminder.dueTimeMillis, pending)
                    } else {
                        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, reminder.dueTimeMillis, pending)
                    }
                } else {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, reminder.dueTimeMillis, pending)
                }
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, reminder.dueTimeMillis, pending)
            }
        } catch (_: Exception) {
            alarmManager.set(AlarmManager.RTC_WAKEUP, reminder.dueTimeMillis, pending)
        }
    }

    fun cancelAlarm(id: Long) {
        val intent = Intent(ctx, ReminderReceiver::class.java).apply {
            action = ReminderReceiver.ACTION_TRIGGER
        }
        val pending = PendingIntent.getBroadcast(
            ctx, id.toInt(), intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pending != null) {
            alarmManager.cancel(pending)
            pending.cancel()
        }
    }

    fun createReminder(
        title: String,
        dueTimeMillis: Long,
        recurrence: String = "Once",
        notes: String = "",
        suggested: Boolean = false
    ): SmartReminder {
        val reminder = SmartReminder(
            id = System.currentTimeMillis(),
            title = title.trim().replaceFirstChar { it.uppercase() },
            dueTimeMillis = dueTimeMillis,
            recurrence = recurrence,
            completed = false,
            notes = notes,
            suggestedFromContext = suggested
        )
        prefs.addOrUpdateReminder(reminder)
        scheduleAlarm(reminder)
        return reminder
    }

    fun updateReminder(reminder: SmartReminder) {
        prefs.addOrUpdateReminder(reminder)
        if (!reminder.completed) {
            scheduleAlarm(reminder)
        } else {
            cancelAlarm(reminder.id)
        }
    }

    fun deleteReminder(id: Long) {
        cancelAlarm(id)
        prefs.deleteReminder(id)
    }

    fun toggleComplete(id: Long): Boolean {
        val cur = prefs.loadReminders().firstOrNull { it.id == id } ?: return false
        val updated = cur.copy(completed = !cur.completed)
        updateReminder(updated)
        return updated.completed
    }

    /**
     * Parses natural language reminder queries:
     * "Remind me to call Mom tomorrow at 2 PM"
     * "Remind me about the project deadline next Friday"
     * "Remind me in 30 minutes to take medicine"
     */
    fun parseNaturalLanguageReminder(raw: String): SmartReminder? {
        val text = raw.trim()
        val lower = text.lowercase()

        // Clean prefix
        var clean = lower
            .replace(Regex("^(?:juliet[,]?)?\\s*(?:please\\s+)?remind\\s+(?:me\\s+)?(?:to|about)?\\s*"), "")
            .replace(Regex("\\s+ka\\s+remind\\s+(?:karo|kar\\s+do|lagao)$"), "")
            .trim()

        val cal = Calendar.getInstance()
        var recurrence = "Once"

        if (clean.contains("daily") || clean.contains("every day") || clean.contains("rozana")) {
            recurrence = "Daily"
            clean = clean.replace(Regex("\\b(daily|every day|rozana)\\b"), "").trim()
        } else if (clean.contains("weekly") || clean.contains("every week")) {
            recurrence = "Weekly"
            clean = clean.replace(Regex("\\b(weekly|every week)\\b"), "").trim()
        } else if (clean.contains("weekdays")) {
            recurrence = "Weekdays"
            clean = clean.replace(Regex("\\b(weekdays|every weekday)\\b"), "").trim()
        }

        // Relative time: "in X minutes" / "in X hours"
        val inMinutesMatch = Regex("in\\s+(\\d+)\\s*(?:min|mins|minute|minutes)").find(clean)
        val inHoursMatch = Regex("in\\s+(\\d+)\\s*(?:hr|hrs|hour|hours)").find(clean)

        if (inMinutesMatch != null) {
            val mins = inMinutesMatch.groupValues[1].toIntOrNull() ?: 10
            cal.add(Calendar.MINUTE, mins)
            val title = clean.replace(inMinutesMatch.value, "").replace(Regex("\\s+to\\s+"), " ").trim()
            return SmartReminder(System.currentTimeMillis(), title.ifBlank { "Reminder" }, cal.timeInMillis, recurrence)
        }

        if (inHoursMatch != null) {
            val hrs = inHoursMatch.groupValues[1].toIntOrNull() ?: 1
            cal.add(Calendar.HOUR_OF_DAY, hrs)
            val title = clean.replace(inHoursMatch.value, "").replace(Regex("\\s+to\\s+"), " ").trim()
            return SmartReminder(System.currentTimeMillis(), title.ifBlank { "Reminder" }, cal.timeInMillis, recurrence)
        }

        // "tomorrow" or "kal"
        val isTomorrow = clean.contains("tomorrow") || clean.contains("kal")
        if (isTomorrow) {
            cal.add(Calendar.DAY_OF_YEAR, 1)
            clean = clean.replace(Regex("\\b(tomorrow|kal)\\b"), "").trim()
        }

        // "next Friday / Monday / etc."
        val days = mapOf(
            "sunday" to Calendar.SUNDAY, "itwar" to Calendar.SUNDAY,
            "monday" to Calendar.MONDAY, "peer" to Calendar.MONDAY,
            "tuesday" to Calendar.TUESDAY, "mangal" to Calendar.TUESDAY,
            "wednesday" to Calendar.WEDNESDAY, "budh" to Calendar.WEDNESDAY,
            "thursday" to Calendar.THURSDAY, "jumma raat" to Calendar.THURSDAY,
            "friday" to Calendar.FRIDAY, "jumma" to Calendar.FRIDAY,
            "saturday" to Calendar.SATURDAY, "hafta" to Calendar.SATURDAY
        )

        for ((dayName, dayCode) in days) {
            if (clean.contains(dayName)) {
                clean = clean.replace(Regex("\\b(next\\s+)?$dayName\\b"), "").trim()
                while (cal.get(Calendar.DAY_OF_WEEK) != dayCode) {
                    cal.add(Calendar.DAY_OF_YEAR, 1)
                }
                break
            }
        }

        // Time parsing: "at 2 PM", "at 14:00", "at 9:30 AM", "2 baje"
        val timeRegex = Regex("(?:at|around|ko)?\\s*(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm|baje)?")
        val match = timeRegex.findAll(clean).lastOrNull { m ->
            m.groupValues[1].isNotEmpty() && (m.groupValues[3].isNotEmpty() || m.groupValues[2].isNotEmpty() || clean.contains("at "))
        }

        if (match != null) {
            var hour = match.groupValues[1].toIntOrNull() ?: 9
            val min = match.groupValues[2].toIntOrNull() ?: 0
            val amPm = match.groupValues[3].lowercase()

            if (amPm == "pm" && hour < 12) hour += 12
            if (amPm == "am" && hour == 12) hour = 0
            // If "baje" or no am/pm specified and hour between 1 and 7, assume afternoon
            if (amPm == "baje" && hour in 1..7) hour += 12

            cal.set(Calendar.HOUR_OF_DAY, hour)
            cal.set(Calendar.MINUTE, min)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)

            // If time is in the past for today and tomorrow wasn't specified, push to tomorrow
            if (!isTomorrow && cal.timeInMillis <= System.currentTimeMillis()) {
                cal.add(Calendar.DAY_OF_YEAR, 1)
            }

            clean = clean.replace(match.value, "").trim()
        } else {
            // Default to 9:00 AM next morning if only date was given
            cal.set(Calendar.HOUR_OF_DAY, 9)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            if (cal.timeInMillis <= System.currentTimeMillis()) {
                cal.add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        var finalTitle = clean
            .replace(Regex("^(?:to|about)\\s+"), "")
            .replace(Regex("\\s+at$"), "")
            .trim()
            .ifBlank { "Reminder" }

        return SmartReminder(
            id = System.currentTimeMillis(),
            title = finalTitle.replaceFirstChar { it.uppercase() },
            dueTimeMillis = cal.timeInMillis,
            recurrence = recurrence
        )
    }

    /**
     * Proactive context detection:
     * Detects when a user statement implies an upcoming task/action and suggests setting a reminder.
     */
    fun detectProactiveReminder(text: String): SmartReminder? {
        val lower = text.lowercase().trim()

        // Ignore direct commands (handled by route/parse)
        if (lower.startsWith("remind me") || lower.startsWith("set a reminder") || lower.startsWith("juliet remind")) {
            return null
        }

        val triggers = listOf(
            "i need to ", "i have to ", "i must ", "don't let me forget to ",
            "need to follow up ", "have to submit ", "have to call ", "need to send "
        )

        val trigger = triggers.firstOrNull { lower.contains(it) } ?: return null
        val taskPart = lower.substringAfter(trigger).trim().trimEnd('.', '!')
        if (taskPart.length < 4) return null

        // Default proactive reminder scheduled for tomorrow 10:00 AM or 2 hours later
        val cal = Calendar.getInstance().apply {
            add(Calendar.HOUR_OF_DAY, 2)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
        }

        val parsed = parseNaturalLanguageReminder("remind me to $taskPart")
        return parsed?.copy(suggestedFromContext = true) ?: SmartReminder(
            id = System.currentTimeMillis(),
            title = taskPart.replaceFirstChar { it.uppercase() },
            dueTimeMillis = cal.timeInMillis,
            recurrence = "Once",
            suggestedFromContext = true
        )
    }

    fun formatDueTime(millis: Long): String {
        val cal = Calendar.getInstance().apply { timeInMillis = millis }
        val now = Calendar.getInstance()
        val timeStr = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(millis))

        return when {
            cal.get(Calendar.YEAR) == now.get(Calendar.YEAR) && cal.get(Calendar.DAY_OF_YEAR) == now.get(Calendar.DAY_OF_YEAR) ->
                "Today at $timeStr"
            cal.get(Calendar.YEAR) == now.get(Calendar.YEAR) && cal.get(Calendar.DAY_OF_YEAR) == now.get(Calendar.DAY_OF_YEAR) + 1 ->
                "Tomorrow at $timeStr"
            else ->
                SimpleDateFormat("EEE, MMM d 'at' h:mm a", Locale.getDefault()).format(Date(millis))
        }
    }
}
