package com.juliet.ai.ui

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.platform.LocalContext
import com.juliet.ai.media.SketchConverter
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.juliet.ai.R
import com.juliet.ai.data.*
import com.juliet.ai.vm.JulietViewModel

@Composable
private fun fieldColors(): TextFieldColors {
    val p = LocalPal.current
    return TextFieldDefaults.colors(
        focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
        cursorColor = J.Crim, focusedTextColor = p.text, unfocusedTextColor = p.text
    )
}

@Composable
private fun SendBtn(round: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.then(if (round) Modifier.size(48.dp).clip(CircleShape) else Modifier.size(62.dp, 48.dp).clip(RoundedCornerShape(15.dp)))
            .background(J.Tile).clickable(onClick = onClick), Alignment.Center
    ) { Icon(Icons.Rounded.Send, "Send", tint = Color.White) }
}

@Composable
private fun Pill(value: String, onValue: (String) -> Unit, hint: String, lead: Boolean, round: Boolean, onSend: () -> Unit) {
    val p = LocalPal.current
    val sh = RoundedCornerShape(34.dp)
    Row(Modifier.fillMaxWidth().clip(sh).background(p.card).border(1.dp, p.border, sh).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        if (lead) Box(Modifier.size(44.dp).clip(CircleShape).background(p.card2), Alignment.Center) { Icon(Icons.Rounded.AutoAwesome, null, tint = J.Red) }
        TextField(
            value, onValue, Modifier.weight(1f), singleLine = true, colors = fieldColors(),
            placeholder = { Text(hint, color = p.mu, fontSize = 19.sp) }, textStyle = TextStyle(fontSize = 19.sp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send), keyboardActions = KeyboardActions(onSend = { onSend() })
        )
        SendBtn(round, onSend)
    }
}

// ---------------- HOME ----------------
@Composable
fun HomeScreen(vm: JulietViewModel, onMic: () -> Unit) {
    val p = LocalPal.current
    val vs by vm.live.state.collectAsState()
    val reduce = vm.s("reduce") == "1"
    val orb = vm.s("orb").toIntOrNull() ?: 0
    var q by remember { mutableStateOf("") }
    val glow = TextStyle(shadow = Shadow(J.Red, Offset.Zero, 24f))
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding().padding(horizontal = 16.dp).navigationBarsPadding().padding(bottom = 130.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 14.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            SquareBtn(Icons.Rounded.Menu, "Quick actions") { vm.navigate(Screen.Quick) }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("JULIET AI", color = J.Red, fontSize = 24.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp, style = glow)
                Text("YOUR AI ASSISTANT", color = p.mu, fontSize = 10.sp, letterSpacing = 3.sp)
            }
            SquareBtn(Icons.Rounded.Settings, "Settings") { vm.navigate(Screen.Settings) }
        }
        Box(Modifier.fillMaxWidth().height(340.dp)) {
            Image(painterResource(R.drawable.juliet_hero), "Juliet", Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alignment = Alignment.TopCenter)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0f to p.bg.copy(alpha = .65f), .28f to Color.Transparent, .6f to Color.Transparent, 1f to p.bg)))
            Canvas(Modifier.fillMaxSize()) {
                fun wave(y: Float, a: Float, c: Color, w: Float) {
                    val path = Path().apply {
                        moveTo(-10f, size.height * y)
                        cubicTo(size.width * .2f, size.height * (y - a), size.width * .4f, size.height * (y + a), size.width * .6f, size.height * y)
                        cubicTo(size.width * .8f, size.height * (y - a), size.width * .95f, size.height * (y + a * .5f), size.width + 10f, size.height * y)
                    }
                    drawPath(path, c, style = Stroke(w, cap = StrokeCap.Round))
                }
                wave(.78f, .3f, J.Red.copy(alpha = .35f), 14f); wave(.78f, .3f, J.Red, 3f)
                wave(.9f, .3f, J.Crim.copy(alpha = .7f), 2f); wave(.66f, .3f, Color(0xFFFF9FB1).copy(alpha = .5f), 1.5f)
            }
            Text("Hi,\nI'm\nJuliet ♡", color = Color.White, fontFamily = FontFamily.Cursive, fontSize = 30.sp, lineHeight = 30.sp,
                style = glow, modifier = Modifier.align(Alignment.CenterStart).padding(top = 30.dp))
            Text("Always\nHere\nFor You ♡", color = Color.White, fontFamily = FontFamily.Cursive, fontSize = 26.sp, lineHeight = 26.sp,
                style = glow, modifier = Modifier.align(Alignment.TopEnd).padding(top = 30.dp))
            Box(Modifier.align(Alignment.BottomCenter).offset(y = 62.dp)) {
                val audioLevel by vm.voiceAudioLevel.collectAsState()
                MicRing(vs != VoiceState.Idle, reduce, orb, vm.orbMode, audioLevel, onMic)
            }
        }
        Spacer(Modifier.height(70.dp))
        Text(
            when (vs) { VoiceState.Idle -> "Tap the mic to start"; VoiceState.Connecting -> "Waking up…"; VoiceState.Listening -> "Listening…"; VoiceState.Speaking -> "Speaking…" },
            color = p.text, fontSize = 26.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        Text(greeting(vm.s("name")), color = p.mu, fontSize = 15.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 4.dp))
        WaveDots(vs != VoiceState.Idle && !reduce)
        Pill(q, { q = it }, "Ask me anything...", true, false) { vm.sendText(q); q = ""; vm.navigate(Screen.Chat) }
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HomeTile("🤖", "WA Bot", "Category menu", Modifier.weight(1f)) { vm.navigate(Screen.Knowledge) }
            HomeTile("📋", "Summaries", "WA & alerts", Modifier.weight(1f)) { vm.navigate(Screen.Summaries) }
            HomeTile("⏰", "Reminders", "Tasks & alerts", Modifier.weight(1f)) { vm.navigate(Screen.Reminders) }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HomeTile("💬", "Chat", "Instant answers", Modifier.weight(1f)) { vm.navigate(Screen.Chat) }
            HomeTile("🖼", "Photo Sketch", "Photos to art", Modifier.weight(1f)) { vm.navigate(Screen.PhotoSketch) }
            HomeTile("📄", "Write", "Notes & code", Modifier.weight(1f)) { vm.navigate(Screen.NotesAndCode) }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HomeTile("🖥️", "Screen", "Live share", Modifier.weight(1f)) { vm.navigate(Screen.ScreenControl) }
            HomeTile("🌐", "Website", "HTML builder", Modifier.weight(1f)) { vm.navigate(Screen.WebsiteBuilder) }
            HomeTile("📞", "Phone", "Keypad & calls", Modifier.weight(1f)) { vm.navigate(Screen.Phone) }
        }
    }
}

@Composable
private fun HomeTile(icon: String, title: String, sub: String, mod: Modifier, onClick: () -> Unit) {
    val p = LocalPal.current
    val sh = RoundedCornerShape(24.dp)
    Column(mod.clip(sh).background(p.card).border(1.dp, p.border, sh).clickable(onClick = onClick).padding(vertical = 14.dp, horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(48.dp).clip(CircleShape).background(p.card2), Alignment.Center) { Text(icon, fontSize = 20.sp) }
        Spacer(Modifier.height(8.dp))
        Text(title, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Text(sub, color = p.mu, fontSize = 12.sp, lineHeight = 14.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
    }
}

@Composable
private fun MicRing(
    active: Boolean,
    reduce: Boolean,
    orb: Int,
    mode: Int,
    audioLevel: Float,
    onClick: () -> Unit
) {
    val t = rememberInfiniteTransition(label = "ring")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(2400, easing = LinearEasing)), label = "spin")
    val rot = if (active && !reduce) spin else 0f
    Box(Modifier.size(158.dp).shadow(24.dp, CircleShape, ambientColor = J.Red, spotColor = J.Red).clip(CircleShape).background(Color(0xFF18060C)).clickable(onClick = onClick), Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = 7.dp.toPx()
            rotate(rot) {
                drawArc(
                    Brush.sweepGradient(0f to Color.Transparent, .12f to J.Crim, .22f to Color.White, .36f to Color.Transparent, .64f to J.Crim, .82f to Color(0xFFFF9FB1), 1f to Color.Transparent),
                    0f, 360f, false, Offset(sw / 2, sw / 2), Size(size.width - sw, size.height - sw), style = Stroke(sw, cap = StrokeCap.Round)
                )
            }
        }
        Box(Modifier.size(124.dp).clip(CircleShape).background(Color(0xFF0F0408)).border(1.dp, J.Red.copy(alpha = .3f), CircleShape), Alignment.Center) {
            if (active) {
                JOrb(orb, Modifier.fillMaxSize(), mode = mode, animate = !reduce, bare = true, audioLevel = audioLevel)
            } else {
                Icon(Icons.Rounded.Mic, "Talk to Juliet", tint = J.Crim, modifier = Modifier.size(54.dp))
            }
        }
    }
}

@Composable
private fun WaveDots(active: Boolean) {
    val t = rememberInfiniteTransition(label = "wave")
    val h by t.animateFloat(22f, 8f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "h")
    Canvas(Modifier.fillMaxWidth().height(28.dp).padding(vertical = 2.dp)) {
        val n = 38; val gap = 8.dp.toPx(); val x0 = (size.width - gap * (n - 1)) / 2
        for (i in 0 until n) {
            val bar = i == 5 || i == 19 || i == 33
            val x = x0 + i * gap
            if (bar) {
                val bh = (if (active) h else 22f).dp.toPx()
                drawLine(J.Red, Offset(x, size.height / 2 - bh / 2), Offset(x, size.height / 2 + bh / 2), 4.dp.toPx(), StrokeCap.Round)
            } else drawCircle(J.Red.copy(alpha = .6f), 1.5.dp.toPx(), Offset(x, size.height / 2))
        }
    }
    Spacer(Modifier.height(14.dp))
}

private fun greeting(name: String): String {
    val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    val g = when { h < 5 -> "Good night"; h < 12 -> "Good morning"; h < 17 -> "Good afternoon"; h < 21 -> "Good evening"; else -> "Good night" }
    return "$g, ${name.substringBefore(' ')} ✦"
}

@Composable
private fun TypingDots() {
    val t = rememberInfiniteTransition(label = "typing")
    Row(Modifier.padding(start = 8.dp, top = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        repeat(3) { i ->
            val a by t.animateFloat(.25f, 1f, infiniteRepeatable(tween(600, delayMillis = i * 150), RepeatMode.Reverse), label = "d$i")
            Box(Modifier.size(9.dp).clip(CircleShape).background(J.Crim.copy(alpha = a)))
        }
    }
}

// ---------------- CHAT ----------------
@Composable
fun ChatScreen(vm: JulietViewModel, imeUp: Boolean) {
    val p = LocalPal.current
    val orb = vm.s("orb").toIntOrNull() ?: 0
    val reduce = vm.s("reduce") == "1"
    val audioLevel by vm.voiceAudioLevel.collectAsState()
    val list = rememberLazyListState()
    var attachedUri by remember { mutableStateOf<Uri?>(null) }
    val photoPickerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) attachedUri = uri
    }

    LaunchedEffect(vm.messages.size, vm.busy) {
        val n = vm.messages.size + (if (vm.busy) 1 else 0)
        if (n > 0) list.animateScrollToItem(n - 1)
    }
    Box(Modifier.fillMaxSize()) {
        Starfield(Modifier.fillMaxSize())
        Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp).navigationBarsPadding().padding(bottom = if (imeUp) 8.dp else 104.dp)) {
            Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                IconButton(onClick = { vm.navigate(Screen.Home) }) { Icon(Icons.Rounded.ArrowBack, "Back", tint = p.text) }
                JOrb(orb, Modifier.size(52.dp), mode = vm.orbMode, animate = !reduce, audioLevel = audioLevel)
                Column(Modifier.weight(1f)) {
                    Text("Juliet", color = p.text, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(J.Ok))
                        Spacer(Modifier.width(6.dp))
                        Text(if (vm.busy) "Typing…" else "Online", color = J.Ok, fontSize = 13.sp)
                    }
                }
                IconButton(onClick = { vm.newChat() }) { Icon(Icons.Rounded.Add, "New conversation", tint = p.text, modifier = Modifier.size(30.dp)) }
            }
            LazyColumn(Modifier.weight(1f), state = list, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                items(vm.messages) { Bubble(it, vm) }
                if (vm.busy) item { TypingDots() }
            }
            if (vm.messages.size <= 1) Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("YouTube kholo", "Mummy ko call karo", "Turn photo to sketch", "ek cafe ki website banao").forEach { s ->
                    Text(s, color = p.text, fontSize = 15.sp, modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(p.card)
                        .border(1.dp, p.border, RoundedCornerShape(20.dp)).clickable { vm.sendText(s) }.padding(horizontal = 14.dp, vertical = 9.dp))
                }
            }
            Spacer(Modifier.height(8.dp))

            attachedUri?.let { uri ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(p.card)
                        .border(1.dp, p.border, RoundedCornerShape(16.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Image, null, tint = J.Red, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Photo attached for Juliet", color = p.text, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    }
                    IconButton(onClick = { attachedUri = null }, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Rounded.Close, "Remove photo", tint = p.mu, modifier = Modifier.size(16.dp))
                    }
                }
            }

            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(p.card)
                        .border(1.dp, p.border, CircleShape)
                        .clickable {
                            photoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.AddPhotoAlternate, "Attach Photo", tint = J.Red, modifier = Modifier.size(22.dp))
                }

                Box(Modifier.weight(1f)) {
                    Pill(vm.draft, { vm.draft = it }, "Message Juliet…", false, true) {
                        val uri = attachedUri
                        if (uri != null) {
                            vm.sendImageChat(uri, vm.draft, isSketch = false)
                            attachedUri = null
                            vm.draft = ""
                        } else {
                            vm.sendText(vm.draft)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Bubble(m: ChatMsg, vm: JulietViewModel) {
    val p = LocalPal.current
    val clip = LocalClipboardManager.current
    val ctx = LocalContext.current
    val user = m.role == "user"
    val sh = if (user) RoundedCornerShape(26.dp, 26.dp, 8.dp, 26.dp) else RoundedCornerShape(26.dp, 26.dp, 26.dp, 8.dp)
    Box(Modifier.fillMaxWidth(), if (user) Alignment.CenterEnd else Alignment.CenterStart) {
        Column(
            Modifier.widthIn(max = 320.dp).clip(sh)
                .then(if (user) Modifier.background(Brush.linearGradient(listOf(Color(0xFFFF5E62), J.Red))) else Modifier.background(p.card).border(1.dp, p.border, sh))
                .padding(horizontal = 18.dp, vertical = 14.dp)
        ) {
            if (m.imageUri != null) {
                var imgBmp by remember(m.imageUri) { mutableStateOf<Bitmap?>(null) }
                LaunchedEffect(m.imageUri) {
                    try {
                        imgBmp = SketchConverter.loadBitmapFromUri(ctx, Uri.parse(m.imageUri), 400)
                    } catch (_: Exception) {}
                }
                imgBmp?.let { bmp ->
                    Image(
                        bitmap = bmp.asImageBitmap(),
                        contentDescription = if (m.isSketch) "Sketch" else "Uploaded photo",
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 220.dp)
                            .clip(RoundedCornerShape(16.dp)),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(Modifier.height(8.dp))
                }
            }
            Text(m.text, color = if (user) Color.White else p.text, fontSize = 18.sp, lineHeight = 24.sp)
            m.proactiveReminder?.let { r ->
                Spacer(Modifier.height(10.dp))
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                        .background(J.Gold.copy(alpha = 0.14f))
                        .border(1.dp, J.Gold.copy(alpha = 0.45f), RoundedCornerShape(16.dp))
                        .padding(10.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Rounded.Alarm, null, tint = J.Gold, modifier = Modifier.size(16.dp))
                            Text("Suggested Reminder", color = J.Gold, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Text(r.title, color = p.text, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 2.dp))
                        Text(vm.reminderManager.formatDueTime(r.dueTimeMillis), color = p.mu, fontSize = 12.sp)
                        Spacer(Modifier.height(6.dp))
                        Box(
                            Modifier.clip(RoundedCornerShape(14.dp)).background(J.Gold)
                                .clickable { vm.acceptProactiveReminder(r) }
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Text("Set Reminder", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            if (!user) Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                Icon(Icons.Rounded.ContentCopy, "Copy", tint = p.mu, modifier = Modifier.size(22.dp).clickable { clip.setText(AnnotatedString(m.text)); vm.toast = "Copied" })
                Icon(Icons.Rounded.Refresh, "Retry", tint = p.mu, modifier = Modifier.size(22.dp).clickable { vm.retry() })
                Icon(Icons.Rounded.VolumeUp, "Listen", tint = p.mu, modifier = Modifier.size(22.dp).clickable { vm.speak(m.text) })
            }
        }
    }
}

// ---------------- HISTORY ----------------
@Composable
fun HistoryScreen(vm: JulietViewModel) {
    val p = LocalPal.current
    var q by remember { mutableStateOf("") }
    val list = vm.convs.filter { it.title.contains(q, true) }
    Box(Modifier.fillMaxSize()) {
        Starfield(Modifier.fillMaxSize())
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding().padding(horizontal = 16.dp).navigationBarsPadding().padding(bottom = 130.dp)) {
            Text("Conversations", color = p.text, fontSize = 34.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 20.dp, bottom = 14.dp))
            val sh = RoundedCornerShape(30.dp)
            TextField(q, { q = it }, Modifier.fillMaxWidth().clip(sh).background(p.card).border(1.dp, p.border, sh), singleLine = true, colors = fieldColors(),
                placeholder = { Text("Search conversations", color = p.mu, fontSize = 19.sp) }, textStyle = TextStyle(fontSize = 19.sp))
            Spacer(Modifier.height(14.dp))
            if (list.isEmpty()) {
                Column(Modifier.fillMaxWidth().padding(top = 80.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(96.dp).clip(CircleShape).background(Brush.radialGradient(listOf(Color(0xFFFFF3D0), Color(0xFFFFB15A), J.Crim))))
                    Spacer(Modifier.height(26.dp))
                    Text("No conversations yet", color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Medium)
                    Text("Chats and voice conversations are saved here automatically.", color = p.mu, fontSize = 19.sp, lineHeight = 26.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp))
                    Spacer(Modifier.height(10.dp))
                    GradientButton("Start a conversation") { vm.navigate(Screen.Chat) }
                }
            } else Group {
                list.forEach { c ->
                    Item("💬", c.title, "${c.msgs.size} messages", trailing = {
                        Icon(Icons.Rounded.Delete, "Delete", tint = p.mu, modifier = Modifier.clickable { vm.deleteConv(c) })
                    }, onClick = { vm.openConv(c) })
                }
            }
        }
    }
}
