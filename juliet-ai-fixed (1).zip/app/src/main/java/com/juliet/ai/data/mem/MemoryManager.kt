package com.juliet.ai.data.mem

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.exp

/**
 * Juliet's 4-layer memory (all stored in the encrypted SQLCipher database):
 *  1. Working    - the current chat (kept by the ViewModel, not stored here)
 *  2. Episodic   - one short summary per past conversation
 *  3. Semantic   - facts about the user (name, family, likes, goals ...)
 *  4. Procedural - routines and how the user wants Juliet to behave
 */
class MemoryManager(ctx: Context) {
    private val app = ctx.applicationContext
    private val db: MemoryDb get() = MemoryDb.get(app)

    /** Something Juliet wants to save but should first ask the user about. */
    data class Ask(val cand: FactExtractor.Candidate, val existing: FactEntity?, val question: String)

    data class Result(val saved: List<FactEntity>, val asks: List<Ask>)

    /* ───────────── Learning ───────────── */

    /** Run on every user message. Saves safe facts directly, returns the ones that need a yes/no. */
    suspend fun learn(text: String, currentName: String): Result = withContext(Dispatchers.IO) {
        val saved = mutableListOf<FactEntity>()
        val asks = mutableListOf<Ask>()
        for (c in FactExtractor.extract(text)) {
            val existing = db.facts().bySlot(c.category, c.slot).firstOrNull()
            when {
                c.slot == "name" -> {
                    if (!c.value.equals(currentName, true) && !c.value.equals(existing?.value, true))
                        asks += Ask(c, existing, "Kya main aapka naam ${c.value} kar dun?")
                }
                c.sensitive -> if (existing == null)
                    asks += Ask(c, null, "Ye sehat ki baat hai: \"${c.value}\". Kya main isay yaad rakhun?")
                existing == null -> {
                    val opposite = oppositeOf(c)
                    if (opposite != null) asks += Ask(c, opposite, "Pehle yaad tha: ${opposite.category} - ${opposite.value}. Ab ${c.category}: ${c.value}. Update kar dun?")
                    else saved += upsert(c, null)
                }
                existing.value.equals(c.value, true) -> db.facts().touch(listOf(existing.id), System.currentTimeMillis())
                !c.multi && !c.explicit -> asks += Ask(c, existing, "Pehle ${existing.value} tha, ab ${c.value}. Update kar dun?")
                else -> saved += upsert(c, existing)
            }
        }
        Result(saved, asks)
    }

    private suspend fun oppositeOf(c: FactExtractor.Candidate): FactEntity? {
        val (cat, slot) = when (c.category) {
            "Likes" -> "Dislikes" to c.slot.replaceFirst("like:", "dislike:")
            "Dislikes" -> "Likes" to c.slot.replaceFirst("dislike:", "like:")
            else -> return null
        }
        return db.facts().bySlot(cat, slot).firstOrNull()
    }

    /** Apply a candidate the user confirmed (or one that needs no confirmation). */
    suspend fun upsert(c: FactExtractor.Candidate, existing: FactEntity?, replace: FactEntity? = null): FactEntity = withContext(Dispatchers.IO) {
        replace?.let { db.facts().delete(it.id) }
        val now = System.currentTimeMillis()
        val emb = LocalEmbedder.toBytes(LocalEmbedder.embed("${c.category} ${c.value}"))
        val layer = if (c.category == "Routine") "procedural" else "semantic"
        if (existing != null) {
            db.facts().updateValue(existing.id, c.value, now, emb)
            existing.copy(value = c.value, updatedAt = now)
        } else {
            val f = FactEntity(
                layer = layer, category = c.category, slot = c.slot, value = c.value,
                importance = c.importance, source = c.source, createdAt = now, updatedAt = now, embedding = emb
            )
            f.copy(id = db.facts().insert(f))
        }
    }

    suspend fun confirm(a: Ask): FactEntity =
        if (a.cand.category == "Likes" || a.cand.category == "Dislikes") upsert(a.cand, null, replace = a.existing)
        else upsert(a.cand, a.existing)

    /* ───────────── Editable name ───────────── */

    suspend fun setName(name: String) = withContext(Dispatchers.IO) {
        val n = name.trim().take(40); if (n.isEmpty()) return@withContext
        val c = FactExtractor.Candidate("Personal", "name", n, 1f, multi = false, source = "user")
        val f = upsert(c, db.facts().bySlot("Personal", "name").firstOrNull())
        db.facts().setPinned(f.id, true)
    }

    /* ───────────── Recall ───────────── */

    /** Text block added to the system prompt: pinned + procedural + most relevant facts + relevant past chats. */
    suspend fun contextFor(query: String, maxFacts: Int = 8): String = withContext(Dispatchers.IO) {
        val facts = db.facts().all()
        val eps = db.episodes().recent(40)
        if (facts.isEmpty() && eps.isEmpty()) return@withContext ""

        val q = if (query.isBlank()) null else LocalEmbedder.embed(query)
        val now = System.currentTimeMillis()
        fun score(f: FactEntity): Float {
            val sim = if (q != null && f.embedding != null) LocalEmbedder.cosine(q, LocalEmbedder.fromBytes(f.embedding)).coerceAtLeast(0f) else 0f
            val days = (now - f.updatedAt) / 86_400_000f
            return sim * 0.6f + f.importance * 0.25f + exp(-days / 30f) * 0.15f
        }
        val always = facts.filter { it.pinned || it.layer == "procedural" }.take(6)
        val rest = facts.filter { it !in always }.sortedByDescending { score(it) }.take(maxFacts)
        val used = always + rest

        val sb = StringBuilder("WHAT YOU REMEMBER ABOUT THE USER (use naturally, never recite as a list, never invent more):\n")
        used.forEach { sb.append("- ${it.category}: ${it.value}\n") }

        if (q != null && eps.isNotEmpty()) {
            val rel = eps.map { it to (it.embedding?.let { b -> LocalEmbedder.cosine(q, LocalEmbedder.fromBytes(b)) } ?: 0f) }
                .filter { it.second > 0.25f }.sortedByDescending { it.second }.take(2)
            if (rel.isNotEmpty()) {
                sb.append("RELATED PAST CONVERSATIONS:\n")
                rel.forEach { sb.append("- ${it.first.title}: ${it.first.summary}\n") }
            }
        }
        db.facts().touch(used.map { it.id }, now)
        sb.toString()
    }

    /* ───────────── Episodes + mood ───────────── */

    /** Called when a conversation ends. Offline summary (Stage 3 can upgrade it with an LLM). */
    suspend fun endConversation(convId: Long, userMsgs: List<String>) = withContext(Dispatchers.IO) {
        if (userMsgs.size < 3 || db.episodes().byConv(convId) != null) return@withContext
        val title = userMsgs.first().take(40)
        val summary = userMsgs.take(4).joinToString(" • ") { it.take(70) }
        val freq = userMsgs.flatMap { LocalEmbedder.tokens(it) }.groupingBy { it }.eachCount()
        val topics = freq.entries.sortedByDescending { it.value }.take(4).joinToString(",") { it.key }
        val mood = userMsgs.mapNotNull { detectMood(it) }.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key ?: "neutral"
        db.episodes().insert(
            EpisodeEntity(
                convId = convId, title = title, summary = summary, topics = topics, mood = mood,
                timestamp = System.currentTimeMillis(), embedding = LocalEmbedder.toBytes(LocalEmbedder.embed("$title $summary $topics"))
            )
        )
    }

    private val moodWords = mapOf(
        "sad" to listOf("udaas", "udas", "dukhi", "sad", "rona", "depressed", "akela", "akeli", "lonely"),
        "stressed" to listOf("pareshan", "tension", "stress", "stressed", "ghabra", "anxious", "worried"),
        "angry" to listOf("ghussa", "gussa", "angry", "naraz", "irritated"),
        "tired" to listOf("thak", "thaka", "thaki", "tired", "neend", "exhausted"),
        "happy" to listOf("khush", "happy", "mazay", "maza", "excited", "great", "zabardast")
    )

    fun detectMood(text: String): String? {
        val toks = LocalEmbedder.tokens(text).toSet()
        return moodWords.entries.firstOrNull { e -> e.value.any { w -> toks.any { it.startsWith(w) } } }?.key
    }

    suspend fun recordMood(text: String, source: String = "text") = withContext(Dispatchers.IO) {
        val m = detectMood(text) ?: return@withContext
        db.moods().insert(MoodEntity(mood = m, source = source, timestamp = System.currentTimeMillis()))
    }

    /* ───────────── Management (for the Memory screen) ───────────── */

    fun observeFacts() = db.facts().observeAll()
    fun observeEpisodes() = db.episodes().observeAll()
    suspend fun count(): Int = withContext(Dispatchers.IO) { db.facts().count() }
    suspend fun editFact(id: Long, v: String) = withContext(Dispatchers.IO) {
        db.facts().updateValue(id, v.trim(), System.currentTimeMillis(), LocalEmbedder.toBytes(LocalEmbedder.embed(v)))
    }
    suspend fun pin(id: Long, p: Boolean) = withContext(Dispatchers.IO) { db.facts().setPinned(id, p) }
    suspend fun deleteFact(id: Long) = withContext(Dispatchers.IO) { db.facts().delete(id) }
    suspend fun deleteCategory(c: String) = withContext(Dispatchers.IO) { db.facts().deleteCategory(c) }
    suspend fun deleteEpisode(id: Long) = withContext(Dispatchers.IO) { db.episodes().delete(id) }

    /** "bhool jao chai" -> memories that look like it, so the caller can confirm before deleting. */
    suspend fun findToForget(what: String): List<FactEntity> = withContext(Dispatchers.IO) {
        val q = LocalEmbedder.embed(what); val toks = LocalEmbedder.tokens(what)
        db.facts().all().filter { f ->
            toks.any { f.value.lowercase().contains(it) || f.slot.contains(it) } ||
                (f.embedding?.let { LocalEmbedder.cosine(q, LocalEmbedder.fromBytes(it)) } ?: 0f) > 0.5f
        }.take(5)
    }

    /** Wipe everything (memory only, chats stay). */
    suspend fun forgetAll() = withContext(Dispatchers.IO) {
        db.facts().deleteAll(); db.episodes().deleteAll(); db.moods().deleteAll()
    }

    /** Factory reset: closes the DB, deletes files and destroys the Keystore key. */
    fun destroy() = MemoryDb.destroy(app)
}
