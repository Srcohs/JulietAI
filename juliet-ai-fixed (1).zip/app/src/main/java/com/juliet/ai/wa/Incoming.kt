package com.juliet.ai.wa

import android.app.Notification
import android.os.Bundle
import android.service.notification.StatusBarNotification

/**
 * Parses notification metadata strictly to enforce private chat identification.
 * WhatsApp groups and channels are identified at the earliest stage and excluded.
 * 1-on-1 private chats are reliably detected even when android.isGroupConversation key is omitted.
 */
class Incoming(
    val pkg: String,
    val key: String,
    val sender: String,
    val text: String,
    val time: Long,
    val fromOther: Boolean,
    val isGroup: Boolean,
    val isChannel: Boolean,
    val verifiedPrivate: Boolean,
    val groupTitle: String?,
    val replyAction: Notification.Action?
) {
    val id: String get() = "$key|$time|${text.hashCode()}"

    companion object {
        fun findReplyAction(n: Notification): Notification.Action? {
            // 1. Direct notification actions
            n.actions?.firstOrNull { a -> a.remoteInputs?.isNotEmpty() == true }?.let { return it }

            // 2. WearableExtender actions (used in some WhatsApp / Android variants)
            try {
                val wearable = Notification.WearableExtender(n)
                wearable.actions?.firstOrNull { a -> a.remoteInputs?.isNotEmpty() == true }?.let { return it }
            } catch (_: Exception) {}

            // 3. Action titled Reply or Jawab with RemoteInput
            n.actions?.firstOrNull { a ->
                val title = a.title?.toString()?.lowercase() ?: ""
                (title.contains("reply") || title.contains("jawab") || title.contains("respond")) &&
                    a.remoteInputs?.isNotEmpty() == true
            }?.let { return it }

            return null
        }

        fun parse(sbn: StatusBarNotification): Incoming? {
            val n = sbn.notification ?: return null
            val x = n.extras ?: return null
            val title = x.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
            val plain = x.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
            val subText = x.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString().orEmpty()

            @Suppress("DEPRECATION")
            val last = x.getParcelableArray(Notification.EXTRA_MESSAGES)?.lastOrNull() as? Bundle
            val text = last?.getCharSequence("text")?.toString() ?: plain
            val senderName = last?.getCharSequence("sender")?.toString()
            val self = x.getCharSequence("android.selfDisplayName")?.toString()
            val fromOther = if (last == null) true
            else !senderName.isNullOrBlank() && !senderName.equals("You", true) && (self == null || senderName != self)

            val hasGroupKey = x.containsKey("android.isGroupConversation")
            val groupFlag = x.getBoolean("android.isGroupConversation", false)
            val conv = x.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString()

            // Strict channel detection
            val isChannel = sbn.key.contains("newsletter", ignoreCase = true) ||
                (sbn.tag?.contains("newsletter", ignoreCase = true) == true) ||
                subText.contains("channel", ignoreCase = true) ||
                title.contains("channel", ignoreCase = true) ||
                sbn.key.contains("@broadcast", ignoreCase = true)

            // Strict group detection
            val isGroup = (hasGroupKey && groupFlag) || !conv.isNullOrBlank() || isChannel ||
                sbn.key.contains("@g.us", ignoreCase = true) ||
                (sbn.tag?.contains("@g.us", ignoreCase = true) == true)

            val summary = (n.flags and Notification.FLAG_GROUP_SUMMARY) != 0

            // Verified 1-on-1 private chat: Not a group, not a channel, from another person, not a group summary
            val verified = !isGroup && !isChannel && fromOther && !summary

            val time = last?.getLong("time", sbn.postTime) ?: sbn.postTime
            val action = findReplyAction(n)

            return Incoming(
                pkg = sbn.packageName,
                key = sbn.key,
                sender = senderName?.takeIf { it.isNotBlank() } ?: title,
                text = text,
                time = time,
                fromOther = fromOther,
                isGroup = isGroup,
                isChannel = isChannel,
                verifiedPrivate = verified,
                groupTitle = conv,
                replyAction = action
            )
        }
    }
}

