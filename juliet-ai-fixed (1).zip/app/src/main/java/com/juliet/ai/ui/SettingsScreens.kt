package com.juliet.ai.ui

import android.Manifest
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Backspace
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.juliet.ai.R
import com.juliet.ai.data.*
import com.juliet.ai.vm.JulietViewModel

@Composable
fun SettingsScreen(vm: JulietViewModel) = Page("Settings", null) {
    val p = LocalPal.current
    val card = RoundedCornerShape(22.dp)
    val glowBrush = androidx.compose.ui.graphics.Brush.linearGradient(listOf(J.Red, J.Crim.copy(alpha = .5f), J.Red))
    // Profile card
    Row(
        Modifier.fillMaxWidth().padding(bottom = 12.dp).clip(card).background(p.card)
            .border(1.dp, p.border, card).clickable { vm.navigate(Screen.Profile) }.padding(14.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Image(painterResource(R.drawable.juliet_emblem), "Profile", Modifier.size(56.dp).clip(CircleShape).border(2.dp, J.Red, CircleShape), contentScale = ContentScale.Crop)
        Column(Modifier.weight(1f)) {
            Text("Profile", color = p.text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Text(vm.s("name"), color = p.mu, fontSize = 15.sp)
        }
        Chevron()
    }
    // Highlighted knowledge card
    Row(
        Modifier.fillMaxWidth().padding(bottom = 12.dp).clip(card)
            .background(androidx.compose.ui.graphics.Brush.horizontalGradient(listOf(J.Dark.copy(alpha = .55f), p.card)))
            .border(1.5.dp, glowBrush, card).clickable { vm.navigate(Screen.Knowledge) }.padding(14.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        TileIcon("🧠", 52)
        Column(Modifier.weight(1f)) {
            Text("Juliet Memory & Auto-Reply Knowledge", color = p.text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Text("Manage your categories, replies and import XML", color = p.mu, fontSize = 14.sp, lineHeight = 18.sp)
        }
        Chevron()
    }
    Group {
        ToggleItem("💬", "WhatsApp Auto-Reply", "Enable / disable bot", vm.s("wa_auto") == "1") { vm.setAutoReply(it) }
        Item("⚙️", "AI Settings", "Gemini & Groq keys and configuration") { vm.navigate(Screen.Conn) }
        Item("🔔", "Permissions", "Microphone, contacts, calls & alerts") { vm.navigate(Screen.Perm) }
        Item("ℹ", "About Juliet", "Version 2.0") { vm.navigate(Screen.About) }
    }
    Sec("MORE")
    Group {
        Item("🎨", "Look & feel", "Theme, orb, motion") { vm.navigate(Screen.Look) }
        Item("🗣", "Voice & language", "Voice, personality, model") { vm.navigate(Screen.Voice) }
        Item("🎙️", "Voice Enrollment & Speaker Lock", "Enroll owner voice, speaker profiles & wake word") { vm.navigate(Screen.VoiceEnrollment) }
        Item("📋", "Juliet Summaries", "WhatsApp & notification summaries") { vm.navigate(Screen.Summaries) }
        Item("⏰", "Smart Reminders", "Scheduled alerts & follow-ups") { vm.navigate(Screen.Reminders) }
        Item("📣", "Voice Announcements", "On/off, calls, messages, Juliet's voice") { vm.navigate(Screen.Announce) }
        Item("🖥️", "Screen Control", "Live screen sharing, visual help") { vm.navigate(Screen.ScreenControl) }
        Item("📱", "Phone control", "Quick actions, speaker, permissions") { vm.navigate(Screen.Phone) }
        Item("🔍", "Diagnostics & Permissions", "Hardware sensors, accessibility & status check") { vm.navigate(Screen.Diagnostics) }
        Item("🛡", "Privacy & data", "What Juliet stores") { vm.navigate(Screen.Privacy) }
    }
}

@Composable
fun LookScreen(vm: JulietViewModel) = Page("Look & feel", { vm.back() }) {
    Group {
        Item("🎨", "Theme", vm.s("theme")) { vm.cycle("theme", listOf("System", "Light", "Dark")) }
        Item("✦", "Orb style", ORBS[vm.s("orb").toIntOrNull() ?: 0].name) { vm.navigate(Screen.Orb) }
        ToggleItem("♿", "Reduce motion", "Calmer screens with fewer animations", vm.s("reduce") == "1") { vm.set("reduce", if (it) "1" else "0") }
    }
}

@Composable
fun VoiceScreen(vm: JulietViewModel) = Page("Voice & language", { vm.back() }) {
    var dlg by remember { mutableStateOf(false) }
    Group {
        Item("✦", "Assistant name", "Juliet", trailing = {})
        Item("☺", "Personality", vm.s("personality")) { vm.cycle("personality", listOf("Normal", "Friendly", "Playful", "Calm", "Professional", "GF Mood")) }
        Item("🌐", "Language", vm.s("language")) { vm.cycle("language", listOf("Auto", "Roman Urdu", "English")) }
        Item("☰", "Response style", vm.s("style")) { vm.cycle("style", listOf("Balanced", "Short", "Detailed")) }
    }
    Sec("PERSONALITY TRAITS (ALL MODES)")
    Group {
        ToggleItem("💞", "Global Jealousy", "Playful jealousy in every mode, only when the context fits", vm.s("jealousy_on") == "1") { vm.set("jealousy_on", if (it) "1" else "0") }
        Item("🎚", "Jealousy Intensity", vm.s("jealousy_level")) { vm.cycle("jealousy_level", listOf("Low", "Medium", "High")) }
        ToggleItem("🎭", "Emotional Reactions", "Caring, excited, sad-aware replies", vm.s("emotions_on") == "1") { vm.set("emotions_on", if (it) "1" else "0") }
        ToggleItem("😉", "Flirting", "Only in compatible modes (never Professional / Calm)", vm.s("flirt_on") == "1") { vm.set("flirt_on", if (it) "1" else "0") }
        ToggleItem("🧠", "Memory", "Remember facts and moods. Say 'bhool jao ...' in chat to delete one", vm.s("memory_on") == "1") { vm.set("memory_on", if (it) "1" else "0") }
    }
    Sec("HOW SHE SOUNDS")
    Group {
        Item("🗣", "Voice", vm.s("voice")) { vm.cycle("voice", listOf("Kore", "Aoede", "Puck", "Charon", "Fenrir", "Leda", "Orus", "Zephyr")) }
        Item("✦", "Voice model", vm.s("model")) { dlg = true }
        Item("🔊", "Voice volume", vm.s("volume") + "%") { vm.cycle("volume", listOf("80", "100", "60", "40")) }
    }
    Sec("LISTENING & WAKE WORD")
    Group {
        ToggleItem("🎙", "Listen when the app opens", "Starts listening as soon as you open Juliet", vm.s("listen") == "1") { vm.set("listen", if (it) "1" else "0") }
        ToggleItem("🔒", "Voice Lock Protection", "Only authorized speaker can execute calls & actions", vm.s("voice_lock_enabled") == "1") { vm.set("voice_lock_enabled", if (it) "1" else "0") }
    }

    if (dlg) AlertDialog(
        onDismissRequest = { dlg = false },
        title = { Text("Voice model") },
        text = {
            Column {
                // Model ids change often. Check ai.google.dev for the current Live API model names.
                listOf("gemini-3.8-live", "gemini-3.8-live-extended-thinking", "gemini-3.1-flash-live-preview", "gemini-2.5-flash-native-audio-preview-12-2025").forEach { m ->
                    TextButton(onClick = { vm.set("model", m); dlg = false }) {
                        Text((if (vm.s("model") == m) "✓ " else "") + m, fontSize = 14.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { dlg = false }) { Text("Close", color = J.Gold) } }
    )
}

@Composable
fun PhoneScreen(vm: JulietViewModel) = Page("Phone Calling & Control", { vm.back() }) {
    val p = LocalPal.current
    var dialNumber by remember { mutableStateOf("") }
    var contactQuery by remember { mutableStateOf("") }
    var showDialpad by remember { mutableStateOf(true) }

    val contacts = remember(contactQuery, vm.permTick) {
        vm.phone.getDeviceContacts(contactQuery)
    }

    // Direct Dialer Card
    Column(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 16.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(p.card)
            .border(1.dp, p.border, RoundedCornerShape(26.dp))
            .padding(18.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Direct Dialer", color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            TextButton(onClick = { showDialpad = !showDialpad }) {
                Text(if (showDialpad) "Hide Pad" else "Show Pad", color = J.Red, fontSize = 13.sp)
            }
        }

        // Dialed number display
        Row(
            Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF0F0A0E))
                .border(1.dp, p.border, RoundedCornerShape(16.dp))
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (dialNumber.isEmpty()) "Enter phone number…" else dialNumber,
                color = if (dialNumber.isEmpty()) p.mu else p.text,
                fontSize = if (dialNumber.length > 12) 18.sp else 22.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.weight(1f)
            )

            if (dialNumber.isNotEmpty()) {
                IconButton(onClick = { dialNumber = dialNumber.dropLast(1) }) {
                    Icon(Icons.AutoMirrored.Rounded.Backspace, "Backspace", tint = p.mu)
                }
            }
        }

        if (showDialpad) {
            val keys = listOf(
                listOf("1" to "", "2" to "ABC", "3" to "DEF"),
                listOf("4" to "GHI", "5" to "JKL", "6" to "MNO"),
                listOf("7" to "PQRS", "8" to "TUV", "9" to "WXYZ"),
                listOf("*" to "", "0" to "+", "#" to "")
            )

            keys.forEach { row ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    row.forEach { (num, letters) ->
                        Box(
                            Modifier
                                .weight(1f)
                                .height(56.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(p.card2)
                                .clickable { dialNumber += num },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(num, color = p.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                if (letters.isNotEmpty()) {
                                    Text(letters, color = p.mu, fontSize = 9.sp, letterSpacing = 1.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Button(
            onClick = {
                if (dialNumber.isNotBlank()) {
                    vm.callContactOrNumber(dialNumber)
                } else {
                    vm.toast = "Please enter a phone number to call"
                }
            },
            modifier = Modifier.fillMaxWidth().height(52.dp).testTag("call_number_btn"),
            colors = ButtonDefaults.buttonColors(containerColor = J.Ok),
            shape = RoundedCornerShape(16.dp)
        ) {
            Icon(Icons.Rounded.Call, null, tint = Color.White, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(10.dp))
            Text("Call ${if (dialNumber.isNotBlank()) dialNumber else "Number"}", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }

    // Contacts Quick Search & Call
    Sec("CONTACTS DIRECT CALL")
    Column(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 16.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(p.card)
            .border(1.dp, p.border, RoundedCornerShape(26.dp))
            .padding(16.dp)
    ) {
        TextField(
            value = contactQuery,
            onValueChange = { contactQuery = it },
            placeholder = { Text("Search contact name or number…", color = p.mu, fontSize = 14.sp) },
            leadingIcon = { Icon(Icons.Rounded.Search, null, tint = p.mu) },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(p.card2),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.Transparent,
                unfocusedContainerColor = Color.Transparent,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                focusedTextColor = p.text,
                unfocusedTextColor = p.text,
                cursorColor = J.Crim
            )
        )

        Spacer(Modifier.height(10.dp))

        contacts.take(8).forEach { (name, num) ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 5.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(p.card2)
                    .clickable { dialNumber = num }
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(name, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Text(num, color = p.mu, fontSize = 13.sp)
                }

                Box(
                    Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(J.Ok)
                        .clickable { vm.callContactOrNumber(num) },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.Call, "Call $name", tint = Color.White, modifier = Modifier.size(20.dp))
                }
            }
        }
    }

    Sec("CALL AUDIO & DEVICE CONTROL")
    Group {
        Item("🔊", "Speakerphone & Volume", "Route call audio to speaker, earpiece, or bluetooth") { vm.navigate(Screen.ScreenControl) }
        Item("🖥️", "Screen Control & Live Sharing", "Screen capture, AI vision, actions") { vm.navigate(Screen.ScreenControl) }
        Item("✦", "Quick actions", "Set up the tools Juliet can run") { vm.navigate(Screen.Quick) }
        Item("🔒", "App permissions", "Microphone, contacts, calls") { vm.navigate(Screen.Perm) }
    }
}

@Composable
fun QuickScreen(vm: JulietViewModel, onMic: () -> Unit) = Page("Quick actions", { vm.back() }) {
    val p = LocalPal.current
    Sub("Tap any tool to launch or ask Juliet directly in Roman Urdu or English.")
    class Q(val icon: String, val title: String, val sub: String, val example: Boolean, val act: () -> Unit)
    val items = listOf(
        Q("🤖", "WhatsApp Bot", "Menu trees & XML import", false) { vm.navigate(Screen.Knowledge) },
        Q("📞", "Call someone", "Dial keypad & contacts", false) { vm.navigate(Screen.Phone) },
        Q("✏", "Photo Sketch", "Turn photos into art", false) { vm.navigate(Screen.PhotoSketch) },
        Q("🌐", "Build a website", "Live HTML/CSS interactive preview", false) { vm.navigate(Screen.WebsiteBuilder) },
        Q("📝", "Write notes & code", "Kotlin, Python, summaries", false) { vm.navigate(Screen.NotesAndCode) },
        Q("📋", "Juliet Summaries", "Summarize WhatsApp & notifications", false) { vm.navigate(Screen.Summaries) },
        Q("⏰", "Smart Reminders", "Tasks, deadlines & alerts", false) { vm.navigate(Screen.Reminders) },
        Q("🖥️", "Screen Control", "Live screen sharing & help", false) { vm.navigate(Screen.ScreenControl) },
        Q("🔊", "Call Speaker", "Speaker & volume control", false) { vm.navigate(Screen.ScreenControl) },
        Q("▦", "Open an app", "YouTube kholo", true) { vm.draft = "YouTube kholo"; vm.navigate(Screen.Chat) },
        Q("💬", "Send a message", "Papa ko WhatsApp karo", true) { vm.draft = "Papa ko WhatsApp karo"; vm.navigate(Screen.Chat) },
        Q("🎙", "Talk to Juliet", "Start a voice conversation", false) { vm.navigate(Screen.Home); onMic() },
        Q("🔒", "App permissions", "Microphone, calls, contacts", false) { vm.navigate(Screen.Perm) }
    )
    items.chunked(2).forEach { row ->
        Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            row.forEach { q ->
                val sh = RoundedCornerShape(28.dp)
                Column(Modifier.weight(1f).heightIn(min = 140.dp).clip(sh).background(p.card).border(1.dp, p.border, sh).clickable(onClick = q.act).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    TileIcon(q.icon, 48)
                    Text(q.title, color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Medium)
                    Text(if (q.example) "\"${q.sub}\"" else q.sub, color = p.mu, fontSize = 13.sp)
                }
            }
            if (row.size == 1) Spacer(Modifier.weight(1f))
        }
    }
}

@Composable
fun PermScreen(vm: JulietViewModel, askPerm: (String, (Boolean) -> Unit) -> Unit) = Page("Permissions", { vm.back() }) {
    val ctx = LocalContext.current
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.permTick++ }
    vm.permTick
    fun ok(perm: String) = ContextCompat.checkSelfPermission(ctx, perm) == android.content.pm.PackageManager.PERMISSION_GRANTED
    Sub("Allow only what you want Juliet to use. You can change any of these later.")
    @Composable fun row(icon: String, title: String, sub: String, perm: String) {
        val on = ok(perm)
        Item(icon, title, sub, trailing = {
            val bg = if (on) J.Ok.copy(alpha = .15f) else LocalPal.current.card2
            Text(if (on) "Allowed" else "Allow", color = if (on) J.Ok else J.Red, fontSize = 15.sp,
                modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(bg).padding(horizontal = 14.dp, vertical = 8.dp))
            Chevron()
        }, onClick = { if (!on) askPerm(perm) { vm.permTick++ } })
    }
    Group {
        row("🎙", "Microphone", "Needed for voice conversations", Manifest.permission.RECORD_AUDIO)
        row("👤", "Contacts", "Lets Juliet find a number when you say a name", Manifest.permission.READ_CONTACTS)
        row("📞", "Phone Calls", "Juliet can place calls directly", Manifest.permission.CALL_PHONE)
        val nOk = Build.VERSION.SDK_INT < 33 || ok(Manifest.permission.POST_NOTIFICATIONS)
        Item("🔔", "Notifications", "Reminders and alerts from Juliet", trailing = {
            Text(if (nOk) "Allowed" else "Open Settings", color = if (nOk) J.Ok else J.Red, fontSize = 15.sp,
                modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(if (nOk) J.Ok.copy(alpha = .15f) else LocalPal.current.card2).padding(horizontal = 14.dp, vertical = 8.dp))
            Chevron()
        }, onClick = {
            ctx.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        })
    }
    Sec("VOICE ANNOUNCEMENTS")
    Group {
        ToggleItem("📣", "Notification Announcements", "Spoken alerts for incoming calls & notifications", vm.s("ann_on") == "1") { vm.set("ann_on", if (it) "1" else "0") }
        Item("⚙️", "Announcement Options", "Configure apps, caller speech & privacy mode") { vm.navigate(Screen.Announce) }
    }
}

@Composable
private fun KeyCard(title: String, status: String, desc: String, hint: String, save: String, link: String, url: String, onSave: (String) -> Unit) {
    val p = LocalPal.current
    val uri = LocalUriHandler.current
    var v by remember { mutableStateOf("") }
    val sh = RoundedCornerShape(26.dp)
    Column(Modifier.fillMaxWidth().padding(bottom = 16.dp).clip(sh).background(p.card).border(1.dp, p.border, sh).padding(18.dp)) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text(title, color = p.text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Text(status, color = if (status.startsWith("✔")) J.Ok else p.mu, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        }
        Text(desc, color = p.mu, fontSize = 16.sp, modifier = Modifier.padding(top = 6.dp, bottom = 14.dp))
        OutlinedTextField(v, { v = it }, Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation(),
            placeholder = { Text(hint, color = p.mu) }, shape = RoundedCornerShape(26.dp),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = J.Red, unfocusedBorderColor = p.border, cursorColor = J.Crim, focusedTextColor = p.text, unfocusedTextColor = p.text))
        Spacer(Modifier.height(14.dp))
        GradientButton(save, Modifier.fillMaxWidth()) { if (v.isNotBlank()) { onSave(v); v = "" } }
        Text("$link ↗", color = J.Crim, fontSize = 17.sp, modifier = Modifier.padding(top = 14.dp).clickable { uri.openUri(url) })
    }
}

@Composable
fun ConnScreen(vm: JulietViewModel) = Page("Connections", { vm.back() }) {
    Sub("Juliet talks and chats through your own keys. They are stored only on this phone.")
    KeyCard("Voice - Gemini key", vm.geminiStatus(), "Powers live voice conversations.", "Paste your Gemini API key", "Save Gemini key",
        "Get a free key at Google AI Studio", "https://aistudio.google.com/apikey") { vm.saveGemini(it) }
    KeyCard("Chat - Groq keys", vm.groqStatus(), "Fast typed replies. Add several keys, separated by commas - they take turns if one is rate limited.",
        "gsk_..., gsk_...", "Save Groq keys", "Get a free key at Groq", "https://console.groq.com/keys") { vm.saveGroq(it) }
}

@Composable
fun PrivacyScreen(vm: JulietViewModel) = Page("Privacy & data", { vm.back() }) {
    var confirm by remember { mutableStateOf(false) }
    Sub("Juliet has no account and no server. Your keys, chats and settings are stored encrypted on this phone only. Ahsan Raza never receives your data.")
    Group {
        Item("☰", "What Juliet stores", "Chats, settings and keys, encrypted on this phone", trailing = {})
        Item("🌐", "Where your messages go", "Voice goes to Google Gemini and typed chat to Groq, using your own keys. Contact numbers never leave this phone.", trailing = {})
        Item("⚠", "Free Gemini keys", "Google may use data sent with a free-tier key to improve its products. For stricter privacy use a Gemini key with billing enabled.", trailing = {})
        Item("🔒", "Permissions", "What Juliet can use on this phone") { vm.navigate(Screen.Perm) }
    }
    Sec("RESET")
    Group { Item("🗑", "Clear all app data", "Erases everything Juliet stored here and restarts it") { confirm = true } }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false }, title = { Text("Clear all app data?") },
        text = { Text("This deletes your keys, chats and settings from this phone.") },
        confirmButton = { TextButton(onClick = { confirm = false; vm.clearAll() }) { Text("Clear", color = J.Red) } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } }
    )
}

@Composable
fun ProfileScreen(vm: JulietViewModel) = Page("Profile", { vm.back() }) {
    val p = LocalPal.current
    var editName by remember { mutableStateOf(false) }
    var nameDraft by remember { mutableStateOf("") }
    if (editName) AlertDialog(
        onDismissRequest = { editName = false }, title = { Text("Your name") },
        text = { OutlinedTextField(nameDraft, { nameDraft = it }, singleLine = true) },
        confirmButton = { TextButton(onClick = { vm.setName(nameDraft); editName = false }) { Text("Save") } },
        dismissButton = { TextButton(onClick = { editName = false }) { Text("Cancel") } }
    )
    LaunchedEffect(editName) { if (editName) nameDraft = vm.s("name") }
    Image(painterResource(R.drawable.juliet_emblem), "JULIET AI", Modifier.align(Alignment.CenterHorizontally).padding(top = 10.dp).size(124.dp).clip(CircleShape).border(2.dp, p.border, CircleShape), contentScale = ContentScale.Crop)
    Text(vm.s("name"), color = p.text, fontSize = 40.sp, fontFamily = FontFamily.Serif, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp))
    Sec("YOU")
    Group {
        Item("✎", "Your name", vm.s("name")) { editName = true }
        Item("🛡", "Privacy controls") { vm.navigate(Screen.Privacy) }
    }
    Sec("YOUR ASSISTANT")
    Group {
        Item("✦", "Name", "Juliet", trailing = {})
        Item("☺", "Personality", vm.s("personality")) { vm.navigate(Screen.Voice) }
        Item("🌐", "Language", vm.s("language"), trailing = {})
        Item("🗣", "Voice", vm.s("voice"), trailing = {})
    }
}

@Composable
fun OrbScreen(vm: JulietViewModel) = Page("Orb style", { vm.back() }) {
    val p = LocalPal.current
    val cur = vm.s("orb").toIntOrNull() ?: 0
    var mode by remember { mutableIntStateOf(0) }
    val reduce = vm.s("reduce") == "1"
    val sh = RoundedCornerShape(30.dp)

    // Main interactive preview card
    Column(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 16.dp)
            .clip(sh)
            .background(p.card)
            .border(1.dp, p.border, sh)
            .padding(vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        JOrb(
            index = cur,
            modifier = Modifier.size(240.dp),
            mode = mode,
            animate = !reduce
        )
        Text(ORBS[cur].name, color = p.text, fontSize = 40.sp, fontFamily = FontFamily.Serif)
        Text(ORBS[cur].sub, color = p.mu, fontSize = 18.sp)

        // Idle / Listening / Speaking state selector tabs
        Row(
            Modifier.padding(top = 18.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val states = listOf("Idle" to Color(0xFF8A2BE2), "Listening" to Color(0xFF0096C7), "Speaking" to Color(0xFFB5179E))
            states.forEachIndexed { i, (label, activeColor) ->
                val isSel = mode == i
                val bg = if (isSel) activeColor else p.card2
                val textColor = if (isSel) Color.White else p.mu
                Text(
                    text = label,
                    color = textColor,
                    fontSize = 17.sp,
                    fontWeight = if (isSel) FontWeight.SemiBold else FontWeight.Normal,
                    modifier = Modifier
                        .clip(RoundedCornerShape(30.dp))
                        .background(bg)
                        .clickable { mode = i }
                        .padding(horizontal = 22.dp, vertical = 12.dp)
                )
            }
        }
    }

    // Grid of all 6 selectable orb styles
    ORBS.chunked(2).forEachIndexed { r, pair ->
        Row(
            Modifier.fillMaxWidth().padding(bottom = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            pair.forEachIndexed { c, o ->
                val i = r * 2 + c
                val sel = i == cur
                val s2 = RoundedCornerShape(28.dp)
                val borderCol = if (sel) Color(0xFF9D4EDD) else p.border
                Column(
                    Modifier
                        .weight(1f)
                        .clip(s2)
                        .background(p.card)
                        .border(if (sel) 2.dp else 1.dp, borderCol, s2)
                        .clickable { vm.set("orb", i.toString()) }
                        .padding(vertical = 18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    JOrb(
                        index = i,
                        modifier = Modifier.size(96.dp),
                        mode = 0,
                        animate = !reduce
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = o.name + if (sel) " ✓" else "",
                        color = if (sel) Color(0xFFC77DFF) else p.text,
                        fontSize = 20.sp,
                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium
                    )
                    Text(o.sub, color = p.mu, fontSize = 15.sp)
                }
            }
        }
    }
}

// Put your real links here. Empty means "not added yet".
private val LINKS = mapOf(
    "YouTube" to "https://youtube.com/@baloch0.5?si=HAm6wVkdKr4dv5sq",
    "Facebook" to "https://www.facebook.com/share/1DwDaEXN97/"
)

@Composable
fun AboutScreen(vm: JulietViewModel) = Page("About Juliet", { vm.back() }) {
    val p = LocalPal.current
    val uri = LocalUriHandler.current
    fun open(n: String) { val u = LINKS[n].orEmpty(); if (u.isBlank()) vm.toast = "Add your $n link in AboutScreen" else uri.openUri(u) }
    Image(painterResource(R.drawable.juliet_logo), "JULIET AI logo", Modifier.fillMaxWidth().padding(bottom = 16.dp).clip(RoundedCornerShape(28.dp)), contentScale = ContentScale.FillWidth)
    Group {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Image(painterResource(R.drawable.juliet_emblem), null, Modifier.size(64.dp).clip(RoundedCornerShape(19.dp)).border(1.dp, p.border, RoundedCornerShape(19.dp)), contentScale = ContentScale.Crop)
            Column {
                Text("JULIET AI", color = p.text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                Text("Your Personal AI Assistant · Smart · Fast · Always With You", color = p.mu, fontSize = 14.sp, lineHeight = 18.sp)
                Text("Version 2.0", color = p.text, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp).border(1.dp, J.Red, RoundedCornerShape(20.dp)).padding(horizontal = 12.dp, vertical = 2.dp))
            }
        }
    }
    Sub("Juliet AI is a voice-first AI assistant designed to make your daily life easier. Talk or type to chat, ask questions, open apps, call and message your contacts, build websites and sketch your photos — all in one place.")
    Sec("DEVELOPER")
    Group {
        Item("👥", "Ahsan Raza", "Developer & Creator of JULIET AI", trailing = {})
        Item("👤", "Ahsan Raza", "Co-Founder of JULIET AI", trailing = {})
        Item("🎓", "Computer Science Student", "Passionate about AI and Software Development", trailing = {})
        Item("📍", "From Lahore, Pakistan", "Turning ideas into real AI solutions", trailing = {})
    }
    Sec("CONNECT WITH ME")
    Row(Modifier.fillMaxWidth().padding(bottom = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("▶️" to "YouTube", "📘" to "Facebook").forEach { (e, n) ->
            val sh = RoundedCornerShape(22.dp)
            Column(Modifier.weight(1f).clip(sh).background(p.card).border(1.dp, p.border, sh).clickable { open(n) }.padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(e, fontSize = 28.sp); Text(n, color = p.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold); Text("Ahsan Raza", color = p.mu, fontSize = 11.sp)
            }
        }
    }
    Sec("APP INFO")
    Group {
        Item("📦", "App Version", null, trailing = { Text("2.0", color = p.mu, fontSize = 18.sp) })
        Item("🛡", "Privacy Policy") { vm.navigate(Screen.Privacy) }
    }
    PersonCard("CEO", { Image(painterResource(R.drawable.ahsan), "Ahsan Raza", Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }, "Ahsan Raza", "@ahsanraza",
        "I build Juliet AI — a voice-first AI assistant that lives on your phone, talks like a person, and helps you get things done hands-free. Thank you for using it. Your feedback shapes what I build next.", true) { open(it) }
    PersonCard("ROMEO", { Image(painterResource(R.drawable.romeo), "Romeo", Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }, "Romeo", "Featured Companion & Experience Strategist",
        "As co-creator of Juliet AI, I help shape the product vision and experience behind it — so Juliet keeps getting smarter, simpler, and more useful for everyone.", false) { open(it) }
}

@Composable
private fun PersonCard(label: String, photo: @Composable BoxScope.() -> Unit, name: String, handle: String, quote: String, links: Boolean, open: (String) -> Unit) {
    val p = LocalPal.current
    val sh = RoundedCornerShape(30.dp)
    Column(Modifier.fillMaxWidth().padding(bottom = 16.dp).clip(sh).background(Brush.verticalGradient(listOf(J.Red.copy(alpha = .12f), p.card)))
        .border(1.dp, p.border, sh).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = J.Red, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 3.sp)
        Spacer(Modifier.height(12.dp))
        Box(Modifier.size(170.dp).clip(CircleShape).border(3.dp, J.Red, CircleShape).background(Color(0xFF1B0610)), Alignment.Center, content = photo)
        Text(name, color = p.text, fontSize = 38.sp, fontFamily = FontFamily.Serif, modifier = Modifier.padding(top = 14.dp))
        Text(handle, color = J.Crim, fontSize = 20.sp, fontFamily = FontFamily.Cursive, textAlign = TextAlign.Center)
        Text(quote, color = p.mu, fontSize = 17.sp, lineHeight = 25.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(vertical = 14.dp))
        if (links) Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("Facebook", "YouTube").forEach { n ->
                Text(n, color = p.text, fontSize = 18.sp, modifier = Modifier.clip(RoundedCornerShape(30.dp)).border(1.dp, J.Red, RoundedCornerShape(30.dp)).clickable { open(n) }.padding(horizontal = 20.dp, vertical = 12.dp))
            }
        }
    }
}
