package com.juliet.ai.screen

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class JulietAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: JulietAccessibilityService? = null
            private set

        fun isRunning(): Boolean = instance != null

        val CONSEQUENTIAL_KEYWORDS = Regex(
            "(?i)\\b(delete|remove|erase|clear\\s*all|format|reset|pay|transfer|send\\s*money|purchase|buy|confirm\\s*payment|uninstall)\\b"
        )
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        if (instance === this) {
            instance = null
        }
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Can track active window/app changes if needed
    }

    override fun onInterrupt() {
        // Accessibility service interrupted
    }

    /**
     * Extracts all visible text, interactive controls, and headings on the current screen.
     * Passwords and sensitive input fields are securely masked.
     */
    fun dumpScreenText(): String {
        val root = rootInActiveWindow ?: return "(Screen content unavailable - screen locked or permission needed)"
        val sb = StringBuilder()
        val visited = mutableSetOf<AccessibilityNodeInfo>()
        fun traverse(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || visited.contains(node)) return
            visited.add(node)
            val isPass = node.isPassword
            val text = if (isPass) "[Password Protected]" else node.text?.toString()?.trim()
            val desc = if (isPass) "[Hidden]" else node.contentDescription?.toString()?.trim()
            val isClickable = node.isClickable
            val isEditable = node.isEditable

            val item = when {
                !text.isNullOrBlank() && !desc.isNullOrBlank() && text != desc -> "$text ($desc)"
                !text.isNullOrBlank() -> text
                !desc.isNullOrBlank() -> desc
                else -> null
            }

            if (item != null) {
                val tag = when {
                    isPass -> "[Protected Input] "
                    isEditable -> "[Input Field] "
                    isClickable -> "[Button] "
                    else -> ""
                }
                sb.append("  ".repeat(depth)).append(tag).append(item).append("\n")
            }

            for (i in 0 until node.childCount) {
                traverse(node.getChild(i), depth + 1)
            }
        }
        traverse(root, 0)
        return if (sb.isBlank()) "(No readable text detected on screen)" else sb.toString().trim()
    }

    /**
     * Checks if a target label implies a consequential/irreversible action (e.g. Delete, Pay, Transfer).
     */
    fun isConsequential(targetText: String): Boolean = CONSEQUENTIAL_KEYWORDS.containsMatchIn(targetText)

    /**
     * Finds an interactive node containing [text] and performs a click.
     */
    fun clickByText(query: String, allowConsequential: Boolean = false): Boolean {
        if (!allowConsequential && isConsequential(query)) {
            return false // Needs explicit confirmation
        }
        val root = rootInActiveWindow ?: return false
        val q = query.trim().lowercase()
        var clicked = false

        fun search(node: AccessibilityNodeInfo?): Boolean {
            if (node == null) return false
            val t = node.text?.toString()?.lowercase() ?: ""
            val d = node.contentDescription?.toString()?.lowercase() ?: ""
            if (t.contains(q) || d.contains(q)) {
                var target: AccessibilityNodeInfo? = node
                while (target != null && !target.isClickable) {
                    target = target.parent
                }
                if (target != null && target.isClickable) {
                    clicked = target.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    return true
                }
            }
            for (i in 0 until node.childCount) {
                if (search(node.getChild(i))) return true
            }
            return false
        }

        search(root)
        return clicked
    }

    /**
     * Finds an interactive node containing [query] and performs a click, returning a voice-friendly status string.
     */
    fun clickNodeByText(query: String, allowConsequential: Boolean = false): String {
        if (!allowConsequential && isConsequential(query)) {
            return "This action '$query' may delete data or confirm a transaction. Please confirm aloud if you wish to proceed."
        }
        val root = rootInActiveWindow ?: return "Screen content is currently unavailable or the phone is locked."
        val q = query.trim().lowercase()
        var clickedLabel: String? = null

        fun search(node: AccessibilityNodeInfo?): Boolean {
            if (node == null) return false
            val t = node.text?.toString() ?: ""
            val d = node.contentDescription?.toString() ?: ""
            if (t.lowercase().contains(q) || d.lowercase().contains(q)) {
                var target: AccessibilityNodeInfo? = node
                while (target != null && !target.isClickable) {
                    target = target.parent
                }
                if (target != null && target.isClickable) {
                    val label = if (t.isNotBlank()) t else if (d.isNotBlank()) d else query
                    val ok = target.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    if (ok) {
                        clickedLabel = label
                        return true
                    }
                }
            }
            for (i in 0 until node.childCount) {
                if (search(node.getChild(i))) return true
            }
            return false
        }

        search(root)
        return if (clickedLabel != null) {
            "Clicked '$clickedLabel'."
        } else {
            "Could not find any clickable button or item matching '$query' on the current screen."
        }
    }

    /**
     * Dispatches a tap gesture at the specified screen coordinates.
     */
    fun tapAt(x: Float, y: Float, callback: ((Boolean) -> Unit)? = null): Boolean {
        val path = Path().apply {
            moveTo(x, y)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, 100)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                callback?.invoke(true)
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                callback?.invoke(false)
            }
        }, null)
    }

    /**
     * Scrolls the current screen forward or backward.
     */
    fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD

        fun findScrollable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
            if (node == null) return null
            if (node.isScrollable) return node
            for (i in 0 until node.childCount) {
                val found = findScrollable(node.getChild(i))
                if (found != null) return found
            }
            return null
        }

        val scrollNode = findScrollable(root)
        return scrollNode?.performAction(action) ?: false
    }

    /**
     * Directional scrolling with voice feedback ("down", "up", "forward", "backward", "next", "previous").
     */
    fun scrollScreen(direction: String): String {
        val dir = direction.lowercase().trim()
        val forward = dir in setOf("down", "forward", "next", "neeche", "aage", "agla")
        val ok = scroll(forward)
        return if (ok) {
            if (forward) "Scrolled down." else "Scrolled up."
        } else {
            "Unable to scroll in this view."
        }
    }

    /**
     * Submits search in the current input field by clicking a search button or executing search action.
     */
    fun submitSearch(): String {
        val root = rootInActiveWindow ?: return "Screen content unavailable."
        // Look for search button or enter
        val searchKeywords = setOf("search", "find", "go", "submit", "dhoondo", "khojein")
        for (kw in searchKeywords) {
            if (clickByText(kw)) {
                return "Submitted search via '$kw' button."
            }
        }
        // Fallback: try click on focused input or submit action
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (focused != null) {
            val ok = focused.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            if (ok) return "Search submitted."
        }
        return "Search command sent."
    }


    /**
     * Reads the currently focused element for blind or visually impaired users.
     */
    fun readFocusedElement(): String {
        val root = rootInActiveWindow ?: return "Screen is locked or inaccessible."
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY)
            ?: root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (focused == null) {
            return "No specific element is currently highlighted. Say 'screen par kya hai' to read everything visible."
        }
        val t = focused.text?.toString() ?: ""
        val d = focused.contentDescription?.toString() ?: ""
        val role = when {
            focused.isPassword -> "Password Field"
            focused.isEditable -> "Text Input Field"
            focused.isClickable -> "Button"
            focused.isCheckable -> if (focused.isChecked) "Checked Box" else "Unchecked Box"
            else -> "Item"
        }
        val label = if (t.isNotBlank()) t else d
        return if (label.isNotBlank()) {
            "Focused $role: '$label'."
        } else {
            "Focused on a $role."
        }
    }

    /**
     * Enters text into the focused editable field or the first editable field found.
     */
    fun enterText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        var focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)

        if (focused == null) {
            fun findEditable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
                if (node == null) return null
                if (node.isEditable) return node
                for (i in 0 until node.childCount) {
                    val found = findEditable(node.getChild(i))
                    if (found != null) return found
                }
                return null
            }
            focused = findEditable(root)
        }

        if (focused != null && focused.isEditable) {
            val args = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            }
            return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        }
        return false
    }

    /** Locks the screen (API 28+). */
    fun lockScreen(): Boolean =
        android.os.Build.VERSION.SDK_INT >= 28 && performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)

    fun goBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun goHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun openRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)
}

