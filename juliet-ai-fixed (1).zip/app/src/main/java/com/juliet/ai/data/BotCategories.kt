package com.juliet.ai.data

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.ByteArrayInputStream
import java.io.InputStream

/** User-owned WhatsApp menu tree. No bundled personal/business facts are seeded. */
data class BotNode(
    val id: String,
    val title: String,
    val type: String, // category, subcategory, option
    val parentId: String = "",
    val answer: String = "",
    val enabled: Boolean = true
)

data class XmlImportResult(val imported: Int, val errors: List<String>)

class BotCategories(private val prefs: Prefs) {
    private val key = "wa_bot_categories_v2"

    @Synchronized fun all(): List<BotNode> = try {
        val a = JSONArray(prefs.get(key, "[]"))
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            BotNode(o.optString("id"), o.optString("title"), o.optString("type", "category"), o.optString("parentId"), o.optString("answer"), o.optBoolean("enabled", true))
        }
    } catch (_: Exception) { emptyList() }

    @Synchronized fun save(nodes: List<BotNode>): Boolean {
        val a = JSONArray()
        nodes.forEach { n -> a.put(JSONObject().put("id", n.id).put("title", n.title).put("type", n.type).put("parentId", n.parentId).put("answer", n.answer).put("enabled", n.enabled)) }
        val raw = a.toString(); prefs.put(key, raw); return prefs.get(key) == raw
    }

    fun add(title: String, type: String, parentId: String = "", answer: String = ""): Boolean {
        val t = title.trim(); if (t.isEmpty() || t.length > 120) return false
        if (type !in setOf("category", "subcategory", "option")) return false
        val nodes = all()
        if (type != "category" && nodes.none { it.id == parentId && it.enabled }) return false
        if (nodes.any { it.type == type && it.parentId == parentId && it.title.equals(t, true) }) return false
        return save(nodes + BotNode(java.util.UUID.randomUUID().toString(), t, type, parentId, answer.trim()))
    }

    fun rename(id: String, title: String): Boolean {
        val t = title.trim(); if (t.isEmpty()) return false
        val nodes = all(); if (nodes.none { it.id == id }) return false
        return save(nodes.map { if (it.id == id) it.copy(title = t) else it })
    }

    fun updateAnswer(id: String, answer: String): Boolean {
        val nodes = all(); if (nodes.none { it.id == id && it.type == "option" }) return false
        return save(nodes.map { if (it.id == id) it.copy(answer = answer.trim()) else it })
    }

    fun delete(id: String): Boolean {
        val nodes = all(); if (nodes.none { it.id == id }) return false
        val remove = mutableSetOf(id)
        var changed = true
        while (changed) { changed = false; nodes.filter { it.parentId in remove }.forEach { if (remove.add(it.id)) changed = true } }
        return save(nodes.filterNot { it.id in remove })
    }

    /** Structural validation. Returns human-readable errors; empty list means the file is safe to import. */
    fun validateXml(bytes: ByteArray): List<String> {
        if (bytes.isEmpty()) return listOf("The file is empty.")
        if (bytes.size > 2_000_000) return listOf("The file is larger than 2 MB.")
        val errors = mutableListOf<String>()
        try {
            val p = XmlPullParserFactory.newInstance().newPullParser()
            p.setInput(ByteArrayInputStream(bytes), null)
            val stack = mutableListOf<String>()
            var cats = 0
            var e = p.eventType
            while (e != XmlPullParser.END_DOCUMENT && errors.size < 10) {
                when (e) {
                    XmlPullParser.DOCDECL -> errors.add("DOCTYPE declarations are not allowed.")
                    XmlPullParser.START_TAG -> {
                        val n = p.name.lowercase(); val line = p.lineNumber
                        val name = (p.getAttributeValue(null, "name") ?: p.getAttributeValue(null, "title") ?: p.getAttributeValue(null, "label")).orEmpty()
                        if (stack.isEmpty() && n != "bot" && n != "juliet") errors.add("Line $line: root element must be <bot> or <juliet>, found <${p.name}>.")
                        when (n) {
                            "category" -> { cats++; if (name.isBlank()) errors.add("Line $line: <category> needs a name attribute.") }
                            "subcategory", "sub-category" -> {
                                if ("category" !in stack) errors.add("Line $line: <subcategory> must be inside a <category>.")
                                if (name.isBlank()) errors.add("Line $line: <subcategory> needs a name attribute.")
                            }
                            "option", "item" -> {
                                if ("category" !in stack) errors.add("Line $line: <option> must be inside a <category>.")
                                if (name.isBlank()) errors.add("Line $line: <option> needs a name attribute.")
                            }
                        }
                        stack.add(n)
                    }
                    XmlPullParser.END_TAG -> if (stack.isNotEmpty()) stack.removeAt(stack.size - 1)
                }
                e = p.next()
            }
            if (errors.isEmpty() && cats == 0) errors.add("No <category> elements were found.")
        } catch (ex: org.xmlpull.v1.XmlPullParserException) {
            errors.add("Invalid XML: ${ex.message ?: "could not be parsed"}")
        } catch (ex: java.io.IOException) {
            errors.add("Could not read the file.")
        }
        return errors
    }

    /** Validates first, then imports. Nothing is written if validation fails; existing entries are merged, never overwritten. */
    fun importChecked(input: InputStream): XmlImportResult {
        val bytes = try { input.readBytes() } catch (_: Exception) { return XmlImportResult(0, listOf("Could not read the file.")) }
        val errors = validateXml(bytes)
        if (errors.isNotEmpty()) return XmlImportResult(0, errors)
        return try { XmlImportResult(importXml(ByteArrayInputStream(bytes)), emptyList()) }
        catch (ex: Exception) { XmlImportResult(0, listOf("Import failed: ${ex.message ?: "unknown error"}")) }
    }

    fun importXml(input: InputStream): Int {
        val parser = XmlPullParserFactory.newInstance().newPullParser()
        parser.setInput(input, "UTF-8")
        val parsed = mutableListOf<BotNode>()
        val parents = mutableMapOf<String, String>()
        var currentOption: BotNode? = null
        var currentTag = ""
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    currentTag = parser.name.lowercase()
                    val type = when (currentTag) {
                        "category" -> "category"
                        "subcategory", "sub-category" -> "subcategory"
                        "option", "item" -> "option"
                        else -> ""
                    }
                    if (type.isNotEmpty()) {
                        val title = parser.getAttributeValue(null, "name")
                            ?: parser.getAttributeValue(null, "title")
                            ?: parser.getAttributeValue(null, "label")
                            ?: ""
                        if (title.isNotBlank()) {
                            val parent = when (type) {
                                "category" -> ""
                                "subcategory" -> parents["category"].orEmpty()
                                else -> parents["subcategory"] ?: parents["category"].orEmpty()
                            }
                            val id = java.util.UUID.randomUUID().toString()
                            val answer = parser.getAttributeValue(null, "answer")
                                ?: parser.getAttributeValue(null, "reply")
                                ?: ""
                            val node = BotNode(id, title.trim(), type, parent, answer.trim())
                            parsed.add(node)
                            if (type == "category") {
                                parents["category"] = id
                                parents.remove("subcategory")
                            }
                            if (type == "subcategory") parents["subcategory"] = id
                            if (type == "option") currentOption = node
                        }
                    }
                }
                XmlPullParser.TEXT -> {
                    if (currentOption != null && (currentTag == "reply" || currentTag == "answer")) {
                        val text = parser.text.orEmpty().trim()
                        if (text.isNotBlank()) {
                            val idx = parsed.indexOfFirst { it.id == currentOption?.id }
                            if (idx >= 0) {
                                parsed[idx] = parsed[idx].copy(answer = (parsed[idx].answer + " " + text).trim())
                            }
                        }
                    }
                }
                XmlPullParser.END_TAG -> {
                    val end = parser.name.lowercase()
                    if (end == "option" || end == "item") currentOption = null
                    currentTag = ""
                }
            }
            event = parser.next()
        }
        if (parsed.isEmpty()) return 0
        val current = all().toMutableList()
        // If an imported category name already exists, merge under the existing category.
        val idMap = mutableMapOf<String, String>()
        parsed.forEach { n ->
            val mappedParent = idMap[n.parentId] ?: n.parentId
            val existing = current.firstOrNull { it.type == n.type && it.parentId == mappedParent && it.title.equals(n.title, true) }
            if (existing != null) {
                idMap[n.id] = existing.id
                if (n.type == "option" && n.answer.isNotBlank() && existing.answer.isBlank()) {
                    val idx = current.indexOfFirst { it.id == existing.id }
                    if (idx >= 0) current[idx] = current[idx].copy(answer = n.answer)
                }
            } else {
                val parent = if (n.parentId.isBlank()) "" else mappedParent
                current.add(n.copy(parentId = parent))
                idMap[n.id] = n.id
            }
        }
        save(current)
        return parsed.size
    }

    fun exportXml(): String {
        val sb = StringBuilder()
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
        sb.append("<bot>\n")
        val cats = menu("")
        cats.forEach { cat ->
            sb.append("    <category name=\"${escapeXml(cat.title)}\">\n")
            val subs = menu(cat.id)
            subs.forEach { sub ->
                sb.append("        <subcategory name=\"${escapeXml(sub.title)}\">\n")
                val opts = menu(sub.id)
                opts.forEach { opt ->
                    sb.append("            <option name=\"${escapeXml(opt.title)}\" answer=\"${escapeXml(opt.answer)}\" />\n")
                }
                sb.append("        </subcategory>\n")
            }
            sb.append("    </category>\n")
        }
        sb.append("</bot>\n")
        return sb.toString()
    }

    private fun escapeXml(s: String): String = s
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&apos;")

    fun menu(parentId: String = ""): List<BotNode> = all().filter { it.enabled && it.parentId == parentId }.sortedBy { it.title.lowercase() }
    fun find(id: String): BotNode? = all().firstOrNull { it.id == id }

    companion object {
        fun importFromUriChecked(ctx: Context, uri: Uri, store: BotCategories): XmlImportResult =
            ctx.contentResolver.openInputStream(uri)?.use { store.importChecked(it) } ?: XmlImportResult(0, listOf("Could not open the selected file."))
        fun importFromUri(ctx: Context, uri: Uri, store: BotCategories): Int = ctx.contentResolver.openInputStream(uri)?.use { store.importXml(it) } ?: 0
    }
}
