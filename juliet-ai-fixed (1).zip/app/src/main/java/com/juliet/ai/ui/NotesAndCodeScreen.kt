package com.juliet.ai.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.juliet.ai.data.SavedSnippet
import com.juliet.ai.vm.JulietViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun NotesAndCodeScreen(vm: JulietViewModel) {
    val p = LocalPal.current
    val clipboard = LocalClipboardManager.current

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Generator, 1: Saved Snippets
    var mode by remember { mutableStateOf("code") } // "code" or "note"
    var selectedLang by remember { mutableStateOf("Kotlin") }
    var promptText by remember { mutableStateOf("") }
    var generatedResult by remember { mutableStateOf("") }

    val codeTemplates = listOf(
        "Android Jetpack Compose Card",
        "Python Web Automation Script",
        "REST API Network Client",
        "Kotlin Flow & StateFlow Pipeline",
        "Modern Responsive Flexbox Component"
    )

    val noteTemplates = listOf(
        "Sprint Standup & Project Status",
        "Executive Meeting Key Takeaways",
        "Computer Science Study Guide",
        "Daily Task Action Checklist",
        "Software Architecture Review"
    )

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // Top App Bar
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(p.card)
                    .clickable { vm.back() },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back", tint = p.text)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    "Write Notes & Code",
                    color = p.text,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Intelligent code generation & structured note-taking",
                    color = p.mu,
                    fontSize = 12.sp
                )
            }
        }

        // Segmented Tabs: Generator vs Saved
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(p.card)
                .padding(4.dp)
        ) {
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (selectedTab == 0) J.Red else Color.Transparent)
                    .clickable { selectedTab = 0 }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "Generator",
                    color = if (selectedTab == 0) Color.White else p.mu,
                    fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                    fontSize = 14.sp
                )
            }
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (selectedTab == 1) J.Red else Color.Transparent)
                    .clickable { selectedTab = 1 }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "Saved Library (${vm.snippets.size})",
                    color = if (selectedTab == 1) Color.White else p.mu,
                    fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                    fontSize = 14.sp
                )
            }
        }

        if (selectedTab == 0) {
            LazyColumn(
                Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(top = 10.dp, bottom = 40.dp)
            ) {
                // Mode Switcher (Code vs Notes)
                item {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (mode == "code") J.Red.copy(alpha = 0.2f) else p.card)
                                .border(1.dp, if (mode == "code") J.Red else p.border, RoundedCornerShape(14.dp))
                                .clickable { mode = "code" }
                                .padding(vertical = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.Code, null, tint = if (mode == "code") J.Red else p.mu, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text("Code Generator", color = if (mode == "code") J.Red else p.text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            }
                        }
                        Box(
                            Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (mode == "note") J.Red.copy(alpha = 0.2f) else p.card)
                                .border(1.dp, if (mode == "note") J.Red else p.border, RoundedCornerShape(14.dp))
                                .clickable { mode = "note" }
                                .padding(vertical = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.EditNote, null, tint = if (mode == "note") J.Red else p.mu, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text("Structured Notes", color = if (mode == "note") J.Red else p.text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            }
                        }
                    }
                }

                // Language Selector (for Code mode)
                if (mode == "code") {
                    item {
                        Column {
                            Text("TARGET LANGUAGE", color = p.mu, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Spacer(Modifier.height(8.dp))
                            Row(
                                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf("Kotlin", "Python", "JavaScript", "HTML/CSS", "C++", "SQL", "Swift").forEach { lang ->
                                    val sel = lang == selectedLang
                                    Box(
                                        Modifier
                                            .clip(RoundedCornerShape(18.dp))
                                            .background(if (sel) J.Red else p.card)
                                            .border(1.dp, if (sel) J.Red else p.border, RoundedCornerShape(18.dp))
                                            .clickable { selectedLang = lang }
                                            .padding(horizontal = 14.dp, vertical = 8.dp)
                                    ) {
                                        Text(lang, color = if (sel) Color.White else p.text, fontSize = 13.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal)
                                    }
                                }
                            }
                        }
                    }
                }

                // Quick Templates
                item {
                    Column {
                        Text("QUICK INSPIRATION", color = p.mu, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Spacer(Modifier.height(8.dp))
                        val templates = if (mode == "code") codeTemplates else noteTemplates
                        Row(
                            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            templates.forEach { tmpl ->
                                Box(
                                    Modifier
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(p.card)
                                        .border(1.dp, p.border, RoundedCornerShape(16.dp))
                                        .clickable { promptText = tmpl }
                                        .padding(horizontal = 14.dp, vertical = 8.dp)
                                ) {
                                    Text(tmpl, color = p.text, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }

                // Prompt Input
                item {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(p.card)
                            .border(1.dp, p.border, RoundedCornerShape(20.dp))
                            .padding(14.dp)
                    ) {
                        TextField(
                            value = promptText,
                            onValueChange = { promptText = it },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 90.dp).testTag("notes_code_prompt_input"),
                            placeholder = {
                                Text(
                                    if (mode == "code") "Describe the code to write (e.g. 'Build a Room entity for user profiles with Flow query')..."
                                    else "Describe the notes to take (e.g. 'Take notes on our Android project sprint and deliverables')...",
                                    color = p.mu,
                                    fontSize = 14.sp
                                )
                            },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent,
                                focusedTextColor = p.text,
                                unfocusedTextColor = p.text,
                                cursorColor = J.Crim
                            ),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                            keyboardActions = KeyboardActions(onDone = {
                                if (promptText.isNotBlank() && !vm.isCodeGenerating) {
                                    vm.generateCodeOrNotes(mode, promptText, selectedLang) { res ->
                                        generatedResult = res
                                    }
                                }
                            })
                        )

                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = {
                                if (promptText.isNotBlank()) {
                                    vm.generateCodeOrNotes(mode, promptText, selectedLang) { res ->
                                        generatedResult = res
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("generate_code_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = J.Red),
                            shape = RoundedCornerShape(14.dp),
                            enabled = promptText.isNotBlank() && !vm.isCodeGenerating
                        ) {
                            if (vm.isCodeGenerating) {
                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.width(10.dp))
                                Text("Writing with Juliet…")
                            } else {
                                Icon(Icons.Rounded.AutoAwesome, null, Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(if (mode == "code") "Generate Code ($selectedLang)" else "Generate Structured Notes")
                            }
                        }
                    }
                }

                // Generated Output
                if (generatedResult.isNotBlank()) {
                    item {
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(20.dp))
                                .background(p.card)
                                .border(1.dp, p.border, RoundedCornerShape(20.dp))
                                .padding(16.dp)
                        ) {
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        if (mode == "code") Icons.Rounded.Code else Icons.Rounded.Description,
                                        null,
                                        tint = J.Red,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        if (mode == "code") "$selectedLang Code Output" else "Generated Notes",
                                        color = p.text,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    // Copy
                                    Box(
                                        Modifier
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(p.card2)
                                            .clickable {
                                                clipboard.setText(AnnotatedString(generatedResult))
                                                vm.toast = "Copied to clipboard ✔"
                                            }
                                            .padding(horizontal = 10.dp, vertical = 6.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Rounded.ContentCopy, null, tint = p.text, modifier = Modifier.size(14.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text("Copy", color = p.text, fontSize = 12.sp)
                                        }
                                    }

                                    // Save
                                    Box(
                                        Modifier
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(J.Red)
                                            .clickable {
                                                val snippet = SavedSnippet(
                                                    id = System.currentTimeMillis(),
                                                    title = promptText.take(40),
                                                    content = generatedResult,
                                                    type = mode,
                                                    language = if (mode == "code") selectedLang else "",
                                                    timestamp = System.currentTimeMillis()
                                                )
                                                vm.saveSnippet(snippet)
                                            }
                                            .padding(horizontal = 10.dp, vertical = 6.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Rounded.BookmarkAdd, null, tint = Color.White, modifier = Modifier.size(14.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text("Save", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }

                            Spacer(Modifier.height(12.dp))
                            SelectionContainer {
                                Box(
                                    Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(Color(0xFF0F0A0E))
                                        .border(1.dp, p.border, RoundedCornerShape(14.dp))
                                        .padding(14.dp)
                                ) {
                                    Text(
                                        text = generatedResult,
                                        color = if (mode == "code") Color(0xFFFFD4DC) else p.text,
                                        fontFamily = if (mode == "code") FontFamily.Monospace else FontFamily.Default,
                                        fontSize = 13.sp,
                                        lineHeight = 20.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Saved Snippets Tab
            if (vm.snippets.isEmpty()) {
                Box(
                    Modifier.fillMaxSize().padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Rounded.BookmarkBorder, null, tint = p.mu, modifier = Modifier.size(48.dp))
                        Spacer(Modifier.height(12.dp))
                        Text("No saved snippets yet", color = p.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(6.dp))
                        Text("Generated code and notes you save will be stored safely here.", color = p.mu, fontSize = 13.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }
                }
            } else {
                LazyColumn(
                    Modifier.fillMaxSize().padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(top = 10.dp, bottom = 40.dp)
                ) {
                    items(vm.snippets, key = { it.id }) { snip ->
                        val dateStr = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(snip.timestamp))
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(20.dp))
                                .background(p.card)
                                .border(1.dp, p.border, RoundedCornerShape(20.dp))
                                .padding(16.dp)
                        ) {
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    val icon = when (snip.type) {
                                        "code" -> Icons.Rounded.Code
                                        "website" -> Icons.Rounded.Language
                                        else -> Icons.Rounded.EditNote
                                    }
                                    Icon(icon, null, tint = J.Red, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text(snip.title, color = p.text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    // Copy
                                    Box(
                                        Modifier
                                            .size(32.dp)
                                            .clip(CircleShape)
                                            .background(p.card2)
                                            .clickable {
                                                clipboard.setText(AnnotatedString(snip.content))
                                                vm.toast = "Copied to clipboard ✔"
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Rounded.ContentCopy, "Copy", tint = p.text, modifier = Modifier.size(14.dp))
                                    }

                                    // Delete
                                    Box(
                                        Modifier
                                            .size(32.dp)
                                            .clip(CircleShape)
                                            .background(p.card2)
                                            .clickable { vm.deleteSnippet(snip.id) },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Rounded.DeleteOutline, "Delete", tint = J.Red, modifier = Modifier.size(14.dp))
                                    }
                                }
                            }

                            Spacer(Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                val tag = if (snip.language.isNotBlank()) snip.language else snip.type.uppercase()
                                Text(
                                    tag,
                                    color = J.Red,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(J.Red.copy(alpha = 0.15f)).padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                                Text(dateStr, color = p.mu, fontSize = 11.sp)
                            }

                            Spacer(Modifier.height(10.dp))
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF0F0A0E))
                                    .padding(12.dp)
                            ) {
                                Text(
                                    snip.content.take(240) + if (snip.content.length > 240) "…" else "",
                                    color = p.mu,
                                    fontFamily = if (snip.type == "code" || snip.type == "website") FontFamily.Monospace else FontFamily.Default,
                                    fontSize = 12.sp,
                                    lineHeight = 18.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
