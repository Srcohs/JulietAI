package com.juliet.ai.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import com.juliet.ai.data.SavedSnippet
import com.juliet.ai.vm.JulietViewModel
import java.io.File

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebsiteBuilderScreen(vm: JulietViewModel) {
    val ctx = LocalContext.current
    val p = LocalPal.current
    val clipboard = LocalClipboardManager.current

    var promptInput by remember { mutableStateOf("") }
    var activeHtml by remember {
        mutableStateOf(
            """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Lahore Artisan Coffee & Roastery</title>
<style>
  :root {
    --primary: #ff3355;
    --primary-dark: #990022;
    --bg: #0c080d;
    --card: #1c1117;
    --border: #3b1923;
    --text: #f5f0f3;
    --sub: #d0949d;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: -apple-system, system-ui, sans-serif; background: var(--bg); color: var(--text); padding-bottom: 40px; }
  header { background: linear-gradient(180deg, #2a0b14 0%, var(--bg) 100%); padding: 32px 20px; text-align: center; border-bottom: 1px solid var(--border); }
  h1 { font-size: 1.8rem; color: var(--primary); margin-bottom: 6px; }
  p.sub { color: var(--sub); font-size: 0.95rem; }
  .container { padding: 16px; max-width: 500px; margin: 0 auto; }
  .card { background: var(--card); border: 1px solid var(--border); border-radius: 16px; padding: 16px; margin-bottom: 14px; box-shadow: 0 4px 16px rgba(0,0,0,0.4); }
  .card h3 { color: #ff9fb1; margin-bottom: 6px; font-size: 1.1rem; }
  .card p { color: var(--sub); font-size: 0.9rem; line-height: 1.4; margin-bottom: 12px; }
  .btn { background: linear-gradient(135deg, var(--primary), var(--primary-dark)); color: #fff; border: none; padding: 10px 18px; border-radius: 10px; font-weight: 600; cursor: pointer; font-size: 0.85rem; }
  .btn:active { transform: scale(0.97); }
  .status { display: none; background: #2b121b; color: #ff9fb1; padding: 10px; border-radius: 8px; margin-top: 10px; font-size: 0.85rem; border: 1px solid var(--primary); }
</style>
</head>
<body>
  <header>
    <h1>☕ Artisan Coffee Co.</h1>
    <p class="sub">Freshly roasted specialty coffee in Lahore</p>
  </header>
  <div class="container">
    <div class="card">
      <h3>☕ Signature Espresso & Latte</h3>
      <p>Single-origin Ethiopian and Colombian beans freshly ground for rich, smooth flavor.</p>
      <button class="btn" onclick="order('Latte')">Order Now</button>
      <div id="status" class="status"></div>
    </div>
    <div class="card">
      <h3>🥐 Fresh Bakery & Pastries</h3>
      <p>Warm butter croissants and handcrafted cinnamon rolls baked daily every morning.</p>
      <button class="btn" onclick="order('Croissant')">Explore Menu</button>
    </div>
  </div>
  <script>
    function order(item) {
      const s = document.getElementById('status');
      s.innerText = '✨ Added ' + item + ' to your order cart!';
      s.style.display = 'block';
    }
  </script>
</body>
</html>"""
        )
    }

    var selectedViewTab by remember { mutableIntStateOf(0) } // 0: Live Preview, 1: Source Code
    var webViewInstance by remember { mutableStateOf<WebView?>(null) }

    val templates = listOf(
        "Modern Cafe & Bakery in Lahore",
        "Full-Stack Developer Portfolio",
        "Online Tech Gadget Store",
        "AI Startup Landing Page",
        "Personal Fitness & Training Gym"
    )

    fun openInBrowser() {
        try {
            val cacheFile = File(ctx.cacheDir, "preview_site.html")
            cacheFile.writeText(activeHtml)
            val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", cacheFile)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "text/html")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ctx.startActivity(Intent.createChooser(intent, "Open in Browser"))
        } catch (_: Exception) {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("data:text/html;charset=utf-8," + Uri.encode(activeHtml)))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // Top App Bar
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(p.card)
                    .clickable { vm.back() },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back", tint = p.text)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    "Website Builder",
                    color = p.text,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Build & preview interactive responsive websites",
                    color = p.mu,
                    fontSize = 12.sp
                )
            }
            Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(p.card)
                    .clickable { openInBrowser() },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.OpenInBrowser, "Browser", tint = p.text)
            }
        }

        // Prompt Input & Builder Area
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(p.card)
                .border(1.dp, p.border, RoundedCornerShape(20.dp))
                .padding(14.dp)
        ) {
            // Quick Template Chips
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                templates.forEach { tmpl ->
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(p.card2)
                            .border(1.dp, p.border, RoundedCornerShape(14.dp))
                            .clickable { promptInput = tmpl }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(tmpl, color = p.text, fontSize = 11.sp)
                    }
                }
            }

            Spacer(Modifier.height(10.dp))
            TextField(
                value = promptInput,
                onValueChange = { promptInput = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 60.dp)
                    .testTag("website_builder_prompt"),
                placeholder = {
                    Text(
                        "Describe your website (e.g. 'Build a modern pizza restaurant landing page with menu items and order buttons')...",
                        color = p.mu,
                        fontSize = 13.sp
                    )
                },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = p.text,
                    unfocusedTextColor = p.text,
                    cursorColor = J.Crim
                )
            )

            Spacer(Modifier.height(8.dp))
            Button(
                onClick = {
                    val prompt = promptInput.ifBlank { "Modern Website" }
                    vm.generateWebsite(prompt) { html ->
                        activeHtml = html
                        webViewInstance?.loadDataWithBaseURL("about:blank", html, "text/html", "UTF-8", null)
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("build_website_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = J.Red),
                shape = RoundedCornerShape(14.dp),
                enabled = !vm.isWebsiteGenerating
            ) {
                if (vm.isWebsiteGenerating) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                    Text("Building Website…")
                } else {
                    Icon(Icons.Rounded.Language, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Build Website with Juliet AI", fontWeight = FontWeight.Bold)
                }
            }
        }

        // View Tabs: Live Preview vs Code
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .background(p.card)
                    .padding(3.dp)
            ) {
                Box(
                    Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (selectedViewTab == 0) J.Red else Color.Transparent)
                        .clickable { selectedViewTab = 0 }
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Live Preview", color = if (selectedViewTab == 0) Color.White else p.mu, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
                Box(
                    Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (selectedViewTab == 1) J.Red else Color.Transparent)
                        .clickable { selectedViewTab = 1 }
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("HTML Code", color = if (selectedViewTab == 1) Color.White else p.mu, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // Copy Code
                Box(
                    Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(p.card2)
                        .clickable {
                            clipboard.setText(AnnotatedString(activeHtml))
                            vm.toast = "HTML Code copied ✔"
                        }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.ContentCopy, null, tint = p.text, modifier = Modifier.size(13.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Copy", color = p.text, fontSize = 11.sp)
                    }
                }

                // Save
                Box(
                    Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(J.Red)
                        .clickable {
                            val snip = SavedSnippet(
                                id = System.currentTimeMillis(),
                                title = promptInput.ifBlank { "Custom Web Page" }.take(40),
                                content = activeHtml,
                                type = "website",
                                language = "html",
                                timestamp = System.currentTimeMillis()
                            )
                            vm.saveSnippet(snip)
                        }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.BookmarkAdd, null, tint = Color.White, modifier = Modifier.size(13.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Save", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Main Viewer (Interactive WebView or Code block)
        Box(
            Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 16.dp, vertical = 4.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFF0C080D))
                .border(1.dp, p.border, RoundedCornerShape(20.dp))
        ) {
            if (selectedViewTab == 0) {
                AndroidView(
                    factory = { context ->
                        WebView(context).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.useWideViewPort = true
                            settings.loadWithOverviewMode = true
                            webViewClient = WebViewClient()
                            webChromeClient = WebChromeClient()
                            loadDataWithBaseURL("about:blank", activeHtml, "text/html", "UTF-8", null)
                            webViewInstance = this
                        }
                    },
                    update = { view ->
                        webViewInstance = view
                        view.loadDataWithBaseURL("about:blank", activeHtml, "text/html", "UTF-8", null)
                    },
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                SelectionContainer {
                    Box(
                        Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp)
                    ) {
                        Text(
                            text = activeHtml,
                            color = Color(0xFFFFD4DC),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        }
    }
}
