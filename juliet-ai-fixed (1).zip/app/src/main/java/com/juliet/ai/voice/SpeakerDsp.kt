package com.juliet.ai.voice

import kotlin.math.*

/**
 * Real on-device speaker feature extraction (no fake time-slice "bands").
 *
 * Pipeline: pre-emphasis -> 25 ms Hamming frames (10 ms hop) -> energy VAD -> 512-pt FFT
 * -> 26 mel filters (100-4000 Hz) -> log -> DCT -> 12 MFCC (+ delta) -> per-utterance
 * mean/std statistics + pitch (F0) statistics = a 50-dim voice print.
 */
object SpeakerDsp {
    const val SR = 16000
    const val FRAME = 400          // 25 ms
    const val HOP = 160            // 10 ms
    const val NFFT = 512
    const val NMEL = 26
    const val NMFCC = 12
    // 12 mean + 12 std + 12 delta-std + pitch mean(log) + pitch std
    const val DIM = NMFCC * 3 + 2

    private val window = FloatArray(FRAME) { (0.54 - 0.46 * cos(2.0 * PI * it / (FRAME - 1))).toFloat() }
    private val melBank: Array<FloatArray> = buildMelBank()
    private val dct: Array<FloatArray> = Array(NMFCC) { k ->
        FloatArray(NMEL) { n -> cos(PI * (k + 1) * (n + 0.5) / NMEL).toFloat() }
    }

    private fun hz2mel(f: Double) = 2595.0 * log10(1.0 + f / 700.0)
    private fun mel2hz(m: Double) = 700.0 * (10.0.pow(m / 2595.0) - 1.0)

    private fun buildMelBank(): Array<FloatArray> {
        val lo = hz2mel(100.0); val hi = hz2mel(4000.0)
        val pts = DoubleArray(NMEL + 2) { mel2hz(lo + (hi - lo) * it / (NMEL + 1)) }
        val bins = IntArray(NMEL + 2) { ((NFFT + 1) * pts[it] / SR).toInt().coerceIn(0, NFFT / 2) }
        return Array(NMEL) { m ->
            val f = FloatArray(NFFT / 2 + 1)
            val l = bins[m]; val c = bins[m + 1]; val r = bins[m + 2]
            for (k in l until c) if (c > l) f[k] = (k - l).toFloat() / (c - l)
            for (k in c..r) if (r > c && k <= NFFT / 2) f[k] = (r - k).toFloat() / (r - c)
            f
        }
    }

    /** In-place radix-2 FFT. */
    private fun fft(re: FloatArray, im: FloatArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val ang = -2.0 * PI / len
            val wr = cos(ang).toFloat(); val wi = sin(ang).toFloat()
            var i = 0
            while (i < n) {
                var cr = 1f; var ci = 0f
                for (k in 0 until len / 2) {
                    val a = i + k; val b = i + k + len / 2
                    val xr = re[b] * cr - im[b] * ci
                    val xi = re[b] * ci + im[b] * cr
                    re[b] = re[a] - xr; im[b] = im[a] - xi
                    re[a] += xr; im[a] += xi
                    val ncr = cr * wr - ci * wi
                    ci = cr * wi + ci * wr; cr = ncr
                }
                i += len
            }
            len = len shl 1
        }
    }

    /** Frame energies (dB-ish) used for voice activity detection. */
    fun frameEnergies(pcm: ShortArray): FloatArray {
        val nf = if (pcm.size < FRAME) 0 else 1 + (pcm.size - FRAME) / HOP
        return FloatArray(nf) { f ->
            var s = 0.0
            val o = f * HOP
            for (i in 0 until FRAME) { val v = pcm[o + i].toDouble(); s += v * v }
            (10.0 * log10(s / FRAME + 1.0)).toFloat()
        }
    }

    /** Marks speech frames: adaptive threshold above the noise floor of this clip. */
    fun speechMask(energies: FloatArray): BooleanArray {
        if (energies.isEmpty()) return BooleanArray(0)
        val sorted = energies.sorted()
        val floor = sorted[(sorted.size * 0.15).toInt().coerceIn(0, sorted.size - 1)]
        val peak = sorted[(sorted.size * 0.95).toInt().coerceIn(0, sorted.size - 1)]
        val thr = max(floor + 8f, floor + (peak - floor) * 0.35f)
        return BooleanArray(energies.size) { energies[it] >= thr && energies[it] > 35f }
    }

    private class Frames(val mfcc: List<FloatArray>, val f0: List<Float>)

    private fun analyse(pcm: ShortArray, mask: BooleanArray): Frames {
        val mfccs = ArrayList<FloatArray>()
        val f0s = ArrayList<Float>()
        val re = FloatArray(NFFT); val im = FloatArray(NFFT)
        val x = FloatArray(FRAME)
        for (f in mask.indices) {
            if (!mask[f]) continue
            val o = f * HOP
            // pre-emphasis + window
            for (i in 0 until FRAME) {
                val cur = pcm[o + i].toFloat()
                val prev = if (o + i > 0) pcm[o + i - 1].toFloat() else 0f
                x[i] = (cur - 0.97f * prev) * window[i] / 32768f
            }
            java.util.Arrays.fill(re, 0f); java.util.Arrays.fill(im, 0f)
            System.arraycopy(x, 0, re, 0, FRAME)
            fft(re, im)
            val mel = FloatArray(NMEL)
            for (m in 0 until NMEL) {
                var e = 0f
                val bank = melBank[m]
                for (k in 0..NFFT / 2) if (bank[k] != 0f) e += bank[k] * (re[k] * re[k] + im[k] * im[k])
                mel[m] = ln(e + 1e-10f)
            }
            val c = FloatArray(NMFCC)
            for (k in 0 until NMFCC) {
                var s = 0f
                for (n in 0 until NMEL) s += dct[k][n] * mel[n]
                c[k] = s
            }
            mfccs.add(c)

            // pitch by normalised autocorrelation on the raw (non pre-emphasised) frame
            val p = pitch(pcm, o)
            if (p > 0f) f0s.add(p)
        }
        return Frames(mfccs, f0s)
    }

    private fun pitch(pcm: ShortArray, o: Int): Float {
        val minLag = SR / 400; val maxLag = SR / 70
        var e0 = 0.0
        for (i in 0 until FRAME) { val v = pcm[o + i].toDouble(); e0 += v * v }
        if (e0 < 1e3) return 0f
        var best = 0.0; var bestLag = 0
        for (lag in minLag..maxLag) {
            var c = 0.0; var e1 = 0.0
            for (i in 0 until FRAME - lag) {
                val a = pcm[o + i].toDouble(); val b = pcm[o + i + lag].toDouble()
                c += a * b; e1 += b * b
            }
            val r = c / sqrt(e0 * e1 + 1e-9)
            if (r > best) { best = r; bestLag = lag }
        }
        return if (best > 0.55 && bestLag > 0) SR.toFloat() / bestLag else 0f
    }

    /** Count of speech frames -> seconds of actual speech in [pcm]. */
    fun speechSeconds(pcm: ShortArray): Float {
        val m = speechMask(frameEnergies(pcm))
        return m.count { it } * HOP / SR.toFloat()
    }

    /**
     * Voice print of one utterance. Returns null if there is too little speech (< 0.7 s)
     * to be a reliable measurement.
     */
    fun embed(pcm: ShortArray): FloatArray? {
        val mask = speechMask(frameEnergies(pcm))
        val fr = analyse(pcm, mask)
        if (fr.mfcc.size < 70) return null
        val n = fr.mfcc.size
        val mean = FloatArray(NMFCC); val sd = FloatArray(NMFCC); val dsd = FloatArray(NMFCC)
        for (c in fr.mfcc) for (k in 0 until NMFCC) mean[k] += c[k] / n
        for (c in fr.mfcc) for (k in 0 until NMFCC) { val d = c[k] - mean[k]; sd[k] += d * d / n }
        for (k in 0 until NMFCC) sd[k] = sqrt(sd[k])
        // delta energy (frame to frame change) captures articulation dynamics
        for (i in 1 until n) for (k in 0 until NMFCC) {
            val d = fr.mfcc[i][k] - fr.mfcc[i - 1][k]; dsd[k] += d * d / (n - 1)
        }
        for (k in 0 until NMFCC) dsd[k] = sqrt(dsd[k])

        var lf0m = 0f; var lf0s = 0f
        if (fr.f0.size >= 10) {
            val l = fr.f0.map { ln(it) }
            lf0m = l.average().toFloat()
            lf0s = sqrt(l.map { (it - lf0m) * (it - lf0m) }.average()).toFloat()
        }
        val out = FloatArray(DIM)
        System.arraycopy(mean, 0, out, 0, NMFCC)
        System.arraycopy(sd, 0, out, NMFCC, NMFCC)
        System.arraycopy(dsd, 0, out, 2 * NMFCC, NMFCC)
        out[3 * NMFCC] = lf0m * 4f   // scaled so pitch carries weight comparable to MFCC dims
        out[3 * NMFCC + 1] = lf0s * 10f
        return out
    }

    /** Mean + per-dimension spread of several enrollment embeddings. */
    fun buildProfile(samples: List<FloatArray>): Pair<List<Float>, List<Float>> {
        val n = samples.size
        val mean = FloatArray(DIM)
        for (s in samples) for (i in 0 until DIM) mean[i] += s[i] / n
        val spread = FloatArray(DIM)
        for (i in 0 until DIM) {
            var v = 0f
            for (s in samples) { val d = s[i] - mean[i]; v += d * d }
            val sampleVar = if (n > 1) v / (n - 1) else 0f
            // blend with a floor so 3-5 samples cannot create an over-tight (unusable) profile
            val floor = 0.12f * abs(mean[i]) + 0.25f
            spread[i] = sqrt(sampleVar + floor * floor)
        }
        return mean.toList() to spread.toList()
    }

    /** RMS z-distance between an utterance and a profile (0 = identical). */
    fun distance(e: FloatArray, mean: List<Float>, spread: List<Float>): Float {
        if (mean.size != DIM || spread.size != DIM) return Float.MAX_VALUE
        var s = 0f
        for (i in 0 until DIM) { val z = (e[i] - mean[i]) / spread[i]; s += z * z }
        return sqrt(s / DIM)
    }

    /** distance -> 0..1 confidence. d=0 ->100%, d=1 ->82%, d=1.6 ->61%, d=2.5 ->29%. */
    fun confidence(d: Float): Float = exp(-0.5 * (d / 1.6).pow(2)).toFloat().coerceIn(0f, 1f)
}
