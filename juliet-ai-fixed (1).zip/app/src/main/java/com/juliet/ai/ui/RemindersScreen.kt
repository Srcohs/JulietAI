package com.juliet.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.juliet.ai.data.SmartReminder
import com.juliet.ai.vm.JulietViewModel
import java.util.Calendar

@Composable
fun RemindersScreen(vm: JulietViewModel) = Page("Smart Reminders", { vm.back() }) {
    val p = LocalPal.current
    var naturalText by remember { mutableStateOf("") }
    var editingReminder by remember { mutableStateOf<SmartReminder?>(null) }
    var editTitle by remember { mutableStateOf("") }
    var editRecurrence by remember { mutableStateOf("Once") }

    val activeReminders = vm.reminders.filter { !it.completed }
    val completedReminders = vm.reminders.filter { it.completed }

    Sub("Schedule reminders with natural language, customize recurrence, and receive timely alerts.")

    Sec("ADD REMINDER")
    OutlinedTextField(
        value = naturalText,
        onValueChange = { naturalText = it },
        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        placeholder = { Text("e.g. Call Mom tomorrow at 2 PM, buy groceries in 30 mins", color = p.mu) },
        shape = RoundedCornerShape(20.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = J.Red,
            unfocusedBorderColor = p.border,
            cursorColor = J.Crim,
            focusedTextColor = p.text,
            unfocusedTextColor = p.text
        )
    )

    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        SuggestionChip(
            onClick = { naturalText = "Call Mom tomorrow at 2 PM" },
            label = { Text("Tomorrow 2 PM", fontSize = 12.sp) }
        )
        SuggestionChip(
            onClick = { naturalText = "Project deadline next Friday at 5 PM" },
            label = { Text("Next Friday", fontSize = 12.sp) }
        )
        SuggestionChip(
            onClick = { naturalText = "Follow up with team in 30 minutes" },
            label = { Text("In 30 mins", fontSize = 12.sp) }
        )
    }

    Spacer(Modifier.height(8.dp))
    GradientButton(
        text = "Set Reminder",
        modifier = Modifier.fillMaxWidth()
    ) {
        if (naturalText.isNotBlank()) {
            vm.createReminderFromNaturalLanguage(naturalText)
            naturalText = ""
        }
    }

    Spacer(Modifier.height(20.dp))
    Sec("UPCOMING (${activeReminders.size})")
    if (activeReminders.isEmpty()) {
        Text("No upcoming reminders. Say: \"Juliet, remind me to check the server at 6 PM\" to schedule one.", color = p.mu, fontSize = 14.sp, lineHeight = 20.sp)
    } else {
        activeReminders.forEach { reminder ->
            ReminderCard(
                reminder = reminder,
                dueStr = vm.reminderManager.formatDueTime(reminder.dueTimeMillis),
                onToggle = { vm.toggleReminder(reminder.id) },
                onEdit = {
                    editingReminder = reminder
                    editTitle = reminder.title
                    editRecurrence = reminder.recurrence
                },
                onDelete = { vm.deleteReminder(reminder.id) }
            )
            Spacer(Modifier.height(10.dp))
        }
    }

    if (completedReminders.isNotEmpty()) {
        Spacer(Modifier.height(16.dp))
        Sec("COMPLETED (${completedReminders.size})")
        completedReminders.forEach { reminder ->
            ReminderCard(
                reminder = reminder,
                dueStr = vm.reminderManager.formatDueTime(reminder.dueTimeMillis),
                onToggle = { vm.toggleReminder(reminder.id) },
                onEdit = {
                    editingReminder = reminder
                    editTitle = reminder.title
                    editRecurrence = reminder.recurrence
                },
                onDelete = { vm.deleteReminder(reminder.id) }
            )
            Spacer(Modifier.height(10.dp))
        }
    }

    editingReminder?.let { r ->
        AlertDialog(
            onDismissRequest = { editingReminder = null },
            title = { Text("Edit Reminder") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = editTitle,
                        onValueChange = { editTitle = it },
                        label = { Text("Reminder Title") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text("Recurrence", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = p.text)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Once", "Daily", "Weekly", "Weekdays").forEach { rec ->
                            FilterChip(
                                selected = editRecurrence == rec,
                                onClick = { editRecurrence = rec },
                                label = { Text(rec, fontSize = 11.sp) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.updateReminder(r.copy(title = editTitle, recurrence = editRecurrence))
                    editingReminder = null
                }) {
                    Text("Save", color = J.Red)
                }
            },
            dismissButton = {
                TextButton(onClick = { editingReminder = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun ReminderCard(
    reminder: SmartReminder,
    dueStr: String,
    onToggle: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val p = LocalPal.current
    val sh = RoundedCornerShape(20.dp)

    Row(
        Modifier.fillMaxWidth().clip(sh).background(p.card).border(1.dp, p.border, sh)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Checkbox(
            checked = reminder.completed,
            onCheckedChange = { onToggle() },
            colors = CheckboxDefaults.colors(
                checkedColor = J.Ok,
                uncheckedColor = p.mu
            )
        )

        Column(Modifier.weight(1f)) {
            Text(
                reminder.title,
                color = if (reminder.completed) p.mu else p.text,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                textDecoration = if (reminder.completed) TextDecoration.LineThrough else TextDecoration.None
            )
            Spacer(Modifier.height(3.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(dueStr, color = J.Gold, fontSize = 13.sp)
                if (reminder.recurrence != "Once") {
                    Text("• ${reminder.recurrence}", color = p.mu, fontSize = 12.sp)
                }
            }
        }

        IconButton(onClick = onEdit) {
            Icon(Icons.Rounded.Edit, "Edit", tint = p.mu, modifier = Modifier.size(20.dp))
        }
        IconButton(onClick = onDelete) {
            Icon(Icons.Rounded.Delete, "Delete", tint = J.Red, modifier = Modifier.size(20.dp))
        }
    }
}
