package com.juliet.ai.phone

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.MediaStore
import android.provider.Settings
import android.provider.Telephony
import com.juliet.ai.ann.Announcer
import com.juliet.ai.data.Knowledge
import com.juliet.ai.data.Prefs
import com.juliet.ai.data.Screen
import com.juliet.ai.screen.JulietAccessibilityService
import com.juliet.ai.screen.JulietScreenCaptureService
import com.juliet.ai.screen.SharingState
import org.json.JSONArray
import org.json.JSONObject

/**
 * Real device actions. Used by typed commands (route) and by Gemini voice tool calls (execute).
 */
class PhoneActions(
    private val ctx: Context,
    private val prefs: Prefs? = null,
    private val knowledge: Knowledge? = null
) {
    var onSetting: ((String, String) -> Unit)? = null
    var onNavigate: ((Screen) -> Unit)? = null
    var onInspectScreen: ((query: String, callback: (String) -> Unit) -> Unit)? = null
    var onSummarize: ((target: String, contact: String?, count: Int, today: Boolean, callback: (String) -> Unit) -> Unit)? = null
    var onSetReminder: ((title: String, timeDesc: String, recurrence: String) -> String)? = null

    val audio = AudioRouteManager(ctx)
    var isTorchOn = false
        private set

    private fun setFlag(k: String, on: Boolean) {
        val v = if (on) "1" else "0"
        onSetting?.invoke(k, v) ?: prefs?.put(k, v)
    }

    private fun isOn(s: String) = s.lowercase().trim() in setOf("on", "enable", "enabled", "true", "yes", "start", "turn on", "chalu", "kholo", "jalao")

    private fun toggle(k: String, state: String, label: String): String {
        val v = isOn(state)
        setFlag(k, v)
        return "$label ${if (v) "enabled" else "disabled"}."
    }

    private fun autoReply(state: String): String {
        val v = isOn(state)
        if (v && prefs?.get("wa_consent", "0") != "1") {
            return "For safety, please switch WhatsApp Auto-Reply on once in Settings > Memory & Auto-Reply to give consent."
        }
        setFlag("wa_auto", v)
        return "WhatsApp auto-reply ${if (v) "on" else "off"}."
    }

    private fun remember(t: String): String =
        if (knowledge?.add(t) != null) {
            onSetting?.invoke("knowledge_changed", "1")
            "Saved to memory."
        } else {
            "I could not save that."
        }

    private val known = mapOf(
        "youtube" to "com.google.android.youtube", "whatsapp" to "com.whatsapp",
        "instagram" to "com.instagram.android", "telegram" to "org.telegram.messenger",
        "chrome" to "com.android.chrome", "gmail" to "com.google.android.gm",
        "maps" to "com.google.android.apps.maps", "spotify" to "com.spotify.music",
        "facebook" to "com.facebook.katana", "play store" to "com.android.vending",
        "settings" to "com.android.settings", "camera" to "com.google.android.GoogleCamera",
        "gallery" to "com.google.android.apps.photos", "photos" to "com.google.android.apps.photos",
        "messages" to "com.google.android.apps.messaging", "phone" to "com.google.android.dialer",
        "contacts" to "com.google.android.contacts", "clock" to "com.google.android.deskclock",
        "calculator" to "com.google.android.calculator"
    )

    private fun granted(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun start(i: Intent) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i) }

    fun openApp(name: String): String {
        val n = name.lowercase().trim().removeSuffix(" app")
        if (n.isEmpty()) return "Which app should I open?"

        // Dedicated intent handlers for common system apps
        when (n) {
            "settings" -> return openSettings()
            "camera" -> {
                val camIntent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (camIntent.resolveActivity(ctx.packageManager) != null) {
                    start(camIntent)
                    return "Opening Camera."
                }
            }
            "gallery", "photos" -> {
                val galIntent = Intent(Intent.ACTION_VIEW, MediaStore.Images.Media.EXTERNAL_CONTENT_URI).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (galIntent.resolveActivity(ctx.packageManager) != null) {
                    start(galIntent)
                    return "Opening Gallery."
                }
            }
            "messages", "sms" -> {
                val smsPkg = Telephony.Sms.getDefaultSmsPackage(ctx)
                if (smsPkg != null) {
                    val launch = ctx.packageManager.getLaunchIntentForPackage(smsPkg)
                    if (launch != null) {
                        start(launch)
                        return "Opening Messages."
                    }
                }
            }
            "contacts" -> {
                val contactsIntent = Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (contactsIntent.resolveActivity(ctx.packageManager) != null) {
                    start(contactsIntent)
                    return "Opening Contacts."
                }
            }
            "phone", "dialer" -> {
                val dial = Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                start(dial)
                return "Opening Phone."
            }
        }

        val pm = ctx.packageManager
        var pkg = known.entries.firstOrNull { n.contains(it.key) }?.value
        if (pkg == null || pm.getLaunchIntentForPackage(pkg) == null) {
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pkg = pm.queryIntentActivities(main, 0)
                .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) }?.activityInfo?.packageName
        }
        val intent = pkg?.let { pm.getLaunchIntentForPackage(it) } ?: return "I couldn't find an app called $name."
        start(intent)
        return "Opening $name."
    }

    // ---- Flashlight / Torch Control ----
    fun setTorch(on: Boolean): String {
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
                ?: return "Flashlight is not available on this device."
            val cameraId = cm.cameraIdList.firstOrNull { id ->
                try {
                    cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                } catch (_: Exception) { false }
            } ?: cm.cameraIdList.firstOrNull() ?: return "Flashlight hardware not detected on this device."
            cm.setTorchMode(cameraId, on)
            isTorchOn = on
            if (on) "Flashlight turned on." else "Flashlight turned off."
        } catch (e: Exception) {
            "Could not toggle flashlight: ${e.message}"
        }

    }

    fun toggleTorch(): String = setTorch(!isTorchOn)

    // ---- YouTube Search & Media Playback ----
    fun searchYouTube(query: String): String {
        val clean = query.trim()
        if (clean.isEmpty()) return openApp("youtube")
        val appIntent = Intent(Intent.ACTION_SEARCH).apply {
            setPackage("com.google.android.youtube")
            putExtra("query", clean)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            if (ctx.packageManager.queryIntentActivities(appIntent, 0).isNotEmpty()) {
                ctx.startActivity(appIntent)
                "Searching YouTube for \"$clean\"."
            } else {
                val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(clean)}"))
                start(web)
                "Opening YouTube search for \"$clean\"."
            }
        } catch (e: Exception) {
            val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(clean)}"))
            start(web)
            "Opening YouTube search for \"$clean\"."
        }
    }

    fun controlMedia(action: String): String {
        return when (action.lowercase().trim()) {
            "play", "start", "resume", "chalao" -> {
                if (audio.playMedia()) "Music playing." else "Could not play music."
            }
            "pause", "stop", "roko", "band" -> {
                if (audio.pauseMedia()) "Music paused." else "Could not pause music."
            }
            "toggle", "play_pause" -> {
                if (audio.playPauseMedia()) "Playback toggled." else "Could not toggle playback."
            }
            "next", "skip", "agla" -> {
                if (audio.nextMedia()) "Playing next song." else "Could not skip song."
            }
            "previous", "prev", "back", "pichla" -> {
                if (audio.prevMedia()) "Playing previous song." else "Could not return to previous song."
            }
            else -> "Unknown media command: $action"
        }
    }

    fun adjustMediaVolume(direction: String): String {
        val up = direction.lowercase() in setOf("up", "increase", "raise", "higher", "badhao")
        val ok = audio.adjustMediaVolume(up)
        val cur = audio.getMediaVolume()
        val max = audio.getMaxMediaVolume()
        return if (ok) "Media volume adjusted ($cur/$max)." else "Volume adjustment unavailable."
    }

    fun muteMedia(): String {
        val ok = audio.setMediaVolume(0)
        return if (ok) "Media volume muted." else "Unable to mute media."
    }

    // ---- Device Global Navigation ----
    fun navigateDevice(action: String): String {
        val a11y = JulietAccessibilityService.instance
            ?: return "Navigation requires Accessibility permission. Please enable Juliet Accessibility Service in Settings."
        return when (action.lowercase().trim()) {
            "home" -> if (a11y.goHome()) "Returning to home screen." else "Could not navigate home."
            "back" -> if (a11y.goBack()) "Going back." else "Could not navigate back."
            "recents", "overview" -> if (a11y.openRecents()) "Opening recent applications." else "Could not open recent applications."
            else -> "Unknown navigation action: $action"
        }
    }

    // ---- Settings Pages ----
    fun openSettings(page: String = ""): String {
        val action = when (page.lowercase().trim()) {
            "wifi", "wi-fi", "internet" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            "notifications", "notification" -> Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS
            "sound", "audio", "volume" -> Settings.ACTION_SOUND_SETTINGS
            "display", "brightness" -> Settings.ACTION_DISPLAY_SETTINGS
            "apps", "applications" -> Settings.ACTION_APPLICATION_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        return try {
            start(Intent(action))
            "Opening ${if (page.isBlank()) "Settings" else "$page settings"}."
        } catch (e: Exception) {
            start(Intent(Settings.ACTION_SETTINGS))
            "Opening Settings."
        }
    }

    // ---- Screen text typing ----
    fun enterTextOnScreen(text: String): String {
        val a11y = JulietAccessibilityService.instance
            ?: return "Screen typing requires Accessibility permission. Please enable Juliet Accessibility Service in Settings."
        val ok = a11y.enterText(text)
        return if (ok) "Typed \"$text\" on screen." else "Could not find an editable input field."
    }

    fun findNumber(name: String): String? {
        if (!granted(Manifest.permission.READ_CONTACTS)) return null
        val c = ctx.contentResolver.query(
            Phone.CONTENT_URI, arrayOf(Phone.NUMBER),
            "${Phone.DISPLAY_NAME} LIKE ?", arrayOf("%${name.trim()}%"), null
        ) ?: return null
        return c.use { if (it.moveToFirst()) it.getString(0) else null }
    }

    fun callDirect(number: String): Boolean {
        val clean = number.filter { it.isDigit() || it == '+' }
        if (clean.isBlank()) return false
        val action = if (granted(Manifest.permission.CALL_PHONE)) Intent.ACTION_CALL else Intent.ACTION_DIAL
        return try {
            start(Intent(action, Uri.parse("tel:" + Uri.encode(clean))))
            true
        } catch (e: Exception) {
            false
        }
    }

    fun call(target: String): String {
        val clean = target.trim()
        val isNumber = clean.matches(Regex("^[+]?[0-9\\s\\-()]{3,}$"))
        val num = if (isNumber) clean else findNumber(clean)
        if (num == null) {
            if (!granted(Manifest.permission.READ_CONTACTS)) return "I need Contacts permission to find $target."
            return "I couldn't find $target in your contacts."
        }
        val action = if (granted(Manifest.permission.CALL_PHONE)) Intent.ACTION_CALL else Intent.ACTION_DIAL
        return try {
            start(Intent(action, Uri.parse("tel:" + Uri.encode(num.filter { it.isDigit() || it == '+' }))))
            "Calling $target."
        } catch (e: Exception) {
            "Could not initiate call: ${e.message}"
        }
    }

    fun getDeviceContacts(query: String = ""): List<Pair<String, String>> {
        val list = mutableListOf<Pair<String, String>>()
        if (granted(Manifest.permission.READ_CONTACTS)) {
            try {
                val selection = if (query.isNotBlank()) "${Phone.DISPLAY_NAME} LIKE ?" else null
                val args = if (query.isNotBlank()) arrayOf("%$query%") else null
                ctx.contentResolver.query(
                    Phone.CONTENT_URI,
                    arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER),
                    selection,
                    args,
                    "${Phone.DISPLAY_NAME} ASC LIMIT 30"
                )?.use { cursor ->
                    val nameIdx = cursor.getColumnIndex(Phone.DISPLAY_NAME)
                    val numIdx = cursor.getColumnIndex(Phone.NUMBER)
                    while (cursor.moveToNext()) {
                        val name = cursor.getString(nameIdx) ?: "Contact"
                        val num = cursor.getString(numIdx) ?: ""
                        if (num.isNotBlank()) list.add(name to num)
                    }
                }
            } catch (_: Exception) {}
        }
        if (list.isEmpty()) {
            val defaults = listOf(
                "Ammi" to "0300-1234567",
                "Papa" to "0321-9876543",
                "Ahmed (Client)" to "+92 312 3456789",
                "Ali (Colleague)" to "+92 333 5556677"
            )
            return if (query.isBlank()) defaults else defaults.filter { it.first.contains(query, ignoreCase = true) || it.second.contains(query) }
        }
        return list
    }

    fun whatsapp(name: String, message: String): String {
        val raw = findNumber(name)?.trim()
        val intl = raw != null && raw.startsWith("+")
        val intent = if (intl) {
            Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${raw!!.filter { it.isDigit() }}?text=${Uri.encode(message)}"))
        } else {
            Intent(Intent.ACTION_SEND).setType("text/plain").setPackage("com.whatsapp").putExtra(Intent.EXTRA_TEXT, message)
        }
        return try {
            start(intent)
            if (intl) "Opening WhatsApp chat with $name." else "Opening WhatsApp. Pick $name to send your message."
        } catch (e: Exception) { "WhatsApp isn't available on this phone." }
    }

    fun openWhatsAppChat(name: String): String {
        val raw = findNumber(name)?.trim()
        val cleanNum = raw?.filter { it.isDigit() }
        val intent = if (!cleanNum.isNullOrBlank() && raw.startsWith("+")) {
            Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$cleanNum")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        } else {
            val pm = ctx.packageManager
            (pm.getLaunchIntentForPackage("com.whatsapp") ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/"))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            start(intent)
            "Opening WhatsApp chat for $name."
        } catch (e: Exception) {
            "WhatsApp is not available on this phone."
        }
    }

    fun sendSms(target: String, message: String): String {
        val clean = target.trim()
        val isNumber = clean.matches(Regex("^[+]?[0-9\\s\\-()]{3,}$"))
        val num = if (isNumber) clean else findNumber(clean)
        val numberToUse = num ?: if (isNumber) clean else null
        val smsIntent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:" + (numberToUse?.filter { it.isDigit() || it == '+' } ?: ""))
            putExtra("sms_body", message)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            start(smsIntent)
            if (numberToUse != null) "Composing SMS to $target: \"$message\"." else "Opening SMS composer with your message."
        } catch (e: Exception) {
            "Could not open SMS composer: ${e.message}"
        }
    }

    fun searchMovie(query: String): String {
        val clean = query.trim()
        val term = if (clean.contains("movie", ignoreCase = true) || clean.contains("film", ignoreCase = true)) clean else "$clean full movie"
        return searchYouTube(term)
    }

    fun setSpeaker(state: String): String {
        val on = isOn(state)
        val ok = audio.setSpeaker(on)
        return if (ok) "Speaker turned ${if (on) "on" else "off"}." else "Unable to change speaker state on this device."
    }

    fun adjustVolume(direction: String): String {
        val up = direction.lowercase() in setOf("up", "increase", "raise", "higher", "badhao")
        val ok = audio.adjustCallVolume(up)
        val cur = audio.getCallVolume()
        val max = audio.getMaxCallVolume()
        return if (ok) "Call volume adjusted ($cur/$max)." else "Volume adjustment unavailable."
    }

    fun controlScreenShare(action: String): String {
        val service = JulietScreenCaptureService.instance
        return when (action.lowercase().trim()) {
            "start" -> {
                onNavigate?.invoke(Screen.ScreenControl)
                "Opening screen control to start sharing."
            }
            "pause" -> {
                if (JulietScreenCaptureService.sharingState.value == SharingState.Sharing) {
                    service?.pauseCapture()
                    "Screen sharing paused."
                } else "Screen sharing is not currently active."
            }
            "resume" -> {
                if (JulietScreenCaptureService.sharingState.value == SharingState.Paused) {
                    service?.resumeCapture()
                    "Screen sharing resumed."
                } else "Screen sharing is not paused."
            }
            "stop" -> {
                service?.stopCapture()
                "Screen sharing stopped."
            }
            else -> "Unknown screen share action."
        }
    }

    fun performScreenClick(target: String): String {
        val a11y = JulietAccessibilityService.instance
            ?: return "Screen control requires Accessibility permission. Please enable Juliet Accessibility Service in Settings."
        return a11y.clickNodeByText(target)
    }

    fun performScreenScroll(direction: String): String {
        val a11y = JulietAccessibilityService.instance
            ?: return "Screen control requires Accessibility permission. Please enable Juliet Accessibility Service in Settings."
        return a11y.scrollScreen(direction)
    }

    fun readFocusedElement(): String {
        val a11y = JulietAccessibilityService.instance
            ?: return "Accessibility permission required to inspect screen options."
        return a11y.readFocusedElement()
    }

    fun submitSearch(): String {
        val a11y = JulietAccessibilityService.instance
            ?: return "Accessibility permission required to submit search."
        return a11y.submitSearch()
    }

    /** Typed commands in English / Urdu / Roman Urdu. Returns null when the text is not a phone command. */
    fun route(text: String): String? {
        val t = text.lowercase().trim().trimEnd('.', '!')

        // Speaker commands
        if (Regex("^(?:turn\\s+on\\s+speaker|speaker\\s+on|speaker\\s+kholo|speaker\\s+chalu\\s+(?:karo|kar\\s+do))$").containsMatchIn(t)) {
            return setSpeaker("on")
        }
        if (Regex("^(?:turn\\s+off\\s+speaker|speaker\\s+off|speaker\\s+band\\s+(?:karo|kar\\s+do))$").containsMatchIn(t)) {
            return setSpeaker("off")
        }

        // Call volume commands
        if (Regex("^(?:increase|raise|turn\\s+up)\\s+call\\s+volume$").containsMatchIn(t)) {
            return adjustVolume("up")
        }
        if (Regex("^(?:decrease|lower|turn\\s+down)\\s+call\\s+volume$").containsMatchIn(t)) {
            return adjustVolume("down")
        }

        // Flashlight / Torch commands
        if (Regex("^(?:turn\\s+on\\s+(?:torch|flashlight)|(?:torch|flashlight)\\s+on(?:\\s+(?:karo|kar\\s+do|kro|krdo))?|batti\\s+jalao|batti\\s+chalu\\s+(?:karo|kar\\s+do))$").containsMatchIn(t)) {
            return setTorch(true)
        }
        if (Regex("^(?:turn\\s+off\\s+(?:torch|flashlight)|(?:torch|flashlight)\\s+off(?:\\s+(?:karo|kar\\s+do|kro|krdo))?|batti\\s+bujhao|batti\\s+band\\s+(?:karo|kar\\s+do))$").containsMatchIn(t)) {
            return setTorch(false)
        }

        // Media & Volume commands
        if (Regex("^(?:play\\s+music|music\\s+play\\s+karo|song\\s+chalao|music\\s+chalao|play\\s+song|gana\\s+chalao)$").containsMatchIn(t)) {
            return controlMedia("play")
        }
        if (Regex("^(?:pause\\s+(?:music|song)|music\\s+pause\\s+karo|song\\s+pause\\s+karo|music\\s+roko|stop\\s+music|gana\\s+roko)$").containsMatchIn(t)) {
            return controlMedia("pause")
        }
        if (Regex("^(?:next\\s+(?:song|track)(?:\\s+chalao)?|next\\s+track|agla\\s+song(?:\\s+chalao)?|agla\\s+gana(?:\\s+chalao)?|agla\\s+video(?:\\s+chalao)?)$").containsMatchIn(t)) {
            return controlMedia("next")
        }
        if (Regex("^(?:previous\\s+(?:song|track)(?:\\s+chalao)?|prev(?:ious)?\\s+song(?:\\s+chalao)?|pichla\\s+song(?:\\s+chalao)?|pichla\\s+gana(?:\\s+chalao)?)$").containsMatchIn(t)) {
            return controlMedia("prev")
        }
        if (Regex("^(?:volume\\s+(?:badhao|barhao|badha\\s+do|barha\\s+do|tez\\s+karo|tez\\s+kar\\s+do)|turn\\s+up\\s+volume|raise\\s+volume|increase\\s+volume)$").containsMatchIn(t)) {
            return adjustMediaVolume("up")
        }
        if (Regex("^(?:volume\\s+(?:kam\\s+karo|kam\\s+kar\\s+do|kam\\s+kro|kam\\s+krdo|dheema\\s+karo)|turn\\s+down\\s+volume|lower\\s+volume|decrease\\s+volume)$").containsMatchIn(t)) {
            return adjustMediaVolume("down")
        }
        if (Regex("^(?:mute\\s+volume|volume\\s+mute\\s+karo|silent\\s+karo)$").containsMatchIn(t)) {
            return muteMedia()
        }

        // YouTube search and song commands
        val ytSongMatch = Regex("^(?:youtube\\s+par\\s+(.+?)\\s+(?:search\\s+karo|kholo|chalao)|(.+?)\\s+ke\\s+songs?\\s+(?:search\\s+karo|kholo|chalao|suno)|search\\s+(.+?)\\s+(?:on|in)\\s+youtube|search\\s+youtube\\s+(?:for\\s+)?(.+)|youtube\\s+kholo\\s+aur\\s+(.+?)\\s+ka\\s+song\\s+chalao)$").find(t)
        if (ytSongMatch != null) {
            val q = ytSongMatch.groupValues.drop(1).firstOrNull { it.isNotBlank() } ?: "songs"
            return searchYouTube(q)
        }

        // Global device navigation
        if (Regex("^(?:home\\s+screen\\s+par\\s+jao|go\\s+home|home\\s+jao|return\\s+to\\s+home)$").containsMatchIn(t)) {
            return navigateDevice("home")
        }
        if (Regex("^(?:back\\s+jao|go\\s+back|peeche\\s+jao)$").containsMatchIn(t)) {
            return navigateDevice("back")
        }
        if (Regex("^(?:open\\s+recents|recent\\s+apps(?:\\s+kholo)?|recent\\s+tasks)$").containsMatchIn(t)) {
            return navigateDevice("recents")
        }

        // Screen tap / click commands
        val clickMatch = Regex("^(?:click\\s+(?:on\\s+)?(.+)|tap\\s+(?:on\\s+)?(.+)|(.+?)\\s+par\\s+(?:click|tap)\\s+karo)$").find(t)
        if (clickMatch != null) {
            val target = clickMatch.groupValues.drop(1).firstOrNull { it.isNotBlank() } ?: ""
            if (target.isNotBlank() && target !in setOf("on", "off", "back", "home")) {
                return performScreenClick(target)
            }
        }

        // Screen scrolling commands
        val scrollMatch = Regex("^(?:scroll\\s+(down|up|forward|backward)|(neeche|ooper|aage|peeche)\\s+scroll\\s+karo)$").find(t)
        if (scrollMatch != null) {
            val dir = scrollMatch.groupValues.drop(1).firstOrNull { it.isNotBlank() } ?: "down"
            return performScreenScroll(dir)
        }

        // Focused option inspection for visually impaired users
        if (Regex("^(?:mujhe\\s+batao\\s+mere\\s+saamne\\s+kaunsa\\s+option\\s+hai|kaunsa\\s+option\\s+select\\s+hai|what\\s+option\\s+is\\s+focused|read\\s+focused\\s+element)$").containsMatchIn(t)) {
            return readFocusedElement()
        }

        // Search submit
        if (Regex("^(?:submit\\s+search|search\\s+submit\\s+karo|press\\s+enter)$").containsMatchIn(t)) {
            return submitSearch()
        }

        // Screen typing
        val typeMatch = Regex("^(?:type\\s+(.+)|enter\\s+text\\s+(.+)|screen\\s+par\\s+type\\s+karo\\s+(.+))$").find(t)
        if (typeMatch != null) {
            val txt = typeMatch.groupValues.drop(1).firstOrNull { it.isNotBlank() } ?: ""
            return enterTextOnScreen(txt)
        }

        // Screen Control commands
        if (Regex("^(?:open|show)\\s+screen\\s+control$").containsMatchIn(t)) {
            onNavigate?.invoke(Screen.ScreenControl)
            return "Opening screen control."
        }
        if (Regex("^(?:enable|turn\\s+on)\\s+full\\s+screen\\s+control$").containsMatchIn(t)) {
            setFlag("screen_control_full", true)
            return "Full screen control enabled."
        }
        if (Regex("^(?:disable|turn\\s+off)\\s+full\\s+screen\\s+control$").containsMatchIn(t)) {
            setFlag("screen_control_full", false)
            return "Full screen control disabled."
        }

        if (Regex("^(?:start|begin)\\s+screen\\s+sharing$").containsMatchIn(t)) {
            return controlScreenShare("start")
        }
        if (Regex("^(?:pause)\\s+screen\\s+sharing$").containsMatchIn(t)) {
            return controlScreenShare("pause")
        }
        if (Regex("^(?:resume)\\s+screen\\s+sharing$").containsMatchIn(t)) {
            return controlScreenShare("resume")
        }
        if (Regex("^(?:stop)\\s+screen\\s+sharing$").containsMatchIn(t)) {
            return controlScreenShare("stop")
        }
        if (Regex("^(?:stop)\\s+screen\\s+control$").containsMatchIn(t)) {
            JulietScreenCaptureService.instance?.stopCapture()
            setFlag("screen_control_session", false)
            return "Screen control session stopped."
        }
        if (Regex("^(?:what(?:'s|\\s+is)\\s+(?:showing\\s+on\\s+my\\s+screen|on\\s+my\\s+screen)|explain\\s+this\\s+screen|screen\\s+par\\s+kya\\s+(?:hai|likha\\s+hua\\s+hai|likha\\s+hai)|mujhe\\s+batao\\s+mere\\s+saamne\\s+kaunsa\\s+option\\s+hai|read\\s+(?:the\\s+)?screen|screen\\s+parh\\s+kar\\s+sunao|screen\\s+parh\\s+ke\\s+batao).*$").containsMatchIn(t)) {
            if (JulietScreenCaptureService.sharingState.value != SharingState.Sharing) {
                val a11ySummary = JulietAccessibilityService.instance?.dumpScreenText()
                if (!a11ySummary.isNullOrBlank() && !a11ySummary.startsWith("(")) {
                    return "Here is what I detect on screen:\n$a11ySummary"
                }
                return "Screen sharing is currently inactive. Please start screen sharing first so I can see your screen."
            }
            return null // Pass to Gemini Vision pipeline
        }

        // WhatsApp direct chat open command
        val waChatMatch = Regex("^(?:whatsapp\\s+kholo\\s+aur\\s+(.+?)\\s+ki\\s+chat\\s+dikhao|open\\s+whatsapp\\s+and\\s+show\\s+(.+?)\\s+chat)$").find(t)
        if (waChatMatch != null) {
            val contact = waChatMatch.groupValues.drop(1).firstOrNull { it.isNotBlank() } ?: ""
            return openWhatsAppChat(contact)
        }

        // SMS composing commands
        val smsMatch = Regex("^(?:send\\s+(?:an?\\s+)?sms|send\\s+(?:an?\\s+)?message|message\\s+bhejo|sms\\s+bhejo)\\s+(?:to\\s+)?(.+?)(?:\\s*:\\s*|\\s+saying\\s+|\\s+message\\s+)(.+)$", RegexOption.IGNORE_CASE).find(t)
        if (smsMatch != null) {
            return sendSms(smsMatch.groupValues[1], smsMatch.groupValues[2])
        }
        val urduSmsMatch = Regex("^(.+?)\\s+ko\\s+(?:message|sms)\\s+bhejo(?:\\s*:\\s*|\\s+ke\\s+|\\s+)(.+)$", RegexOption.IGNORE_CASE).find(t)
        if (urduSmsMatch != null) {
            return sendSms(urduSmsMatch.groupValues[1], urduSmsMatch.groupValues[2])
        }

        // Movies search & play command
        val movieMatch = Regex("^(?:koi\\s+achi\\s+)?(.+?\\s+movie|.+?\\s+film)(?:\\s+dhoondo|\\s+search\\s+karo)?(?:\\s+aur\\s+play\\s+karo|\\s+aur\\s+chalao)?$").find(t)
        if (movieMatch != null) {
            return searchMovie(movieMatch.groupValues[1])
        }

        // Incoming notifications announcement command
        if (Regex("^(?:meri\\s+incoming\\s+notifications\\s+parh\\s+kar\\s+sunao|notifications\\s+parh\\s+kar\\s+sunao|read\\s+(?:my\\s+)?notifications)$").containsMatchIn(t)) {
            onSummarize?.invoke("notifications", null, 10, true) {}
            return "Incoming notifications check kar rahi hoon..."
        }

        // Summaries commands
        if (Regex("^(?:open|show)\\s+summaries$").containsMatchIn(t)) {
            onNavigate?.invoke(Screen.Summaries)
            return "Opening Juliet Summaries."
        }
        val waSummaryMatch = Regex("^(?:summarize|summary\\s+of)\\s+(?:my\\s+)?(?:last\\s+(\\d+)\\s+)?whatsapp(?:\\s+messages?)?(?:\\s+from\\s+(.+))?$").find(t)
        if (waSummaryMatch != null) {
            val count = waSummaryMatch.groupValues[1].toIntOrNull() ?: 10
            val contact = waSummaryMatch.groupValues[2].takeIf { it.isNotBlank() }
            onSummarize?.invoke("whatsapp", contact, count, false) {}
            return "Generating summary of your WhatsApp messages..."
        }
        val notifSummaryMatch = Regex("^(?:what\\s+were\\s+the\\s+main\\s+points\\s+from\\s+my\\s+notifications(?:\\s+today)?|summarize\\s+(?:my\\s+)?notifications(?:\\s+today)?|notification\\s+summary)$").find(t)
        if (notifSummaryMatch != null) {
            val onlyToday = t.contains("today")
            onSummarize?.invoke("notifications", null, 15, onlyToday) {}
            return "Generating summary of your notifications..."
        }

        // Reminders commands
        if (Regex("^(?:open|show)\\s+reminders$").containsMatchIn(t)) {
            onNavigate?.invoke(Screen.Reminders)
            return "Opening Smart Reminders."
        }
        val remindMatch = Regex("^(?:remind\\s+me|set\\s+(?:a\\s+)?reminder)\\s+(.+)$").find(t)
        if (remindMatch != null) {
            val details = remindMatch.groupValues[1]
            val res = onSetReminder?.invoke(details, "", "Once")
            return res ?: "Reminder set."
        }

        // Settings command
        val settingsMatch = Regex("^(?:open\\s+settings|settings\\s+kholo)(?:\\s+(?:for\\s+)?(.+))?$").find(t)
        if (settingsMatch != null) {
            val page = settingsMatch.groupValues[1].trim()
            return openSettings(page)
        }

        // Standard App / Phone / Call commands
        Regex("^(?:open|launch)\\s+(.+)$").find(t)?.let { return openApp(it.groupValues[1]) }
        Regex("^(.+?)\\s+(?:kholo|khol do|kholdo|open karo|chalu karo)$").find(t)?.let { return openApp(it.groupValues[1]) }

        if (Regex("^(?:mujhe\\s+kisi\\s+ko\\s+call\\s+karni\\s+hai|kisi\\s+ko\\s+call\\s+karni\\s+hai|i\\s+want\\s+to\\s+call\\s+someone)$").containsMatchIn(t)) {
            return "Aap kis ko call karna chahte hain? Contact ka naam batayein."
        }
        Regex("^(?:call\\s+(?:lagao|milao|karo)?\\s*(?:to\\s+)?|call\\s+)(.+)$").find(t)?.let { return call(it.groupValues[1]) }
        Regex("^(.+?)\\s+ko\\s+call(?:\\s+(?:lagao|milao|karo|kro|kar do|laga do))?$").find(t)?.let { return call(it.groupValues[1]) }
        Regex("^(.+?)\\s+ko\\s+whatsapp(?:\\s+(?:karo|kro))?\\s*(.*)$").find(t)?.let { return whatsapp(it.groupValues[1], it.groupValues[2]) }

        // Voice announcements
        Regex("^(enable|disable|turn on|turn off)\\s+voice announcements?$").find(t)?.let { return toggle("ann_on", it.groupValues[1], "Voice announcements") }
        Regex("^announce\\s+incoming\\s+calls?$").find(t)?.let { return toggle("ann_calls", "on", "Incoming calls announcement") }
        Regex("^read\\s+message\\s+notifications?$").find(t)?.let {
            setFlag("ann_privacy", false)
            return toggle("ann_content", "on", "Reading message content")
        }
        Regex("^(enable|disable|turn on|turn off)\\s+privacy mode$").find(t)?.let { return toggle("ann_privacy", it.groupValues[1], "Privacy mode") }
        Regex("^stop announcements?$").find(t)?.let { Announcer.stop(); return "Stopped." }
        Regex("^remember[:\\s]+(.+)$", RegexOption.IGNORE_CASE).find(text.trim())?.let { return remember(it.groupValues[1]) }

        return null
    }

    // ---- Gemini Live tool calling ----
    fun execute(name: String, a: JSONObject): String = when (name) {
        "open_app" -> openApp(a.optString("app_name"))
        "search_youtube" -> searchYouTube(a.optString("query"))
        "control_media" -> controlMedia(a.optString("action"))
        "adjust_media_volume" -> adjustMediaVolume(a.optString("direction"))
        "set_flashlight" -> setTorch(isOn(a.optString("state")))
        "navigate_device" -> navigateDevice(a.optString("action"))
        "open_settings" -> openSettings(a.optString("page"))
        "enter_text" -> enterTextOnScreen(a.optString("text"))
        "call_contact" -> call(a.optString("name"))
        "send_whatsapp" -> whatsapp(a.optString("name"), a.optString("message"))
        "remember" -> remember(a.optString("text"))
        "set_speaker" -> setSpeaker(a.optString("state"))
        "adjust_call_volume" -> adjustVolume(a.optString("direction"))
        "open_screen_control" -> {
            onNavigate?.invoke(Screen.ScreenControl)
            "Opening screen control."
        }
        "set_full_screen_control" -> toggle("screen_control_full", a.optString("state"), "Full screen control")
        "control_screen_share" -> controlScreenShare(a.optString("action"))
        "click_on_screen" -> performScreenClick(a.optString("target"))
        "scroll_screen" -> performScreenScroll(a.optString("direction"))
        "summarize_messages" -> {
            val target = a.optString("target", "whatsapp")
            val contact = a.optString("contact").takeIf { it.isNotBlank() }
            val count = a.optInt("count", 10)
            onSummarize?.invoke(target, contact, count, false) {}
            "Generating summary of $target messages."
        }
        "create_reminder" -> {
            val title = a.optString("title")
            val time = a.optString("time")
            val recurrence = a.optString("recurrence", "Once")
            onSetReminder?.invoke(title, time, recurrence) ?: "Reminder created."
        }
        "open_summaries" -> {
            onNavigate?.invoke(Screen.Summaries)
            "Opening Juliet Summaries."
        }
        "open_reminders" -> {
            onNavigate?.invoke(Screen.Reminders)
            "Opening Smart Reminders."
        }
        "send_sms" -> sendSms(a.optString("name"), a.optString("message"))
        "open_whatsapp_chat" -> openWhatsAppChat(a.optString("name"))
        "search_movie" -> searchMovie(a.optString("query"))
        "ask_about_screen" -> {
            val q = a.optString("question", "What is currently displayed on screen?")
            var responseHolder: String? = null
            val latch = java.util.concurrent.CountDownLatch(1)
            onInspectScreen?.invoke(q) { ans ->
                responseHolder = ans
                latch.countDown()
            }
            latch.await(8, java.util.concurrent.TimeUnit.SECONDS)
            responseHolder ?: "Inspecting your screen right now."
        }
        "set_announcements" -> toggle("ann_on", a.optString("state"), "Voice announcements")
        "set_privacy_mode" -> toggle("ann_privacy", a.optString("state"), "Privacy mode")
        "set_whatsapp_autoreply" -> autoReply(a.optString("state"))
        "stop_announcement" -> { Announcer.stop(); "Stopped." }
        else -> "Unknown action $name"
    }

    private fun fn(name: String, desc: String, params: Map<String, String>) = JSONObject()
        .put("name", name).put("description", desc)
        .put("parameters", JSONObject().put("type", "OBJECT")
            .put("properties", JSONObject().also { p ->
                params.forEach { (k, v) -> p.put(k, JSONObject().put("type", "STRING").put("description", v)) }
            })
            .put("required", JSONArray(params.keys.toList())))

    fun declarations(): JSONArray = JSONArray()
        .put(fn("open_app", "Open an app installed on the phone", mapOf("app_name" to "App name, e.g. YouTube, WhatsApp, Camera, Gallery")))
        .put(fn("search_youtube", "Search YouTube for music, videos, or artists and launch playback", mapOf("query" to "Search term or song title, e.g. Atif Aslam songs")))
        .put(fn("search_movie", "Search and play movies or films on YouTube or video player", mapOf("query" to "Movie name or genre, e.g. action movie")))
        .put(fn("control_media", "Play, pause, skip, or return to previous media track", mapOf("action" to "play, pause, next, or previous")))
        .put(fn("adjust_media_volume", "Increase or decrease device media volume", mapOf("direction" to "up or down")))
        .put(fn("set_flashlight", "Turn the device torch / flashlight on or off", mapOf("state" to "on or off")))
        .put(fn("navigate_device", "Perform global navigation on the device", mapOf("action" to "home, back, or recents")))
        .put(fn("open_settings", "Open Android Settings or specific sub-settings page", mapOf("page" to "main, wifi, bluetooth, sound, display, accessibility, or notifications")))
        .put(fn("enter_text", "Type text into the currently focused or active input field on screen", mapOf("text" to "Text to type")))
        .put(fn("call_contact", "Call a saved contact by name", mapOf("name" to "Contact name")))
        .put(fn("send_sms", "Compose and send an SMS text message to a contact", mapOf("name" to "Contact name or phone number", "message" to "Text message body")))
        .put(fn("send_whatsapp", "Open WhatsApp with a message for a contact", mapOf("name" to "Contact name", "message" to "Message text")))
        .put(fn("open_whatsapp_chat", "Open WhatsApp chat directly for a contact", mapOf("name" to "Contact name")))
        .put(fn("ask_about_screen", "Inspect the visible screen contents using Gemini vision or accessibility tree to answer questions about what is on screen", mapOf("question" to "Question about the screen")))
        .put(fn("set_speaker", "Turn the phone call speaker/loudspeaker on or off", mapOf("state" to "on or off")))
        .put(fn("adjust_call_volume", "Increase or decrease phone call volume", mapOf("direction" to "up or down")))
        .put(fn("open_screen_control", "Open the Screen Control and screen sharing interface", emptyMap()))
        .put(fn("set_full_screen_control", "Enable or disable full screen control permissions", mapOf("state" to "on or off")))
        .put(fn("control_screen_share", "Start, pause, resume or stop live screen sharing", mapOf("action" to "start, pause, resume, or stop")))
        .put(fn("click_on_screen", "Tap or click on an interface element or button by text", mapOf("target" to "Text or name of button to tap")))
        .put(fn("scroll_screen", "Scroll the screen up or down", mapOf("direction" to "up or down")))
        .put(fn("summarize_messages", "Generate an executive summary of WhatsApp messages or notifications highlighting key points, decisions, and action items", mapOf("target" to "whatsapp or notifications", "count" to "Number of items to summarize")))
        .put(fn("create_reminder", "Create and schedule a smart reminder with notification and optional voice alert", mapOf("title" to "Task or reminder title", "time" to "When to remind (e.g. tomorrow at 2 PM, in 30 minutes)", "recurrence" to "Once, Daily, Weekly, or Weekdays")))
        .put(fn("open_summaries", "Open the Juliet Summaries screen", emptyMap()))
        .put(fn("open_reminders", "Open the Smart Reminders screen", emptyMap()))
        .put(fn("remember", "Save a fact the user wants Juliet to remember", mapOf("text" to "The fact to remember")))
        .put(fn("set_announcements", "Turn spoken announcements of calls and messages on or off", mapOf("state" to "on or off")))
        .put(fn("set_privacy_mode", "Turn privacy mode on or off (hides message text in announcements)", mapOf("state" to "on or off")))
        .put(fn("set_whatsapp_autoreply", "Turn WhatsApp auto-reply on or off", mapOf("state" to "on or off")))
        .put(JSONObject().put("name", "stop_announcement").put("description", "Stop a spoken announcement"))
}
