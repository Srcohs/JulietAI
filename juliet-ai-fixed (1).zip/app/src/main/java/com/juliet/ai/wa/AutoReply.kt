package com.juliet.ai.wa

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import com.juliet.ai.BuildConfig
import com.juliet.ai.data.Knowledge
import com.juliet.ai.data.BotCategories
import com.juliet.ai.data.BotNode
import com.juliet.ai.data.Prefs
import com.juliet.ai.net.GroqClient
import com.juliet.ai.phone.ContactNames
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * WhatsApp bot that ONLY answers from the owner's own data:
 *   - the category tree (menu / subcategory / option answers), and
 *   - the saved knowledge facts.
 * Anything outside that is never answered (silent, optional owner alert).
 *
 * Two modes (setting `wa_mode`):
 *   "category": menu first. Greeting / first contact shows the categories; numbers or names
 *               navigate; free text is matched against the tree locally (no AI).
 *   "auto":     Gemini reads the whole conversation (not just the last line) and answers only
 *               if the answer is fully supported by the saved data; strict JSON + guards.
 *
 * Real-time handling: rapid-fire messages from one sender are merged (1.8 s debounce) so the
 * bot reads the complete message before replying and no message is dropped.
 */
class AutoReply(private val ctx: Context, private val prefs: Prefs) {
    class Reply(val text: String, val handover: Boolean)

    private class Pending(val texts: MutableList<String>, @Volatile var action: Notification.Action, val name: String) {
        @Volatile var lastAt: Long = System.currentTimeMillis()
    }
    private class MenuSt(val node: String, val at: Long)

    companion object {
        private val HINDI_TERMS = Regex("(?i)\\b(dhanyawad|kripya|namaste|namaskar|samay|mitra|shukriya\\s*ji|dhanyavaad)\\b")
        private const val DEBOUNCE_MS = 1800L
        private const val MENU_TTL = 30 * 60_000L
        private const val OWNER_ALERT_GAP = 10 * 60_000L
        private val STOP = setOf(
            "hai", "hain", "hy", "he", "ka", "ki", "ke", "ko", "se", "me", "mein", "main", "aur", "ya", "kya", "kia",
            "the", "is", "are", "a", "an", "to", "of", "for", "and", "in", "on", "please", "plz", "pls", "mujhe",
            "batao", "bata", "btao", "do", "dein", "den", "kar", "kro", "karo", "ap", "aap", "i", "you", "me", "my",
            "can", "tell", "about", "what", "how", "ji", "sir", "bhai", "hello", "hi", "salam", "kitna", "kitni", "kab"
        )
    }

    private val groq = GroqClient()
    private val knowledge = Knowledge(prefs)
    private val categories = BotCategories(prefs)
    private val menuState = ConcurrentHashMap<String, MenuSt>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val processed = LinkedHashSet<String>()
    private val manualUntil = ConcurrentHashMap<String, Long>()
    private val greetedAt = ConcurrentHashMap<String, Long>()
    private val ownerAlertAt = ConcurrentHashMap<String, Long>()
    private val history = ConcurrentHashMap<String, MutableList<GroqClient.Msg>>()
    private val pending = ConcurrentHashMap<String, Pending>()
    private val workers = ConcurrentHashMap<String, Boolean>()

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val greet = Regex("(?i)(\\bhi\\b|\\bhello\\b|\\bhey\\b|good morning|good evening|good afternoon|assalam\\w*(\\s*o?\\s*alaikum)?|a?salam\\s*o\\s*alaikum|aslam\\s*o\\s*alaikum|salaam|salam|\\baoa\\b|a\\.o\\.a|السلام\\s*علیکم|السلام\\s*عليكم|سلام)")

    private fun mode(): String = prefs.get("wa_mode", "category")

    fun handle(inc: Incoming) {
        if (!inc.verifiedPrivate || inc.isGroup || inc.isChannel) {
            WhatsAppDiagnostics.recordStatus("Ignored message: Group or channel (${inc.sender})")
            return
        }
        val action = inc.replyAction
        if (action == null) {
            WhatsAppDiagnostics.recordStatus("Failed: No RemoteInput reply action found in notification", "RemoteInput missing")
            return
        }
        if (inc.sender.isBlank() || inc.text.isBlank()) return
        if (!inc.fromOther) return

        synchronized(processed) {
            if (!processed.add(inc.id)) {
                WhatsAppDiagnostics.recordStatus("Skipped duplicate notification ID")
                return
            }
            if (processed.size > 500) processed.remove(processed.first())
        }

        val resolvedName = if (ContactNames.looksLikeNumber(inc.sender)) {
            ContactNames.forNumber(ctx, inc.sender) ?: inc.sender
        } else inc.sender

        WhatsAppDiagnostics.recordIncoming(resolvedName, inc.text)

        if ((manualUntil[inc.sender] ?: 0L) > System.currentTimeMillis()) {
            WhatsAppDiagnostics.recordStatus("Manual mode active for ${inc.sender} (suppressed for 15m)")
            return
        }
        enqueue(inc.sender, resolvedName, inc.text, action)
    }

    /** Called when the user opens/dismisses the chat notification. Pauses the bot for that chat for 15 min. */
    fun markManual(sender: String) {
        manualUntil[sender] = System.currentTimeMillis() + 15 * 60_000L
        pending.remove(sender)
        WhatsAppDiagnostics.recordStatus("User clicked notification for $sender, paused auto-reply for 15m")
    }

    // ---------- real-time batching: read the COMPLETE message before replying ----------
    private fun enqueue(sender: String, name: String, text: String, action: Notification.Action) {
        val p = pending.getOrPut(sender) { Pending(mutableListOf(), action, name) }
        synchronized(p.texts) { if (p.texts.lastOrNull() != text) p.texts.add(text) }
        p.action = action
        p.lastAt = System.currentTimeMillis()
        startWorker(sender)
    }

    private fun startWorker(sender: String) {
        if (workers.putIfAbsent(sender, true) != null) return
        scope.launch {
            try {
                while (true) {
                    delay(300)
                    val p = pending[sender] ?: break
                    if (System.currentTimeMillis() - p.lastAt < DEBOUNCE_MS) continue
                    pending.remove(sender, p)
                    try { process(sender, p) } catch (e: Exception) {
                        WhatsAppDiagnostics.recordStatus("Bot error: ${e.message}", "Exception")
                    }
                    if (!pending.containsKey(sender)) break
                }
            } finally {
                workers.remove(sender)
                if (pending.containsKey(sender)) startWorker(sender)
            }
        }
    }

    private suspend fun process(who: String, p: Pending) {
        val combined = synchronized(p.texts) { p.texts.joinToString("\n") }.trim()
        if (combined.isBlank()) return
        val hist = history.getOrPut(who) { mutableListOf() }
        synchronized(hist) {
            hist.add(GroqClient.Msg("user", combined))
            while (hist.size > 20) hist.removeAt(0)
        }
        val reply = decide(p.name, combined, synchronized(hist) { hist.toList() }, true, who)
        if (reply == null) {
            WhatsAppDiagnostics.recordStatus("Stayed silent for ${p.name} (not in saved knowledge/categories)")
            return
        }
        delay((500L..1200L).random())
        if ((manualUntil[who] ?: 0L) > System.currentTimeMillis()) return

        if (send(p.action, reply.text)) {
            synchronized(hist) { hist.add(GroqClient.Msg("assistant", reply.text)) }
            WhatsAppDiagnostics.recordReply(p.name, reply.text)
        } else {
            WhatsAppDiagnostics.recordStatus("Error sending reply via RemoteInput Intent", "Send intent failed")
        }
    }

    suspend fun preview(sender: String, msg: String): String {
        val r = decide(sender, msg, listOf(GroqClient.Msg("user", msg)), false, "preview:$sender")
            ?: return "(Juliet would stay silent here: not covered by your categories/knowledge)"
        return r.text
    }

    // ---------- decision ----------
    private fun isGreetingOnly(t: String): Boolean {
        if (!greet.containsMatchIn(t)) return false
        val rest = greet.replace(t, "").replace(Regex("[\\p{Punct}\\s]+"), "")
        return rest.length <= 10 && !t.contains('?') && !t.contains('؟')
    }

    private fun welcome(): String = prefs.get("wa_welcome").trim().ifBlank { "Assalam o Alaikum wa Rahmatullah!" }

    private fun list(nodes: List<BotNode>): String = nodes.mapIndexed { i, n -> "${i + 1}. ${n.title}" }.joinToString("\n")

    private fun rootMenu(key: String, intro: String?): String? {
        val roots = categories.menu("")
        if (roots.isEmpty()) return null
        menuState[key] = MenuSt("", System.currentTimeMillis())
        greetedAt[key] = System.currentTimeMillis()
        return (if (intro.isNullOrBlank()) "" else intro + "\n\n") +
            "Barah-e-karam ek category select karein:\n" + list(roots) + "\n\n(Dobara menu ke liye 'menu' likhein)"
    }

    private suspend fun decide(who: String, msg: String, hist: List<GroqClient.Msg>, record: Boolean, key: String): Reply? {
        val now = System.currentTimeMillis()
        val t = msg.trim()
        val mode = mode()
        val roots = categories.menu("")
        val st = menuState[key]
        val active = st != null && now - st.at < MENU_TTL
        if (!active) menuState.remove(key)

        if (roots.isNotEmpty() && t.lowercase().trim('.', '!', ' ') in setOf("menu", "main menu", "categories", "category")) {
            return rootMenu(key, null)?.let { Reply(it, false) }
        }

        if (isGreetingOnly(t)) {
            val w = welcome()
            if (mode == "category") rootMenu(key, w)?.let { return Reply(it, false) }
            return Reply(w + if (roots.isNotEmpty()) "\n\nCategories ke liye 'menu' likhein, ya apna sawal poochein." else "\n\nJi, apna sawal poochein.", false)
        }

        if (active) navigate(key, t)?.let { return Reply(it, false) }

        bestMatch(t)?.let { return Reply(render(key, it), false) }

        if (mode == "category") {
            val first = (greetedAt[key] ?: 0L) + 6 * 3600_000L < now
            if (first && roots.isNotEmpty()) rootMenu(key, welcome())?.let { return Reply(it, false) }
            return unknown(who, t, record, key)
        }

        // ----- AUTO mode: grounded AI -----
        val corpus = buildCorpus()
        if (corpus.isBlank()) return unknown(who, t, record, key)
        val clock = SimpleDateFormat("EEEE h:mm a", Locale.ENGLISH).format(Date())
        val systemPrompt = """
You are Juliet, answering WhatsApp messages on behalf of the owner. You are STRICTLY LIMITED to the KNOWLEDGE below.

HOW TO WORK:
1. Read the WHOLE conversation (oldest to newest), not only the last line. Work out what the sender means NOW. Follow-ups such as "aur price?" or "and timing?" refer to the earlier topic.
2. Find the answer in KNOWLEDGE. Use only facts written there. Never invent or guess names, prices, times, numbers, phone numbers, links or policies.
3. If KNOWLEDGE fully answers it, reply briefly in the sender's language style.
4. If KNOWLEDGE does not fully answer it, you must NOT answer from general knowledge.
5. A short polite acknowledgement for "thanks" / "ok" / "bye" is allowed (no new facts).

OUTPUT: return ONLY a JSON object, nothing else:
{"grounded": true|false, "answer": "reply text, or empty if grounded is false"}

LANGUAGE (absolute): English or Roman Urdu only. Never Urdu script, Hindi, Devanagari or Punjabi. Never use words like dhanyawad, kripya, namaste.
Keep answers short (1-3 sentences) unless a saved answer is longer; saved answers may be copied as written.

KNOWLEDGE:
$corpus

Current local time: $clock. Sender name: $who.
""".trimIndent()

        val raw = generateAIResponse(systemPrompt, hist) ?: return null
        val parsed = parseGrounded(raw) ?: return unknown(who, t, record, key)
        val answer = sanitizeText(parsed.second)
        if (!parsed.first || answer.isBlank()) return unknown(who, t, record, key)
        if (!supported(answer, corpus, t)) {
            WhatsAppDiagnostics.recordStatus("Blocked unsupported AI answer (numbers/links not in knowledge)")
            return unknown(who, t, record, key)
        }
        return Reply(answer, false)
    }

    /** Nothing in the saved data answers this: stay silent (default) or re-offer the menu. Owner is alerted (throttled). */
    private fun unknown(who: String, msg: String, record: Boolean, key: String): Reply? {
        if (record) {
            val now = System.currentTimeMillis()
            if (now - (ownerAlertAt[key] ?: 0L) > OWNER_ALERT_GAP) {
                ownerAlertAt[key] = now
                notifyOwner(who, msg)
            }
        }
        if (prefs.get("wa_unknown", "silent") == "menu") {
            rootMenu(key, "Main sirf in categories mein madad kar sakti hoon.")?.let { return Reply(it, false) }
        }
        return null
    }

    // ---------- category navigation ----------
    private fun navigate(key: String, t: String): String? {
        val st = menuState[key] ?: return null
        val cur = categories.menu(st.node)
        val low = t.lowercase().trim()
        if (low in setOf("back", "wapis", "0")) {
            val parent = categories.find(st.node)?.parentId ?: ""
            if (st.node.isBlank()) return rootMenu(key, null)
            val nodes = categories.menu(parent)
            menuState[key] = MenuSt(parent, System.currentTimeMillis())
            return list(nodes).let { "Barah-e-karam ek option select karein:\n$it" }
        }
        val number = low.toIntOrNull()
        val selected = when {
            number != null && number in 1..cur.size -> cur[number - 1]
            else -> cur.firstOrNull { it.title.equals(t.trim(), true) }
        } ?: return null
        return render(key, selected)
    }

    private fun render(key: String, n: BotNode): String {
        val children = categories.menu(n.id)
        if (children.isNotEmpty()) {
            menuState[key] = MenuSt(n.id, System.currentTimeMillis())
            val head = if (n.answer.isNotBlank()) n.answer + "\n\n" else ""
            return head + "${n.title}\nBarah-e-karam ek option select karein:\n" + list(children) + "\n\n('back' likhein wapis jane ke liye)"
        }
        menuState[key] = MenuSt(n.parentId, System.currentTimeMillis())
        return n.answer.ifBlank { n.title } + "\n\n(Menu ke liye 'menu' likhein)"
    }

    // ---------- local matching against the tree ----------
    private fun tokens(s: String): List<String> =
        s.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 2 && it !in STOP }

    private fun tokEq(a: String, b: String) = a == b || (a.length >= 4 && b.length >= 4 && (a.startsWith(b) || b.startsWith(a)))

    /** Clear single best node for a free-text question, or null. */
    private fun bestMatch(msg: String): BotNode? {
        val q = tokens(msg).distinct()
        if (q.isEmpty()) return null
        val nodes = categories.all().filter { it.enabled && (it.answer.isNotBlank() || categories.menu(it.id).isNotEmpty()) }
        if (nodes.isEmpty()) return null
        val scored = nodes.map { n ->
            val tt = tokens(n.title); val at = tokens(n.answer)
            val titleHit = q.count { w -> tt.any { tokEq(it, w) } }
            val ansHit = q.count { w -> tt.none { tokEq(it, w) } && at.any { tokEq(it, w) } }
            val score = (2.0 * titleHit + ansHit) / (2.0 * q.size)
            Triple(n, score, titleHit)
        }.filter { it.third >= 1 }.sortedByDescending { it.second }
        val top = scored.firstOrNull() ?: return null
        val second = scored.getOrNull(1)?.second ?: 0.0
        return if (top.second >= 0.6 && top.second - second >= 0.15) top.first else null
    }

    // ---------- grounding corpus & guards ----------
    private fun buildCorpus(): String {
        val sb = StringBuilder()
        val facts = knowledge.promptFacts()
        if (!facts.contains("(nothing saved yet)")) sb.append("FACTS:\n").append(facts).append('\n')
        val nodes = categories.all().filter { it.enabled }
        if (nodes.isNotEmpty()) {
            sb.append("CATEGORIES (Category > Subcategory > Option: saved answer):\n")
            fun walk(parent: String, path: String, depth: Int) {
                if (depth > 4 || sb.length > 12000) return
                for (n in nodes.filter { it.parentId == parent }) {
                    val p = if (path.isEmpty()) n.title else "$path > ${n.title}"
                    if (n.answer.isNotBlank()) sb.append("- ").append(p).append(": ").append(n.answer).append('\n')
                    else if (nodes.none { it.parentId == n.id }) sb.append("- ").append(p).append('\n')
                    walk(n.id, p, depth + 1)
                }
            }
            walk("", "", 0)
        }
        return sb.toString().trim()
    }

    private fun parseGrounded(raw: String): Pair<Boolean, String>? {
        val s = raw.indexOf('{'); val e = raw.lastIndexOf('}')
        if (s < 0 || e <= s) return null
        return try {
            val o = JSONObject(raw.substring(s, e + 1))
            o.optBoolean("grounded", false) to o.optString("answer", "").trim()
        } catch (_: Exception) { null }
    }

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    /** Numbers and links in the answer must exist in the saved data (or in the sender's own message). */
    private fun supported(answer: String, corpus: String, userText: String): Boolean {
        val c = norm(corpus); val u = norm(userText)
        for (m in Regex("\\d{2,}").findAll(answer.replace(Regex("(?<=\\d)[\\s,.-](?=\\d)"), ""))) {
            if (!c.contains(m.value) && !u.contains(m.value)) return false
        }
        val cl = corpus.lowercase()
        for (m in Regex("(https?://\\S+|www\\.\\S+)").findAll(answer.lowercase())) {
            if (!cl.contains(m.value.trimEnd('.', ',', ')'))) return false
        }
        return true
    }

    private suspend fun generateAIResponse(systemPrompt: String, hist: List<GroqClient.Msg>): String? {
        val geminiKey = prefs.get("k_gemini").ifBlank { BuildConfig.DEFAULT_GEMINI_KEY }
        val g = if (geminiKey.isNotBlank()) (callGemini(geminiKey, systemPrompt, hist) ?: callGemini(geminiKey, systemPrompt, hist)) else null
        return g ?: callGroq(systemPrompt, hist)
    }

    private fun sanitizeText(input: String): String {
        var clean = input.trim()
        clean = HINDI_TERMS.replace(clean, "")
        clean = clean.replace(Regex("[\\u0900-\\u097F]+"), "")
        return clean.trim()
    }

    private suspend fun callGemini(key: String, system: String, hist: List<GroqClient.Msg>): String? = withContext(Dispatchers.IO) {
        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$key"
            val contents = JSONArray()
            hist.takeLast(16).forEach { m ->
                val role = if (m.role == "user") "user" else "model"
                contents.put(JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", m.content))))
            }
            val payload = JSONObject().apply {
                put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                put("contents", contents)
                put("generationConfig", JSONObject().put("temperature", 0.2).put("maxOutputTokens", 700)
                    .put("responseMimeType", "application/json"))
            }.toString().toRequestBody("application/json".toMediaType())

            val req = Request.Builder().url(url).post(payload).build()
            httpClient.newCall(req).execute().use { res ->
                if (!res.isSuccessful) return@withContext null
                val json = JSONObject(res.body?.string().orEmpty())
                val parts = json.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                parts?.optJSONObject(0)?.optString("text")
            }
        } catch (e: Exception) {
            null
        }
    }

    private suspend fun callGroq(system: String, hist: List<GroqClient.Msg>): String? {
        val keys = groqKeys()
        if (keys.isEmpty()) return null
        return groq.chat(keys, system, hist).getOrNull()
    }

    private fun groqKeys(): List<String> =
        prefs.get("k_groq").ifBlank { BuildConfig.DEFAULT_GROQ_KEYS }.split(",").map { it.trim() }.filter { it.isNotEmpty() }

    private fun send(action: Notification.Action, text: String): Boolean = try {
        val inputs = action.remoteInputs ?: return false
        val data = Bundle()
        for (r in inputs) data.putCharSequence(r.resultKey, text)
        val intent = Intent()
        RemoteInput.addResultsToIntent(inputs, intent, data)
        action.actionIntent.send(ctx, 0, intent)
        true
    } catch (e: Exception) {
        false
    }

    private fun notifyOwner(who: String, msg: String) {
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channelId = "juliet_handover"
            val channel = NotificationChannel(channelId, "Juliet Awaiting Reply", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Messages the bot could not answer from your saved knowledge"
            }
            nm.createNotificationChannel(channel)
            val n = Notification.Builder(ctx, channelId)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("$who: bot ke paas jawab nahi")
                .setContentText(msg.take(120))
                .setAutoCancel(true)
                .build()
            nm.notify(who.hashCode(), n)
        } catch (_: Exception) { }
    }
}
