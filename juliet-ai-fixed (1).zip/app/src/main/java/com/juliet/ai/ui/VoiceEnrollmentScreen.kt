package com.juliet.ai.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.juliet.ai.data.VoiceProfile
import com.juliet.ai.vm.JulietViewModel

@Composable
fun VoiceEnrollmentScreen(vm: JulietViewModel) {
    val p = LocalPal.current
    var addSpeakerDlg by remember { mutableStateOf(false) }
    var renameDlg by remember { mutableStateOf<VoiceProfile?>(null) }
    var newSpeakerName by remember { mutableStateOf("") }
    var renameText by remember { mutableStateOf("") }
    var enrollingForOwner by remember { mutableStateOf(true) }
    var targetSpeakerName by remember { mutableStateOf("") }

    val enrollmentPhrases = listOf(
        "\"Hey Juliet, meri madad karo.\"",
        "\"Juliet, aaj ka weather kaisa hai?\"",
        "\"Juliet, main yahan hoon.\""
    )

    Page("Voice Enrollment & Lock", {
        if (vm.isEnrollingVoice) vm.cancelEnrollment()
        vm.back()
    }) {
        // Status Overview Card
        val ownerProfile = vm.voiceProfiles.find { it.isOwner }
        val isLocked = vm.s("voice_lock_enabled") == "1"

        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = p.card),
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
        ) {
            Column(Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(46.dp).clip(CircleShape)
                            .background(if (ownerProfile != null) J.Ok.copy(alpha = 0.2f) else J.Red.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (ownerProfile != null) Icons.Rounded.VerifiedUser else Icons.Rounded.VoiceOverOff,
                            contentDescription = "Enrollment status",
                            tint = if (ownerProfile != null) J.Ok else J.Red,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            text = if (ownerProfile != null) "Voice Enrolled: ${ownerProfile.name}" else "Owner Voice Not Enrolled",
                            color = p.text,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Text(
                            text = if (isLocked) "Voice Lock: ACTIVE (Protected)" else "Voice Lock: Inactive (Open access)",
                            color = if (isLocked) J.Gold else p.mu,
                            fontSize = 13.sp
                        )
                    }
                }

                Spacer(Modifier.height(14.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Authorized Profiles: ${vm.voiceProfiles.size}", color = p.mu, fontSize = 12.sp)
                        Text("Wake Word: \"Juliet\"", color = p.mu, fontSize = 12.sp)
                    }
                    Switch(
                        checked = isLocked,
                        onCheckedChange = { vm.set("voice_lock_enabled", if (it) "1" else "0") },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = J.Gold,
                            checkedTrackColor = J.Gold.copy(alpha = 0.4f)
                        ),
                        modifier = Modifier.testTag("voice_lock_toggle")
                    )
                }
            }
        }

        // Active Recording / Visualizer View
        if (vm.isEnrollingVoice || vm.isTestingVoice) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = p.card2),
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp).border(1.dp, J.Red.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val pulseAnim by rememberInfiniteTransition(label = "pulse").animateFloat(
                        initialValue = 0.9f,
                        targetValue = 1.15f,
                        animationSpec = infiniteRepeatable(tween(600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
                        label = "pulse"
                    )

                    Box(
                        Modifier.size(80.dp).clip(CircleShape)
                            .background(Brush.radialGradient(listOf(J.Red, J.Dark)))
                            .padding((8 * (pulseAnim * (1f + vm.enrollmentAudioLevel))).dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Mic,
                            contentDescription = "Listening",
                            tint = Color.White,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    Spacer(Modifier.height(14.dp))
                    Text(
                        text = if (vm.isTestingVoice) "Testing Voice Recognition..." else "Recording Sample ${vm.enrollmentStep + 1} of 3",
                        color = p.text,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )

                    if (vm.isEnrollingVoice) {
                        val currentPrompt = enrollmentPhrases.getOrElse(vm.enrollmentStep) { "\"Juliet, meri madad karo.\"" }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = "Please speak aloud:",
                            color = p.mu,
                            fontSize = 13.sp
                        )
                        Text(
                            text = currentPrompt,
                            color = J.Gold,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    } else {
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "Say anything to test speaker verification (e.g. \"Juliet, what is the time?\")",
                            color = p.mu,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        )
                    }

                    Spacer(Modifier.height(12.dp))
                    // Real-time audio waveform level bar
                    LinearProgressIndicator(
                        progress = { vm.enrollmentAudioLevel },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                        color = J.Red,
                        trackColor = p.bg
                    )

                    Spacer(Modifier.height(14.dp))
                    OutlinedButton(
                        onClick = { vm.cancelEnrollment() },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = J.Red)
                    ) {
                        Text("Cancel")
                    }
                }
            }
        }

        // Test Verification Result Card
        vm.testVerificationResult?.let { res ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (res.isAuthorized) J.Ok.copy(alpha = 0.15f) else J.Red.copy(alpha = 0.15f)
                ),
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
                    .border(1.dp, if (res.isAuthorized) J.Ok.copy(alpha = 0.4f) else J.Red.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (res.isAuthorized) Icons.Rounded.CheckCircle else Icons.Rounded.Cancel,
                            contentDescription = null,
                            tint = if (res.isAuthorized) J.Ok else J.Red,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            text = if (res.isAuthorized) "Speaker Verified ✔" else "Speaker Verification Failed ✖",
                            color = if (res.isAuthorized) J.Ok else J.Red,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Spacer(Modifier.weight(1f))
                        Text(
                            text = "${(res.confidence * 100).toInt()}% Match",
                            color = p.text,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(res.details, color = p.text, fontSize = 13.sp)
                }
            }
        }

        // Action Buttons: Enroll My Voice, Add Speaker, Test
        Sec("VOICE ACTIONS")
        Group {
            Item("🎙️", "Enroll My Voice", "Capture 3 samples to verify your identity") {
                enrollingForOwner = true
                targetSpeakerName = vm.s("name") + " (Owner)"
                vm.enrollmentSamples.clear()
                vm.enrollmentStep = 0
                vm.startEnrollmentSample { ok, msg ->
                    if (ok && vm.enrollmentSamples.size >= 3) {
                        vm.completeEnrollment(targetSpeakerName, true)
                    }
                }
            }
            Item("👥", "Add Another Authorized Speaker", "Allow family member or friend to command Juliet") {
                newSpeakerName = ""
                addSpeakerDlg = true
            }
            Item("🔍", "Test Voice Recognition", "Speak now to test recognition & confidence score") {
                vm.testVoiceRecognition()
            }
        }

        // In-progress multi-sample enrollment indicator
        if (vm.enrollmentSamples.isNotEmpty() && !vm.isEnrollingVoice) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = p.card),
                modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text(
                        text = "Enrollment Progress: ${vm.enrollmentSamples.size} of 3 samples captured",
                        color = p.text,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (vm.enrollmentSamples.size < 3) {
                            Button(
                                onClick = {
                                    vm.startEnrollmentSample { ok, _ ->
                                        if (ok && vm.enrollmentSamples.size >= 3) {
                                            vm.completeEnrollment(targetSpeakerName, enrollingForOwner)
                                        }
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = J.Red)
                            ) {
                                Text("Record Sample ${vm.enrollmentSamples.size + 1}")
                            }
                        } else {
                            Button(
                                onClick = { vm.completeEnrollment(targetSpeakerName, enrollingForOwner) },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = J.Ok)
                            ) {
                                Text("Save Voice Profile ✔")
                            }
                        }
                        OutlinedButton(onClick = { vm.cancelEnrollment() }) {
                            Text("Reset")
                        }
                    }
                }
            }
        }

        // Authorized Speakers List
        Sec("AUTHORIZED SPEAKERS (${vm.voiceProfiles.size})")
        Group {
            if (vm.voiceProfiles.isEmpty()) {
                Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                    Text("No voice profiles saved yet.", color = p.mu, fontSize = 14.sp)
                }
            } else {
                vm.voiceProfiles.forEach { profile ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(38.dp).clip(CircleShape)
                                .background(if (profile.isOwner) J.Gold.copy(alpha = 0.2f) else p.card2),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (profile.isOwner) Icons.Rounded.Star else Icons.Rounded.Person,
                                contentDescription = null,
                                tint = if (profile.isOwner) J.Gold else p.text,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(profile.name, color = p.text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                                if (profile.isOwner) {
                                    Spacer(Modifier.width(6.dp))
                                    Text("OWNER", color = J.Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Text("${profile.sampleCount} acoustic samples • Phrase: \"${profile.phrase}\"", color = p.mu, fontSize = 12.sp)
                        }
                        IconButton(onClick = {
                            renameDlg = profile
                            renameText = profile.name
                        }) {
                            Icon(Icons.Rounded.Edit, contentDescription = "Rename", tint = p.mu, modifier = Modifier.size(18.dp))
                        }
                        IconButton(onClick = { vm.deleteVoiceProfile(profile.id) }) {
                            Icon(Icons.Rounded.Delete, contentDescription = "Delete", tint = J.Red.copy(alpha = 0.8f), modifier = Modifier.size(18.dp))
                        }
                    }
                    HorizontalDivider(color = p.border, thickness = 0.5.dp)
                }
            }
        }

        // Wake Word & Confidence Settings
        Sec("WAKE WORD & ACCURACY")
        Group {
            Item("✦", "Wake Word", "\"Juliet\"", trailing = {})
            Item("🌙", "Always Listen (Background)", if (vm.s("background_listen") == "1") "On: works with app closed & screen locked" else "Off") {
                vm.setBackgroundListen(vm.s("background_listen") != "1")
            }
            Item("🚨", "Lock Phone After Unknown Voice", "${vm.s("voice_lock_strikes")} attempts") {
                vm.cycle("voice_lock_strikes", listOf("2", "3", "4"))
            }
            Item("🎚️", "Wake Word Sensitivity", vm.s("wake_word_sensitivity")) {
                vm.cycle("wake_word_sensitivity", listOf("Low", "Normal", "High"))
            }
            Item("🎯", "Voice Match Threshold", "${vm.s("voice_verification_threshold")}%") {
                vm.cycle("voice_verification_threshold", listOf("60", "70", "80", "85"))
            }
        }
    }

    // Add Speaker Dialog
    if (addSpeakerDlg) {
        AlertDialog(
            onDismissRequest = { addSpeakerDlg = false },
            title = { Text("Add Authorized Speaker") },
            text = {
                Column {
                    Text("Enter speaker's name or relationship (e.g. Brother, Colleague, Ali):", fontSize = 13.sp, color = p.mu)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = newSpeakerName,
                        onValueChange = { newSpeakerName = it },
                        placeholder = { Text("Speaker Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("speaker_name_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val name = newSpeakerName.trim().ifBlank { "Authorized Speaker" }
                        addSpeakerDlg = false
                        enrollingForOwner = false
                        targetSpeakerName = name
                        vm.enrollmentSamples.clear()
                        vm.enrollmentStep = 0
                        vm.startEnrollmentSample { ok, _ ->
                            if (ok && vm.enrollmentSamples.size >= 3) {
                                vm.completeEnrollment(targetSpeakerName, false)
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = J.Red)
                ) {
                    Text("Start Recording")
                }
            },
            dismissButton = {
                TextButton(onClick = { addSpeakerDlg = false }) {
                    Text("Cancel", color = p.mu)
                }
            }
        )
    }

    // Rename Dialog
    renameDlg?.let { profile ->
        AlertDialog(
            onDismissRequest = { renameDlg = null },
            title = { Text("Rename Speaker") },
            text = {
                OutlinedTextField(
                    value = renameText,
                    onValueChange = { renameText = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (renameText.isNotBlank()) vm.renameVoiceProfile(profile.id, renameText)
                        renameDlg = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = J.Gold)
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { renameDlg = null }) { Text("Cancel", color = p.mu) }
            }
        )
    }
}
