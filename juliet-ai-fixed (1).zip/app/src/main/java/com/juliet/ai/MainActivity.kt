package com.juliet.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.juliet.ai.ui.JulietApp
import com.juliet.ai.vm.JulietViewModel

class MainActivity : ComponentActivity() {
    private val vm: JulietViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { JulietApp(vm) }
    }
}


