package com.juliet.ai.ui

import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily

// =========================================================================
// iOS DESIGN SYSTEM THEME TOKENS
// =========================================================================
// Font Note: To use genuine Inter or SF Pro .ttf fonts locally:
// Place inter_regular.ttf and inter_bold.ttf into res/font/
// and replace FontFamily.Default below with:
// FontFamily(androidx.compose.ui.text.font.Font(R.font.inter_regular), ...)
val IOSFont = FontFamily.Default

object J {
    val Pink = Color(0xFFFF2D8A)
    val Purple = Color(0xFF7B2FF7)
    val Red = Pink
    val Crim = Purple
    val Dark = Color(0xFF1E182D)
    val Ok = Color(0xFF34C759)
    val Gold = Color(0xFFFF9500)
    val Blue = Color(0xFF007AFF)
    val Tile = Brush.linearGradient(listOf(Pink, Purple))
}

data class Pal(
    val bg: Color,
    val card: Color,
    val card2: Color,
    val border: Color,
    val text: Color,
    val mu: Color,
    val nav: Color,
    val hairline: Color
)

val DarkPal = Pal(
    bg = Color(0xFF05030A),
    card = Color(0xFF14101F),
    card2 = Color(0xFF1E182D),
    border = Color(0x1FFFFFFF), // Hairline divider
    text = Color(0xFFFFFFFF),
    mu = Color(0xFF8E8E93),     // iOS Secondary Label
    nav = Color(0xCC05030A),    // Frosted Tab Bar
    hairline = Color(0x14FFFFFF)
)

val LightPal = Pal(
    bg = Color(0xFFF2F2F7),
    card = Color(0xFFFFFFFF),
    card2 = Color(0xFFE5E5EA),
    border = Color(0x1F000000),
    text = Color(0xFF000000),
    mu = Color(0xFF8E8E93),
    nav = Color(0xCCF2F2F7),
    hairline = Color(0x14000000)
)

val LocalPal = staticCompositionLocalOf { DarkPal }

@Composable
fun JulietTheme(dark: Boolean, content: @Composable () -> Unit) {
    val p = if (dark) DarkPal else LightPal
    val cs = if (dark) {
        darkColorScheme(
            primary = J.Pink,
            secondary = J.Purple,
            background = p.bg,
            surface = p.card,
            onBackground = p.text,
            onSurface = p.text
        )
    } else {
        lightColorScheme(
            primary = J.Pink,
            secondary = J.Purple,
            background = p.bg,
            surface = p.card,
            onBackground = p.text,
            onSurface = p.text
        )
    }

    IOSAppTheme(themePreference = if (dark) "Dark" else "Light") {
        CompositionLocalProvider(
            LocalPal provides p
        ) {
            MaterialTheme(colorScheme = cs, content = content)
        }
    }
}
