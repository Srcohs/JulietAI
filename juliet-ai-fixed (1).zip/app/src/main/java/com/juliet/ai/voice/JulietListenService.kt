package com.juliet.ai.voice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.juliet.ai.BuildConfig
import com.juliet.ai.MainActivity
import com.juliet.ai.data.Knowledge
import com.juliet.ai.data.Prefs
import com.juliet.ai.data.VoiceState
import com.juliet.ai.phone.PhoneActions
import com.juliet.ai.screen.PhoneLocker
import com.juliet.ai.vm.DEFAULTS
import com.juliet.ai.vm.Persona
import com.juliet.ai.vm.VOICE_MODELS
import kotlinx.coroutines.*

/**
 * "Always on" Juliet. A microphone foreground service keeps the voice session alive when the
 * app is closed or the screen is locked. If Voice Lock is on, the on-device [SpeakerGate]
 * ensures ONLY the enrolled voice is ever sent to Gemini; strangers are blocked and after
 * N strikes the phone is locked.
 */
class JulietListenService : Service() {

    companion object {
        const val ACTION_STOP = "com.juliet.ai.voice.STOP"
        private const val CH = "juliet_listen"
        private const val NID = 4711
        @Volatile var running = false; private set

        fun start(ctx: Context) {
            val i = Intent(ctx, JulietListenService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, JulietListenService::class.java)) }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())
    private var wake: PowerManager.WakeLock? = null
    private var prefs: Prefs? = null
    private var live: GeminiLive? = null
    private var gate: SpeakerGate? = null
    private var backoff = 3000L
    private var stopping = false
    private var status = "Listening…"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { prefs?.put("background_listen", "0"); stopSelf(); return START_NOT_STICKY }
        if (running) return START_STICKY
        running = true; stopping = false

        createChannel()
        val n = notification(status)
        if (Build.VERSION.SDK_INT >= 29) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(NID, n)

        wake = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "juliet:listen").apply { setReferenceCounted(false); acquire() }

        val p = Prefs(this).also { prefs = it; it.put("background_listen", "1") }
        val phone = PhoneActions(this, p, Knowledge(p))
        val mgr = VoiceEnrollmentManager(this, p)
        val g = SpeakerGate(mgr, p).also { gate = it }
        g.onAccept = { name, conf -> update("Hello $name (${(conf * 100).toInt()}%)") }
        g.onReject = { n1, max, why -> update("Unknown voice blocked $n1/$max"); android.util.Log.i("JulietGate", why) }
        g.onLockout = {
            val ok = PhoneLocker.lockNow(this)
            update(if (ok) "Phone locked: unknown speaker" else "Unknown speaker! Enable Accessibility to allow locking")
        }
        val l = GeminiLive(phone).also { live = it }
        l.gate = g
        scope.launch { l.error.collect { if (it != null) update(it) } }
        scope.launch {
            l.state.collect { st ->
                if (st == VoiceState.Idle && !stopping) scheduleReconnect()
                if (st == VoiceState.Listening) { backoff = 3000L; if (!g.isActive()) update("Listening…") }
            }
        }
        connect()
        return START_STICKY
    }

    private fun connect() {
        val p = prefs ?: return
        val l = live ?: return
        val key = p.get("k_gemini").ifBlank { BuildConfig.DEFAULT_GEMINI_KEY }
        if (key.isBlank()) { update("Add a Gemini key in Settings"); return }
        val get = { k: String -> p.get(k, DEFAULTS[k] ?: "") }
        val models = (listOf(get("model")) + VOICE_MODELS).distinct()
        l.start(key, models, get("voice"), Persona.system(get),
            (get("volume").toFloatOrNull() ?: 80f) / 100f, "")   // no greeting on background reconnects
    }

    private fun scheduleReconnect() {
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ if (!stopping) connect() }, backoff)
        backoff = (backoff * 2).coerceAtMost(30_000L)
    }

    private fun update(text: String) {
        status = text
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NID, notification(text))
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CH, "Juliet always listening", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun notification(text: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val stop = PendingIntent.getService(this, 1,
            Intent(this, JulietListenService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Juliet is active")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .build()
    }

    override fun onDestroy() {
        stopping = true; running = false
        handler.removeCallbacksAndMessages(null)
        try { live?.stop() } catch (_: Exception) {}
        scope.cancel()
        try { wake?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}
