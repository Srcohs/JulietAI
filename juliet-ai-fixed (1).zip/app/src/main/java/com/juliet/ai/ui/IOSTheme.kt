package com.juliet.ai.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Native iOS (Apple HIG) Design Tokens for Juliet AI.
 * Specifications:
 * - Dark Theme: Background #05030A, Grouped Card #14101F, Card Secondary #1E182D
 * - Light Theme: Background #F2F2F7, Grouped Card #FFFFFF, Card Secondary #E5E5EA
 * - Accent Gradient: #FF2D8A -> #7B2FF7 (Pink to Purple)
 * - Typography: SF Pro / Inter equivalent scale (Large Title 34sp bold, Body 17sp, etc.)
 */
object IOSColors {
    // ---- Primary Brand Gradient ----
    val Pink = Color(0xFFFF2D8A)
    val Purple = Color(0xFF7B2FF7)
    val AccentGradient = Brush.linearGradient(listOf(Pink, Purple))
    val AccentGradientHorizontal = Brush.horizontalGradient(listOf(Pink, Purple))

    // ---- System Colors (Apple HIG Palette) ----
    val Blue = Color(0xFF007AFF)
    val Green = Color(0xFF34C759)
    val Indigo = Color(0xFF5856D6)
    val Orange = Color(0xFFFF9500)
    val Red = Color(0xFFFF3B30)
    val Teal = Color(0xFF5AC8FA)
    val Yellow = Color(0xFFFFCC00)

    // ---- Dark Theme Palette ----
    val DarkBackground = Color(0xFF05030A)
    val DarkCard = Color(0xFF14101F)
    val DarkCardSecondary = Color(0xFF1E182D)
    val DarkCardTertiary = Color(0xFF2A223E)
    val DarkSeparator = Color(0xFF2E2544)
    val DarkHairline = Color(0x1FFFFFFF) // 12% white for ultra-fine borders
    val DarkText = Color(0xFFFFFFFF)
    val DarkTextSecondary = Color(0xFF8E8E93)
    val DarkTextTertiary = Color(0xFF636366)
    val DarkFill = Color(0x33787880)

    // ---- Light Theme Palette ----
    val LightBackground = Color(0xFFF2F2F7)
    val LightCard = Color(0xFFFFFFFF)
    val LightCardSecondary = Color(0xFFE5E5EA)
    val LightCardTertiary = Color(0xFFD1D1D6)
    val LightSeparator = Color(0xFFC6C6C8)
    val LightHairline = Color(0x1F000000) // 12% black for hairline borders
    val LightText = Color(0xFF000000)
    val LightTextSecondary = Color(0xFF8E8E93)
    val LightTextTertiary = Color(0xFFAEAEB2)
    val LightFill = Color(0x1F787880)

    // Frosted Glass Overlays
    val DarkFrostedBar = Color(0xCC05030A)
    val LightFrostedBar = Color(0xCCF2F2F7)
    val DarkSheetBackground = Color(0xF014101F)
    val LightSheetBackground = Color(0xF0FFFFFF)
}

@Immutable
data class IOSTypography(
    val largeTitle: TextStyle = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Bold,
        fontSize = 34.sp,
        lineHeight = 41.sp,
        letterSpacing = 0.37.sp
    ),
    val title1: TextStyle = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Bold,
        fontSize = 28.sp,
        lineHeight = 34.sp,
        letterSpacing = 0.36.sp
    ),
    val title2: TextStyle = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp,
        lineHeight = 28.sp,
        letterSpacing = 0.35.sp
    ),
    val title3: TextStyle = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.SemiBold,
        fontSize = 20.sp,
        lineHeight = 25.sp,
        letterSpacing = 0.38.sp
    ),
    val headline: TextStyle = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.SemiBold,
        fontSize = 17.sp,
        lineHeight = 22.sp,
        letterSpacing = (-0.41).sp
    ),
    val body: TextStyle = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 17.sp,
        lineHeight = 22.sp,
        letterSpacing = (-0.41).sp
    ),
    val callout: TextStyle = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 21.sp,
        letterSpacing = (-0.32).sp
    ),
    val subheadline: TextStyle = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 20.sp,
        letterSpacing = (-0.24).sp
    ),
    val footnote: TextStyle = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 18.sp,
        letterSpacing = (-0.08).sp
    ),
    val caption1: TextStyle = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.sp
    ),
    val caption2: TextStyle = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 11.sp,
        lineHeight = 13.sp,
        letterSpacing = 0.07.sp
    )
)

val LocalIOSTypography = staticCompositionLocalOf { IOSTypography() }

@Immutable
data class IOSColorScheme(
    val isDark: Boolean,
    val background: Color,
    val card: Color,
    val cardSecondary: Color,
    val cardTertiary: Color,
    val separator: Color,
    val hairline: Color,
    val text: Color,
    val textSecondary: Color,
    val textTertiary: Color,
    val frostedBar: Color,
    val sheetBackground: Color,
    val accentPink: Color = IOSColors.Pink,
    val accentPurple: Color = IOSColors.Purple,
    val accentGradient: Brush = IOSColors.AccentGradient,
    val systemBlue: Color = IOSColors.Blue,
    val systemGreen: Color = IOSColors.Green,
    val systemRed: Color = IOSColors.Red,
    val systemOrange: Color = IOSColors.Orange
)

val DarkIOSColorScheme = IOSColorScheme(
    isDark = true,
    background = IOSColors.DarkBackground,
    card = IOSColors.DarkCard,
    cardSecondary = IOSColors.DarkCardSecondary,
    cardTertiary = IOSColors.DarkCardTertiary,
    separator = IOSColors.DarkSeparator,
    hairline = IOSColors.DarkHairline,
    text = IOSColors.DarkText,
    textSecondary = IOSColors.DarkTextSecondary,
    textTertiary = IOSColors.DarkTextTertiary,
    frostedBar = IOSColors.DarkFrostedBar,
    sheetBackground = IOSColors.DarkSheetBackground
)

val LightIOSColorScheme = IOSColorScheme(
    isDark = false,
    background = IOSColors.LightBackground,
    card = IOSColors.LightCard,
    cardSecondary = IOSColors.LightCardSecondary,
    cardTertiary = IOSColors.LightCardTertiary,
    separator = IOSColors.LightSeparator,
    hairline = IOSColors.LightHairline,
    text = IOSColors.LightText,
    textSecondary = IOSColors.LightTextSecondary,
    textTertiary = IOSColors.LightTextTertiary,
    frostedBar = IOSColors.LightFrostedBar,
    sheetBackground = IOSColors.LightSheetBackground
)

val LocalIOSColorScheme = staticCompositionLocalOf { DarkIOSColorScheme }

/**
 * Accessor for current iOS Theme properties in Composables.
 */
object IOSTheme {
    val colors: IOSColorScheme
        @Composable
        get() = LocalIOSColorScheme.current

    val typography: IOSTypography
        @Composable
        get() = LocalIOSTypography.current
}

/**
 * Top-level theme wrapper applying iOS styling, color schemes, and typography.
 */
@Composable
fun IOSAppTheme(
    themePreference: String = "Auto", // "Auto", "Dark", "Light"
    content: @Composable () -> Unit
) {
    val systemDark = isSystemInDarkTheme()
    val isDark = when (themePreference.lowercase()) {
        "dark" -> true
        "light" -> false
        else -> systemDark
    }
    val colors = if (isDark) DarkIOSColorScheme else LightIOSColorScheme
    val typography = IOSTypography()

    CompositionLocalProvider(
        LocalIOSColorScheme provides colors,
        LocalIOSTypography provides typography
    ) {
        content()
    }
}
