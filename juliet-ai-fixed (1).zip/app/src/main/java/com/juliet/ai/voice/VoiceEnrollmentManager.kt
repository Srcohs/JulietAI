package com.juliet.ai.voice

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import com.juliet.ai.data.Prefs
import com.juliet.ai.data.SpeakerVerificationResult
import com.juliet.ai.data.VoiceProfile
import kotlinx.coroutines.*
import kotlin.math.sqrt

/**
 * Microphone with the SAME processing chain (VOICE_COMMUNICATION + AEC + NS) everywhere.
 * Enrollment and live verification must hear the voice identically, otherwise the
 * spectrum differs and even the owner is rejected.
 */
class ProcessedMic @SuppressLint("MissingPermission") constructor(bufferBytes: Int) {
    val record: AudioRecord = AudioRecord(
        MediaRecorder.AudioSource.VOICE_COMMUNICATION, SpeakerDsp.SR,
        AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferBytes
    )
    private var aec: AcousticEchoCanceler? = null
    private var ns: NoiseSuppressor? = null

    val ok: Boolean get() = record.state == AudioRecord.STATE_INITIALIZED

    init {
        if (ok) {
            if (AcousticEchoCanceler.isAvailable()) {
                try { aec = AcousticEchoCanceler.create(record.audioSessionId)?.apply { enabled = true } } catch (_: Exception) {}
            }
            if (NoiseSuppressor.isAvailable()) {
                try { ns = NoiseSuppressor.create(record.audioSessionId)?.apply { enabled = true } } catch (_: Exception) {}
            }
        }
    }

    fun release() {
        try { aec?.release() } catch (_: Exception) {}
        try { ns?.release() } catch (_: Exception) {}
        try { record.stop() } catch (_: Exception) {}
        try { record.release() } catch (_: Exception) {}
    }
}

/**
 * On-device Voice Enrollment & Speaker Verification.
 * Real MFCC + pitch voice prints (see [SpeakerDsp]); no cloud, nothing leaves the phone.
 */
class VoiceEnrollmentManager(
    private val ctx: Context,
    private val prefs: Prefs
) {
    companion object {
        const val SAMPLE_RATE = SpeakerDsp.SR
        const val EMBEDDING_DIM = SpeakerDsp.DIM
        const val MIN_SPEECH_SECONDS = 0.9f
    }

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var recordingJob: Job? = null
    private var mic: ProcessedMic? = null

    @Volatile
    var isRecording: Boolean = false
        private set

    /** Kept for API compatibility: embedding as a list (zeros if too little speech). */
    fun extractEmbedding(pcm: ShortArray): List<Float> =
        (SpeakerDsp.embed(pcm) ?: FloatArray(EMBEDDING_DIM)).toList()

    fun cosineSimilarity(v1: List<Float>, v2: List<Float>): Float {
        if (v1.size != v2.size || v1.isEmpty()) return 0f
        var dot = 0f; var a = 0f; var b = 0f
        for (i in v1.indices) { dot += v1[i] * v2[i]; a += v1[i] * v1[i]; b += v2[i] * v2[i] }
        val d = sqrt(a.toDouble()) * sqrt(b.toDouble())
        return if (d > 1e-6) (dot / d).toFloat() else 0f
    }

    /**
     * Records [durationMillis] of audio, reports live level, then returns the voice print
     * (only if there was enough real speech).
     */
    @SuppressLint("MissingPermission")
    fun recordSample(
        durationMillis: Long = 4000L,
        onLevelUpdate: (Float) -> Unit,
        onResult: (List<Float>?, String) -> Unit
    ) {
        if (isRecording) { onResult(null, "Already recording a voice sample"); return }

        val minBuf = AudioRecord.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val bufSize = (minBuf * 2).coerceAtLeast(SAMPLE_RATE * 2)
        val m = try { ProcessedMic(bufSize) } catch (e: Exception) {
            onResult(null, "Recording error: ${e.message}"); return
        }
        if (!m.ok) { m.release(); onResult(null, "Microphone could not be initialized"); return }
        mic = m
        isRecording = true
        try { m.record.startRecording() } catch (e: Exception) {
            stopRecordingInternal(); onResult(null, "Recording error: ${e.message}"); return
        }

        recordingJob = scope.launch {
            val total = (SAMPLE_RATE * (durationMillis / 1000.0)).toInt()
            val captured = ShortArray(total)
            val chunk = ShortArray(1024)
            var count = 0
            val start = System.currentTimeMillis()
            while (isActive && count < total && System.currentTimeMillis() - start < durationMillis + 1500) {
                val read = m.record.read(chunk, 0, minOf(chunk.size, total - count))
                if (read > 0) {
                    System.arraycopy(chunk, 0, captured, count, read)
                    count += read
                    var sum = 0.0
                    for (i in 0 until read) { val s = chunk[i].toDouble(); sum += s * s }
                    val lvl = (sqrt(sum / read).toFloat() / 32768f * 6f).coerceIn(0f, 1f)
                    withContext(Dispatchers.Main) { onLevelUpdate(lvl) }
                } else delay(10)
            }
            releaseMic()   // NOT stopRecordingInternal(): that would cancel this very coroutine

            if (count < total * 0.6) {
                withContext(Dispatchers.Main) { onResult(null, "Recording too short. Please try again.") }
                return@launch
            }
            val pcm = captured.copyOf(count)
            val speech = SpeakerDsp.speechSeconds(pcm)
            if (speech < MIN_SPEECH_SECONDS) {
                withContext(Dispatchers.Main) {
                    onResult(null, "Not enough speech detected (${"%.1f".format(speech)}s). Speak a full sentence, closer to the mic.")
                }
                return@launch
            }
            val emb = SpeakerDsp.embed(pcm)
            withContext(Dispatchers.Main) {
                if (emb == null) onResult(null, "Could not analyse voice. Speak louder and try again.")
                else onResult(emb.toList(), "Voice sample captured (${"%.1f".format(speech)}s of speech).")
            }
        }
    }

    /** Minimum confidence (0..1) required, from the user's "Voice Match Threshold" setting. */
    fun requiredConfidence(): Float = ((prefs.get("voice_verification_threshold", "70").toFloatOrNull() ?: 70f) / 100f)

    fun verifySpeaker(sample: List<Float>): SpeakerVerificationResult =
        verifyEmbedding(sample.toFloatArray(), prefs.loadVoiceProfiles())

    fun verifyEmbedding(e: FloatArray, profiles: List<VoiceProfile>): SpeakerVerificationResult {
        if (profiles.isEmpty()) {
            return SpeakerVerificationResult(null, 0f, false, "No enrolled voice profiles found. Please enroll your voice first.")
        }
        var best: VoiceProfile? = null
        var bestD = Float.MAX_VALUE
        for (p in profiles) {
            val d = SpeakerDsp.distance(e, p.features, p.spread)
            if (d < bestD) { bestD = d; best = p }
        }
        val conf = if (bestD == Float.MAX_VALUE) 0f else SpeakerDsp.confidence(bestD)
        val need = requiredConfidence()
        val ok = best != null && conf >= need
        val msg = when {
            ok -> "Speaker identified: ${best!!.name} (${(conf * 100).toInt()}% match)"
            best != null -> "Not recognised. Closest: ${best.name} at ${(conf * 100).toInt()}% (needs ${(need * 100).toInt()}%)"
            else -> "Could not identify speaker."
        }
        return SpeakerVerificationResult(if (ok) best else null, conf, ok, msg)
    }

    fun cancelRecording() { stopRecordingInternal() }

    private fun releaseMic() {
        isRecording = false
        mic?.release(); mic = null
    }

    private fun stopRecordingInternal() {
        recordingJob?.cancel(); recordingJob = null
        releaseMic()
    }

    fun release() { cancelRecording(); scope.cancel() }
}
