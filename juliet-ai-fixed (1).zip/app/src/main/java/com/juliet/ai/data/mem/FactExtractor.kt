package com.juliet.ai.data.mem

/**
 * Fast offline extractor: finds facts in what the user says (English, Roman Urdu).
 * Stage 3 adds an optional LLM pass for harder sentences; this one costs zero tokens.
 */
object FactExtractor {

    data class Candidate(
        val category: String,
        val slot: String,
        val value: String,
        val importance: Float = 0.5f,
        val multi: Boolean = true,        // false = only one value allowed (name, birthday...) -> conflicts are asked
        val sensitive: Boolean = false,   // health etc. -> always ask before saving
        val explicit: Boolean = false,    // user said "yaad rakho" -> save directly
        val source: String = "auto"
    )

    private val I = RegexOption.IGNORE_CASE
    private const val REL = "bhai|brother|behan|behen|sister|ammi|mummy|mom|mother|maa|abbu|papa|dad|father|biwi|wife|shohar|husband|beta|son|beti|daughter|dost|friend"

    private val NAME_A = Regex("""(?:mera\s+(?:naam|name)|my\s+name\s+is|call\s+me)\s+([\p{L}]{2,20}(?:\s[\p{L}]{2,20})?)""", I)
    private val NAME_B = Regex("""mujhe\s+([\p{L}]{2,20})\s+(?:bulao|kaho|bola\s+karo|bulaya\s+karo)""", I)
    private val NAME_STOP = setOf("kya", "yaad", "hai", "bata", "batao", "what", "is", "kon", "kaun")

    private val DISLIKE = listOf(
        Regex("""mujhe\s+(.{2,50}?)\s+(?:pasand\s+nahi|nahi\s+pasand|bura\s+lagta|buri\s+lagti)""", I),
        Regex("""\bi\s+(?:really\s+)?(?:hate|dislike|can'?t\s+stand)\s+(.{2,50})""", I)
    )
    private val LIKE = listOf(
        Regex("""mujhe\s+(.{2,50}?)\s+(?:bohat\s+|bahut\s+|boht\s+)?(?:pasand\s+(?:hai|hain|he)|acha\s+lagta|achi\s+lagti|achay\s+lagte)""", I),
        Regex("""\bi\s+(?:really\s+|absolutely\s+)?(?:like|love|enjoy|prefer)\s+(.{2,50})""", I)
    )
    private val FAM_A = Regex("""(?:mera|meri|my)\s+($REL)(?:'s)?\s+(?:ka\s+naam|ki\s+naam|ka\s+name|name\s+is|is\s+called|is\s+named)\s+([\p{L}]{2,20})""", I)
    private val FAM_B = Regex("""(?:mera|meri)\s+($REL)\s+([\p{L}]{2,20})\s+(?:hai|hay|he)\b""", I)
    private val FAM_STOP = setOf("kahan", "kaun", "kya", "bohat", "bahut", "theek", "bimar", "acha", "achi", "bura", "busy", "ghar", "aaya", "aayi")

    private val BDAY = listOf(
        Regex("""meri\s+(?:birthday|salgirah|sal\s*girah)\s+(.{3,25}?)\s+(?:ko\s+)?(?:hai|hoti\s+hai)""", I),
        Regex("""my\s+birthday\s+is\s+(?:on\s+)?(.{3,25})""", I)
    )
    private val LOC = listOf(
        Regex("""\bmain\s+(.{2,30}?)\s+(?:mein|me)\s+reh(?:ta|ti)\s+(?:hun|hoon|hu)""", I),
        Regex("""\bi\s+live\s+in\s+(.{2,30})""", I),
        Regex("""\bi(?:'m|\s+am)\s+from\s+(.{2,30})""", I)
    )
    private val WORK = listOf(
        Regex("""\bi\s+work\s+(?:at|for|as(?:\s+an?)?|in)\s+(.{2,40})""", I),
        Regex("""\bmain\s+(.{2,30}?)\s+(?:mein|me)\s+kaam\s+kar(?:ta|ti)\s+(?:hun|hoon|hu)""", I),
        Regex("""\bi(?:'m|\s+am)\s+an?\s+(student|engineer|doctor|teacher|developer|designer|lawyer|nurse|accountant|businessman)""", I),
        Regex("""\bmain\s+(student|engineer|doctor|teacher|developer|designer)\s+(?:hun|hoon|hu)""", I)
    )
    private val GOAL = listOf(
        Regex("""mera\s+(?:goal|maqsad|khwab)\s+(.{3,60}?)\s+(?:hai|he)""", I),
        Regex("""\bi\s+(?:want|plan|hope)\s+to\s+(.{3,60})""", I),
        Regex("""\bmain\s+(.{3,50}?)\s+chah(?:ta|ti)\s+(?:hun|hoon|hu)""", I)
    )
    private val GOAL_STOP = Regex("""^(know|ask|see|check|find|call|send|open|play|say|tell|listen|watch)\b""", I)

    private val HEALTH = listOf(
        Regex("""mujhe\s+(diabetes|sugar|bp|blood\s+pressure|asthma|allergy|migraine|depression|anxiety)\b""", I),
        Regex("""\bi\s+(?:have|suffer\s+from)\s+(diabetes|asthma|allergy|migraine|depression|anxiety|high\s+blood\s+pressure)""", I)
    )
    private val ROUTINE = listOf(
        Regex("""\b(?:main\s+)?(?:roz|rozana|har\s+din)\s+(.{3,50}?)(?:\s+(?:hun|hoon|hu|hai|karta|karti))?$""", I),
        Regex("""\bi\s+(?:usually|always|normally)\s+(.{3,50})""", I),
        Regex("""\bmain\s+aksar\s+(.{3,50})""", I),
        Regex("""\bevery\s+(?:day|morning|night|evening)\s+i\s+(.{3,50})""", I)
    )
    private val STYLE = Regex("""(?:mujhe\s+)?(short|chhote|chote|detailed|lambe|tafseeli)\s+(?:jawab|jawabat|answers?|replies)\s*(?:chahiye|pasand|please)?""", I)
    private val EXPLICIT = Regex("""(?:yaad\s+rakh(?:o|na|iye)?|remember\s+(?:that|this)?)\s*(?:ke|k|that)?\s+(.{4,160})""", I)
    private val FORGET = Regex("""(?:bhool\s+jao|bhul\s+jao|forget(?:\s+that)?|delete\s+memory(?:\s+of)?)\s+(.{3,80})""", I)

    private val SENTENCE = Regex("""(?<=[.!?\n])\s*""")

    private val canon = mapOf(
        "brother" to "bhai", "sister" to "behan", "behen" to "behan", "mummy" to "ammi", "mom" to "ammi",
        "mother" to "ammi", "maa" to "ammi", "papa" to "abbu", "dad" to "abbu", "father" to "abbu",
        "wife" to "biwi", "husband" to "shohar", "son" to "beta", "daughter" to "beti", "friend" to "dost"
    )

    fun extract(text: String): List<Candidate> {
        val out = mutableListOf<Candidate>()
        for (raw in text.split(SENTENCE)) {
            val s = raw.trim()
            if (s.length < 6 || s.endsWith("?")) continue

            // explicit "yaad rakho ..." -> saved as a note
            EXPLICIT.find(s)?.let {
                val v = clean(it.groupValues[1])
                if (v.length >= 4) out += Candidate("Notes", "note:" + v.lowercase().take(40), v, 0.9f, explicit = true, source = "user")
            }
            (NAME_A.find(s) ?: NAME_B.find(s))?.let {
                val v = clean(it.groupValues[1]).split(" ").joinToString(" ") { w -> w.replaceFirstChar { c -> c.uppercase() } }
                if (v.lowercase() !in NAME_STOP) out += Candidate("Personal", "name", v, 0.95f, multi = false)
            }
            FAM_A.find(s)?.let { addFamily(out, it.groupValues[1], it.groupValues[2]) }
                ?: FAM_B.find(s)?.let { if (it.groupValues[2].lowercase() !in FAM_STOP) addFamily(out, it.groupValues[1], it.groupValues[2]) }

            first(BDAY, s)?.let { out += Candidate("Personal", "birthday", clean(it), 0.85f, multi = false) }
            first(LOC, s)?.let { out += Candidate("Personal", "location", cap(clean(it)), 0.7f, multi = false) }
            first(WORK, s)?.let { out += Candidate("Work", "work", clean(it), 0.7f, multi = false) }

            val dis = first(DISLIKE, s)
            if (dis != null) out += Candidate("Dislikes", "dislike:" + clean(dis).lowercase().take(30), clean(dis), 0.5f)
            else first(LIKE, s)?.let { out += Candidate("Likes", "like:" + clean(it).lowercase().take(30), clean(it), 0.5f) }

            first(GOAL, s)?.let {
                val v = clean(it)
                if (!GOAL_STOP.containsMatchIn(v)) out += Candidate("Goals", "goal:" + v.lowercase().take(30), v, 0.7f)
            }
            first(ROUTINE, s)?.let {
                val v = clean(it)
                if (v.length >= 4 && !GOAL_STOP.containsMatchIn(v)) out += Candidate("Routine", "routine:" + v.lowercase().take(30), v, 0.6f)
            }
            STYLE.find(s)?.let {
                val k = it.groupValues[1].lowercase()
                val short = k in setOf("short", "chhote", "chote")
                out += Candidate("Routine", "pref:reply_length", if (short) "Prefers short replies" else "Prefers detailed replies", 0.8f, multi = false)
            }
            first(HEALTH, s)?.let {
                val v = clean(it)
                out += Candidate("Health", "health:" + v.lowercase(), v, 0.8f, sensitive = true)
            }
        }
        return out.distinctBy { it.category + "|" + it.slot }
    }

    /** "bhool jao ..." -> what to forget (caller finds + confirms matching memories). */
    fun detectForget(text: String): String? = FORGET.find(text.trim())?.let { clean(it.groupValues[1]) }

    private fun addFamily(out: MutableList<Candidate>, rel: String, name: String) {
        val r = canon[rel.lowercase()] ?: rel.lowercase()
        val n = cap(name)
        out += Candidate("Family", "family:$r:${n.lowercase()}", n, 0.75f)
    }

    private fun first(rs: List<Regex>, s: String): String? {
        for (r in rs) { val m = r.find(s) ?: continue; val g = m.groupValues.drop(1).firstOrNull { it.isNotBlank() }; if (g != null) return g }
        return null
    }

    private fun cap(s: String) = s.split(" ").joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }

    private fun clean(v: String): String {
        var s = v.trim()
        s = s.split(Regex("""\s+(?:but|because|lekin|magar|kyun|kyunke|and then|aur phir)\s+""", I))[0]
        s = s.replace(Regex("""\s+(?:hai|hain|he|hoon|hun|hu)$""", I), "")
        return s.trim(' ', '.', ',', '!', '"', '\'').take(80)
    }
}
