package com.juliet.ai.data.mem

import android.content.Context
import androidx.room.*
import com.juliet.ai.data.secure.KeyVault
import kotlinx.coroutines.flow.Flow
import net.zetetic.database.sqlcipher.SupportOpenHelperFactory
import java.io.File

/* ───────────── Tables ───────────── */

/** Semantic + procedural memory: one row = one thing Juliet knows. */
@Entity(tableName = "facts", indices = [Index(value = ["category", "slot"])])
data class FactEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val layer: String = "semantic",        // semantic | procedural
    val category: String,                  // Personal, Family, Likes, Dislikes, Goals, Work, Health, Notes, Routine
    val slot: String,                      // normalized key, e.g. "name", "family:bhai:ali", "like:chai"
    val value: String,
    val importance: Float = 0.5f,          // 0..1
    val pinned: Boolean = false,
    val source: String = "auto",           // auto | user | llm
    val createdAt: Long,
    val updatedAt: Long,
    val lastUsedAt: Long = 0,
    val useCount: Int = 0,
    val embedding: ByteArray? = null
)

/** Episodic memory: a short summary of one conversation. */
@Entity(tableName = "episodes", indices = [Index("timestamp")])
data class EpisodeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val convId: Long,
    val title: String,
    val summary: String,
    val topics: String = "",               // comma separated
    val mood: String = "neutral",
    val timestamp: Long,
    val embedding: ByteArray? = null
)

/** Mood history for the weekly graph + gentle check-ins. */
@Entity(tableName = "moods", indices = [Index("timestamp")])
data class MoodEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val mood: String,
    val intensity: Float = 0.5f,
    val source: String = "text",           // text | voice
    val timestamp: Long
)

/* ───────────── DAOs ───────────── */

@Dao
interface FactDao {
    @Query("SELECT * FROM facts ORDER BY pinned DESC, updatedAt DESC")
    fun observeAll(): Flow<List<FactEntity>>

    @Query("SELECT * FROM facts") suspend fun all(): List<FactEntity>
    @Query("SELECT * FROM facts WHERE category = :c AND slot = :s") suspend fun bySlot(c: String, s: String): List<FactEntity>
    @Query("SELECT * FROM facts WHERE category = :c") suspend fun byCategory(c: String): List<FactEntity>
    @Query("SELECT * FROM facts WHERE id = :id") suspend fun byId(id: Long): FactEntity?
    @Query("SELECT COUNT(*) FROM facts") suspend fun count(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(f: FactEntity): Long
    @Update suspend fun update(f: FactEntity)

    @Query("DELETE FROM facts WHERE id = :id") suspend fun delete(id: Long)
    @Query("DELETE FROM facts WHERE category = :c") suspend fun deleteCategory(c: String)
    @Query("DELETE FROM facts") suspend fun deleteAll()

    @Query("UPDATE facts SET pinned = :p WHERE id = :id") suspend fun setPinned(id: Long, p: Boolean)
    @Query("UPDATE facts SET value = :v, updatedAt = :t, embedding = :e WHERE id = :id")
    suspend fun updateValue(id: Long, v: String, t: Long, e: ByteArray?)
    @Query("UPDATE facts SET lastUsedAt = :t, useCount = useCount + 1 WHERE id IN (:ids)")
    suspend fun touch(ids: List<Long>, t: Long)
}

@Dao
interface EpisodeDao {
    @Query("SELECT * FROM episodes ORDER BY timestamp DESC") fun observeAll(): Flow<List<EpisodeEntity>>
    @Query("SELECT * FROM episodes ORDER BY timestamp DESC LIMIT :n") suspend fun recent(n: Int): List<EpisodeEntity>
    @Query("SELECT * FROM episodes WHERE convId = :cid LIMIT 1") suspend fun byConv(cid: Long): EpisodeEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(e: EpisodeEntity): Long
    @Query("DELETE FROM episodes WHERE id = :id") suspend fun delete(id: Long)
    @Query("DELETE FROM episodes") suspend fun deleteAll()
}

@Dao
interface MoodDao {
    @Query("SELECT * FROM moods WHERE timestamp >= :since ORDER BY timestamp ASC") suspend fun since(since: Long): List<MoodEntity>
    @Query("SELECT * FROM moods WHERE timestamp >= :since ORDER BY timestamp ASC") fun observeSince(since: Long): Flow<List<MoodEntity>>
    @Query("SELECT * FROM moods ORDER BY timestamp DESC LIMIT 1") suspend fun last(): MoodEntity?
    @Insert suspend fun insert(m: MoodEntity): Long
    @Query("DELETE FROM moods") suspend fun deleteAll()
}

/* ───────────── Encrypted database (SQLCipher AES-256) ───────────── */

@Database(entities = [FactEntity::class, EpisodeEntity::class, MoodEntity::class], version = 1, exportSchema = false)
abstract class MemoryDb : RoomDatabase() {
    abstract fun facts(): FactDao
    abstract fun episodes(): EpisodeDao
    abstract fun moods(): MoodDao

    companion object {
        private const val NAME = "juliet_mind.db"
        @Volatile private var inst: MemoryDb? = null

        init { System.loadLibrary("sqlcipher") }

        fun get(ctx: Context): MemoryDb = inst ?: synchronized(this) {
            inst ?: open(ctx.applicationContext).also { inst = it }
        }

        private fun build(app: Context): MemoryDb {
            val factory = SupportOpenHelperFactory(KeyVault.dbPassphrase(app))
            return Room.databaseBuilder(app, MemoryDb::class.java, NAME)
                .openHelperFactory(factory)
                .build()
        }

        private fun open(app: Context): MemoryDb = try {
            build(app).also { it.openHelper.writableDatabase }          // force-open to validate the key
        } catch (e: Exception) {
            // Keystore key lost (e.g. restored phone) -> old data is unreadable by design. Start clean.
            deleteFiles(app); KeyVault.reset(app); build(app)
        }

        private fun deleteFiles(app: Context) {
            listOf("", "-wal", "-shm", "-journal").forEach { File(app.getDatabasePath(NAME).path + it).delete() }
        }

        /** Full factory reset: closes DB, deletes files, destroys keys. Restart the app after calling. */
        fun destroy(ctx: Context) {
            val app = ctx.applicationContext
            synchronized(this) { inst?.close(); inst = null }
            deleteFiles(app); KeyVault.reset(app)
        }
    }
}
