package com.juliet.ai.ann

import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.util.Base64
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.juliet.ai.BuildConfig
import com.juliet.ai.data.Prefs
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.Calendar
import java.util.Locale

/**
 * Speaks notification and call announcements in a natural female voice in real time.
 * Features:
 * - Female TTS voice preference and warm voice pitch tuning.
 * - Sensitive OTP, verification code, and password redaction to protect user privacy.
 * - Start, Stop, Pause, Resume, and test controls.
 * - Quiet hours, Do Not Disturb, and in-call suppression.
 */
object Announcer {
    @Volatile
    var voiceActive = false // set by GeminiLive while a live voice session runs

    /** Compose state, so the Pause / Resume button updates on screen immediately. */
    var isPaused by mutableStateOf(false)

    private class Item(val text: String, val vol: Float)
    private var tts: TextToSpeech? = null          // only a fallback if Juliet's own voice can't be reached
    private var ttsReady = false
    private val http = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS).readTimeout(20, TimeUnit.SECONDS).build()
    // ONE worker: announcements play strictly one after another, never on top of each other.
    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r, "juliet-announce").apply { isDaemon = true } }
    @Volatile private var gen = 0                   // bumped by stop()/pause() to cancel queued + current speech
    @Volatile private var track: AudioTrack? = null
    private val cache = object : LinkedHashMap<String, ByteArray>(16, 0.75f, true) {
        override fun removeEldestEntry(e: MutableMap.MutableEntry<String, ByteArray>?) = size > 24
    }
    private val TTS_MODELS = listOf("gemini-2.5-flash-preview-tts", "gemini-2.5-pro-preview-tts")

    private val SENSITIVE_KEYWORDS = Regex(
        "(?i)\\b(otp|one\\s*time\\s*password|verification\\s*code|security\\s*code|login\\s*code|pin\\s*code|cvv|password|passcode|bank|hbl|mcb|ubl|meezan|jazzcash|easypaisa|nayapay|sadapay)\\b"
    )
    private val AUTH_CODE_DIGITS = Regex("\\b\\d{4,8}\\b")

    /**
     * Checks if the notification text contains a sensitive authentication code, OTP, or password.
     */
    fun containsSensitiveCode(text: String): Boolean {
        if (text.isBlank()) return false
        val hasKeyword = SENSITIVE_KEYWORDS.containsMatchIn(text)
        val hasCode = AUTH_CODE_DIGITS.containsMatchIn(text)
        return hasKeyword && hasCode
    }

    /**
     * Checks if current time falls within user-configured Quiet Hours.
     */
    fun isQuietHours(prefs: Prefs): Boolean {
        if (prefs.get("ann_quiet_hours", "0") != "1") return false
        val cal = Calendar.getInstance()
        val hour = cal.get(Calendar.HOUR_OF_DAY)
        val start = prefs.get("ann_quiet_start", "22").toIntOrNull() ?: 22
        val end = prefs.get("ann_quiet_end", "7").toIntOrNull() ?: 7

        return if (start > end) {
            hour >= start || hour < end
        } else {
            hour in start until end
        }
    }

    /** Returns null if spoken or queued, otherwise the reason it was skipped. */
    @Synchronized
    fun speak(ctx: Context, text: String, volume: Float = 1f, force: Boolean = false): String? {
        val app = ctx.applicationContext
        if (isPaused && !force) return "announcements are paused"

        if (!force) {
            val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (am.mode == AudioManager.MODE_IN_CALL || am.mode == AudioManager.MODE_IN_COMMUNICATION) return "a call is in progress"
            if (voiceActive) return "a Juliet voice session is active"
            if (am.ringerMode != AudioManager.RINGER_MODE_NORMAL) return "phone is on silent or vibrate"
            val nm = app.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val f = nm.currentInterruptionFilter
            if (f != NotificationManager.INTERRUPTION_FILTER_ALL && f != NotificationManager.INTERRUPTION_FILTER_UNKNOWN) return "Do Not Disturb is on"

            val prefs = Prefs(app)
            if (isQuietHours(prefs)) return "quiet hours are active"
        }

        // Privacy filter: Never read sensitive OTPs or passwords aloud
        val safeText = if (containsSensitiveCode(text)) {
            "Verification code received. Message content hidden for your security."
        } else {
            text
        }

        val item = Item(safeText, volume.coerceIn(0f, 1f))
        val g = gen
        worker.execute {
            try { if (g == gen && (!isPaused || force)) play(app, item, g) } catch (_: Throwable) {}
        }
        return null
    }

    // ---- Juliet's OWN voice (same Gemini voice as live voice chat: Settings > Voice) ----

    private fun geminiKey(prefs: Prefs): String = prefs.get("k_gemini").ifBlank { BuildConfig.DEFAULT_GEMINI_KEY }

    /** Returns raw PCM16 mono 24 kHz in Juliet's voice, or null if it could not be fetched. */
    private fun synth(prefs: Prefs, text: String): ByteArray? {
        val key = geminiKey(prefs)
        if (key.isBlank()) return null
        val voice = prefs.get("voice", "Kore").ifBlank { "Kore" }
        val ck = "$voice|$text"
        synchronized(cache) { cache[ck]?.let { return it } }
        val models = (listOf(prefs.get("ann_tts_model")) + TTS_MODELS).filter { it.isNotBlank() }.distinct()
        for (m in models) {
            try {
                val body = JSONObject()
                    .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(
                        JSONObject().put("text", "Say this in a warm, natural, friendly female voice, clearly: $text")))))
                    .put("generationConfig", JSONObject()
                        .put("responseModalities", JSONArray().put("AUDIO"))
                        .put("speechConfig", JSONObject().put("voiceConfig",
                            JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
                val req = Request.Builder()
                    .url("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent")
                    .header("x-goog-api-key", key)
                    .post(body.toString().toRequestBody("application/json".toMediaType())).build()
                http.newCall(req).execute().use { r ->
                    if (!r.isSuccessful) return@use
                    val j = JSONObject(r.body?.string().orEmpty())
                    val data = j.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
                        ?.optJSONArray("parts")?.optJSONObject(0)?.optJSONObject("inlineData")?.optString("data").orEmpty()
                    if (data.isNotEmpty()) {
                        val pcm = Base64.decode(data, Base64.DEFAULT)
                        synchronized(cache) { cache[ck] = pcm }
                        return pcm
                    }
                }
            } catch (_: Exception) { }
        }
        return null
    }

    private fun play(app: Context, i: Item, g: Int) {
        val pcm = synth(Prefs(app), i.text)
        if (g != gen) return                         // stopped while we were fetching
        if (pcm == null) { speakFallback(app, i); return }
        val min = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(min, 4096)).setTransferMode(AudioTrack.MODE_STREAM).build()
        track = t
        try {
            t.setVolume(i.vol); t.play()
            var off = 0
            while (off < pcm.size && g == gen) {
                val n = t.write(pcm, off, minOf(4096, pcm.size - off))
                if (n <= 0) break
                off += n
            }
            // let the last buffered samples finish (unless stopped)
            val totalFrames = pcm.size / 2
            var guard = 0
            while (g == gen && t.playbackHeadPosition < totalFrames && guard++ < 400) Thread.sleep(25)
        } finally {
            try { t.stop() } catch (_: Exception) {}
            try { t.release() } catch (_: Exception) {}
            if (track === t) track = null
        }
    }

    // ---- Last-resort fallback: phone's own TTS (different voice) only when Juliet's voice can't be reached ----

    private fun speakFallback(app: Context, i: Item) {
        synchronized(this) {
            if (tts == null) {
                tts = TextToSpeech(app) { st ->
                    synchronized(this@Announcer) {
                        ttsReady = st == TextToSpeech.SUCCESS
                        if (ttsReady) { applyFemaleVoice(); say(i) }
                    }
                }
            } else if (ttsReady) say(i)
        }
    }

    private fun applyFemaleVoice() {
        val engine = tts ?: return
        try {
            engine.setPitch(1.08f); engine.setSpeechRate(1.0f)
            val voices: Set<Voice>? = engine.voices
            val f = voices?.firstOrNull { v ->
                val n = v.name.lowercase()
                (n.contains("female") || n.contains("fem") || v.features?.contains("gender=female") == true) && !v.isNetworkConnectionRequired
            }
            if (f != null) engine.voice = f
        } catch (_: Exception) {}
    }

    private fun say(i: Item) {
        val b = Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, i.vol) }
        tts?.speak(i.text, TextToSpeech.QUEUE_ADD, b, "ann_" + System.nanoTime())
    }

    private fun cutNow() {
        gen++
        try { track?.pause(); track?.flush(); track?.stop() } catch (_: Exception) {}
        try { tts?.stop() } catch (_: Exception) {}
    }

    @Synchronized fun pause() { isPaused = true; cutNow() }
    @Synchronized fun resume() { isPaused = false }
    @Synchronized fun stop() { cutNow() }
}
