package com.juliet.ai.phone

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build

enum class AudioRoute(val label: String) {
    Earpiece("Phone earpiece"),
    Speaker("Loudspeaker"),
    Bluetooth("Bluetooth headset")
}

/**
 * Manages call audio routing (Speaker, Earpiece, Bluetooth) and volume control.
 * Compatible with Android 12+ (setCommunicationDevice) and legacy fallbacks.
 */
class AudioRouteManager(private val ctx: Context) {
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun getCurrentRoute(): AudioRoute {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val dev = am.communicationDevice
                when (dev?.type) {
                    AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> AudioRoute.Speaker
                    AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
                    AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
                    AudioDeviceInfo.TYPE_BLE_HEADSET -> AudioRoute.Bluetooth
                    else -> if (am.isSpeakerphoneOn) AudioRoute.Speaker else AudioRoute.Earpiece
                }
            } else {
                when {
                    am.isSpeakerphoneOn -> AudioRoute.Speaker
                    am.isBluetoothScoOn -> AudioRoute.Bluetooth
                    else -> AudioRoute.Earpiece
                }
            }
        } catch (e: Exception) {
            AudioRoute.Earpiece
        }
    }

    fun isSpeakerOn(): Boolean = getCurrentRoute() == AudioRoute.Speaker

    fun setSpeaker(on: Boolean): Boolean {
        return if (on) {
            setRoute(AudioRoute.Speaker)
        } else {
            setRoute(AudioRoute.Earpiece)
        }
    }

    fun setRoute(route: AudioRoute): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val devices = am.availableCommunicationDevices
                val targetType = when (route) {
                    AudioRoute.Speaker -> AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
                    AudioRoute.Earpiece -> AudioDeviceInfo.TYPE_BUILTIN_EARPIECE
                    AudioRoute.Bluetooth -> AudioDeviceInfo.TYPE_BLUETOOTH_SCO
                }
                val matched = devices.firstOrNull { it.type == targetType }
                    ?: if (route == AudioRoute.Bluetooth) {
                        devices.firstOrNull {
                            it.type == AudioDeviceInfo.TYPE_BLE_HEADSET || it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP
                        }
                    } else null

                if (matched != null) {
                    am.setCommunicationDevice(matched)
                } else if (route == AudioRoute.Earpiece) {
                    am.clearCommunicationDevice()
                    true
                } else {
                    // Fallback to legacy
                    setRouteLegacy(route)
                }
            } else {
                setRouteLegacy(route)
            }
        } catch (e: Exception) {
            false
        }
    }

    private fun setRouteLegacy(route: AudioRoute): Boolean {
        return try {
            when (route) {
                AudioRoute.Speaker -> {
                    try { am.stopBluetoothSco() } catch (_: Exception) {}
                    am.isBluetoothScoOn = false
                    am.isSpeakerphoneOn = true
                    am.isSpeakerphoneOn
                }
                AudioRoute.Earpiece -> {
                    try { am.stopBluetoothSco() } catch (_: Exception) {}
                    am.isBluetoothScoOn = false
                    am.isSpeakerphoneOn = false
                    !am.isSpeakerphoneOn
                }
                AudioRoute.Bluetooth -> {
                    am.isSpeakerphoneOn = false
                    try {
                        am.startBluetoothSco()
                        am.isBluetoothScoOn = true
                        true
                    } catch (e: Exception) {
                        false
                    }
                }
            }
        } catch (e: Exception) {
            false
        }
    }

    fun getCallVolume(): Int = try {
        am.getStreamVolume(AudioManager.STREAM_VOICE_CALL)
    } catch (e: Exception) {
        0
    }

    fun getMaxCallVolume(): Int = try {
        am.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL)
    } catch (e: Exception) {
        10
    }

    fun setCallVolume(level: Int): Boolean {
        return try {
            val max = getMaxCallVolume()
            val safe = level.coerceIn(0, max)
            am.setStreamVolume(AudioManager.STREAM_VOICE_CALL, safe, AudioManager.FLAG_SHOW_UI)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun adjustCallVolume(up: Boolean): Boolean {
        return try {
            val direction = if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
            am.adjustStreamVolume(AudioManager.STREAM_VOICE_CALL, direction, AudioManager.FLAG_SHOW_UI)
            true
        } catch (e: Exception) {
            false
        }
    }

    // ---- Media stream volume controls ----
    fun getMediaVolume(): Int = try {
        am.getStreamVolume(AudioManager.STREAM_MUSIC)
    } catch (e: Exception) {
        0
    }

    fun getMaxMediaVolume(): Int = try {
        am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
    } catch (e: Exception) {
        15
    }

    fun setMediaVolume(level: Int): Boolean {
        return try {
            val max = getMaxMediaVolume()
            val safe = level.coerceIn(0, max)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, safe, AudioManager.FLAG_SHOW_UI)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun adjustMediaVolume(up: Boolean): Boolean {
        return try {
            val direction = if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
            true
        } catch (e: Exception) {
            false
        }
    }

    // ---- Media Playback Controls ----
    private fun sendMediaKey(keyCode: Int): Boolean {
        return try {
            val down = android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, keyCode)
            val up = android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, keyCode)
            am.dispatchMediaKeyEvent(down)
            am.dispatchMediaKeyEvent(up)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun playPauseMedia(): Boolean = sendMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
    fun playMedia(): Boolean = sendMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PLAY)
    fun pauseMedia(): Boolean = sendMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PAUSE)
    fun nextMedia(): Boolean = sendMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_NEXT)
    fun prevMedia(): Boolean = sendMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS)
}

