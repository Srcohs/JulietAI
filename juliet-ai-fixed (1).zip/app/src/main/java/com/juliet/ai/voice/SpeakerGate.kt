package com.juliet.ai.voice

import com.juliet.ai.data.Prefs
import com.juliet.ai.data.VoiceProfile
import kotlin.math.log10
import kotlin.math.sqrt

/**
 * Real-time speaker gate. Sits between the microphone and the cloud:
 *
 *  - Speech is buffered locally and verified against enrolled voice prints.
 *  - Only audio from an AUTHORIZED speaker is passed on (to Gemini). Strangers' audio never
 *    leaves the phone.
 *  - Each rejected utterance (>= 1.5 s of real speech) is a strike. [maxStrikes] strikes within
 *    [STRIKE_WINDOW_MS] fires [onLockout] (the app then locks the phone).
 *
 * Call [feed] with consecutive 100 ms PCM chunks from ONE thread.
 */
class SpeakerGate(
    private val manager: VoiceEnrollmentManager,
    private val prefs: Prefs
) {
    companion object {
        const val CHUNK_MS = 100
        const val VERIFY_AFTER_MS = 1500       // speech needed before first decision
        const val END_SILENCE_MS = 700         // silence that ends an utterance
        const val OPEN_WINDOW_MS = 15_000      // gate stays open this long after owner stops
        const val STRIKE_WINDOW_MS = 120_000L
        const val LOCKOUT_COOLDOWN_MS = 8_000L
        private const val PRE_ROLL_CHUNKS = 3
    }

    /** (strikesNow, maxStrikes, details) */
    var onReject: ((Int, Int, String) -> Unit)? = null
    var onAccept: ((String, Float) -> Unit)? = null
    var onLockout: (() -> Unit)? = null

    private var profiles: List<VoiceProfile> = emptyList()
    private var maxStrikes = 3

    private val pre = ArrayDeque<ShortArray>()
    private val utt = ArrayList<ShortArray>()
    private var speechMs = 0
    private var silenceMs = 0
    private var decided = false          // utterance already verified once
    private var ignoring = false         // currently inside a rejected utterance
    private var open = false
    private var openSilenceMs = 0
    private var floorDb = Float.NaN
    private val strikes = ArrayDeque<Long>()
    private var lastLockout = 0L

    /** Gate is only active when Voice Lock is on AND at least one voice is enrolled. */
    fun refresh(): Boolean {
        profiles = prefs.loadVoiceProfiles()
        maxStrikes = (prefs.get("voice_lock_strikes", "3").toIntOrNull() ?: 3).coerceIn(2, 6)
        reset()
        return isActive()
    }

    fun isActive(): Boolean = prefs.get("voice_lock_enabled", "0") == "1" && profiles.isNotEmpty()

    fun reset() {
        pre.clear(); utt.clear(); speechMs = 0; silenceMs = 0
        decided = false; ignoring = false; open = false; openSilenceMs = 0
    }

    /** Call when the app itself is speaking, so its own voice never forms part of an utterance. */
    fun dropUtterance() {
        pre.clear(); utt.clear(); speechMs = 0; silenceMs = 0; decided = false; ignoring = false
    }

    private fun db(c: ShortArray): Float {
        var s = 0.0
        for (v in c) { val x = v.toDouble(); s += x * x }
        return (20.0 * log10(sqrt(s / c.size) + 1.0)).toFloat()
    }

    /** Returns the chunks that are allowed to be sent on to the cloud. */
    fun feed(chunk: ShortArray): List<ShortArray> {
        val level = db(chunk)
        floorDb = when {
            floorDb.isNaN() -> level
            level < floorDb -> level
            else -> floorDb + 0.02f * (level - floorDb)
        }
        val speech = level > maxOf(floorDb + 10f, 45f)
        val out = ArrayList<ShortArray>(4)

        if (speech) {
            silenceMs = 0; openSilenceMs = 0
            if (!ignoring) {
                if (utt.isEmpty()) { utt.addAll(pre); pre.clear() }
                utt.add(chunk)
                speechMs += CHUNK_MS
            }
        } else {
            silenceMs += CHUNK_MS
            if (open) openSilenceMs += CHUNK_MS
            if (utt.isNotEmpty() && !ignoring) utt.add(chunk)
            else if (!ignoring) { pre.addLast(chunk); while (pre.size > PRE_ROLL_CHUNKS) pre.removeFirst() }
        }

        // owner already verified: stream live
        if (open) {
            if (openSilenceMs >= OPEN_WINDOW_MS) open = false else out.add(chunk)
        }

        // (a) enough speech and still undecided -> decide now
        if (!ignoring && !decided && speechMs >= VERIFY_AFTER_MS) {
            val wasOpen = open
            if (decide()) {
                if (!wasOpen) out.addAll(utt)    // flush what we held back
                open = true; openSilenceMs = 0
            } else {
                open = false
                utt.clear(); speechMs = 0; ignoring = true
            }
        }

        // (b) utterance ended
        if (silenceMs >= END_SILENCE_MS) {
            if (!ignoring && utt.isNotEmpty() && !decided && speechMs >= 1000 && !open) {
                // short phrase (1.0-1.5 s): decide at the end
                if (decide()) { out.addAll(utt); open = true; openSilenceMs = 0 }
                else open = false
            }
            utt.clear(); speechMs = 0; decided = false; ignoring = false
        }
        return out
    }

    private fun pcmOfUtterance(): ShortArray {
        var n = 0
        for (c in utt) n += c.size
        val all = ShortArray(n)
        var o = 0
        for (c in utt) { System.arraycopy(c, 0, all, o, c.size); o += c.size }
        return all
    }

    /** true = authorized. Records a strike on a confident rejection. */
    private fun decide(): Boolean {
        decided = true
        val e = SpeakerDsp.embed(pcmOfUtterance()) ?: return false.also { decided = false }
        val r = manager.verifyEmbedding(e, profiles)
        if (r.isAuthorized) {
            strikes.clear()
            onAccept?.invoke(r.matchedProfile?.name ?: "", r.confidence)
            return true
        }
        val now = System.currentTimeMillis()
        while (strikes.isNotEmpty() && now - strikes.first() > STRIKE_WINDOW_MS) strikes.removeFirst()
        strikes.addLast(now)
        onReject?.invoke(strikes.size, maxStrikes, r.details)
        if (strikes.size >= maxStrikes && now - lastLockout > LOCKOUT_COOLDOWN_MS) {
            lastLockout = now
            strikes.clear()
            onLockout?.invoke()
        }
        return false
    }
}
