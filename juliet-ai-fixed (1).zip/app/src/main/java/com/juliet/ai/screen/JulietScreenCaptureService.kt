package com.juliet.ai.screen

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.juliet.ai.MainActivity
import com.juliet.ai.R
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.ByteArrayOutputStream

enum class SharingState {
    Inactive,
    Sharing,
    Paused
}

class JulietScreenCaptureService : Service() {

    inner class LocalBinder : Binder() {
        val service: JulietScreenCaptureService get() = this@JulietScreenCaptureService
    }

    private val binder = LocalBinder()

    companion object {
        const val ACTION_START = "com.juliet.ai.screen.START"
        const val ACTION_STOP = "com.juliet.ai.screen.STOP"
        const val ACTION_PAUSE = "com.juliet.ai.screen.PAUSE"
        const val ACTION_RESUME = "com.juliet.ai.screen.RESUME"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"

        const val CHANNEL_ID = "juliet_screen_share"
        const val NOTIFICATION_ID = 4040

        val sharingState = MutableStateFlow(SharingState.Inactive)
        val errorMessage = MutableStateFlow<String?>(null)

        @Volatile
        var instance: JulietScreenCaptureService? = null
            private set

        fun getLatestFrame(): Bitmap? = instance?.captureFrame()
    }

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var screenWidth = 720
    private var screenHeight = 1280
    private var screenDensity = 320

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        instance = this
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val resultData = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
                if (resultCode == Activity.RESULT_OK && resultData != null) {
                    startCapture(resultCode, resultData)
                } else {
                    errorMessage.value = "Screen capture permission not granted"
                    stopSelf()
                }
            }
            ACTION_PAUSE -> pauseCapture()
            ACTION_RESUME -> resumeCapture()
            ACTION_STOP -> stopCapture()
        }
        return START_NOT_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Juliet Screen Sharing",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows live screen sharing status for Juliet AI"
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(stateText: String): Notification {
        val stopIntent = Intent(this, JulietScreenCaptureService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPending = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val openAppIntent = Intent(this, MainActivity::class.java)
        val openAppPending = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Juliet Live Screen Sharing")
            .setContentText(stateText)
            .setSmallIcon(R.drawable.juliet_emblem)
            .setContentIntent(openAppPending)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop Sharing", stopPending)
            .setOngoing(true)
            .build()
    }

    private fun startCapture(resultCode: Int, resultData: Intent) {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)

        // Scale down to max 720p width for low bandwidth / fast AI vision response
        val scale = if (metrics.widthPixels > 720) 720f / metrics.widthPixels else 1f
        screenWidth = (metrics.widthPixels * scale).toInt()
        screenHeight = (metrics.heightPixels * scale).toInt()
        screenDensity = (metrics.densityDpi * scale).toInt()

        val notification = buildNotification("Screen sharing active with Juliet")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = mpManager.getMediaProjection(resultCode, resultData)

        mediaProjection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopCapture()
            }
        }, null)

        imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "JulietScreenShare",
            screenWidth, screenHeight, screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, null
        )

        sharingState.value = SharingState.Sharing
        errorMessage.value = null
    }

    fun captureFrame(): Bitmap? {
        if (sharingState.value != SharingState.Sharing) return null
        val reader = imageReader ?: return null
        var image: android.media.Image? = null
        return try {
            image = reader.acquireLatestImage()
            if (image == null) return null
            val planes = image.planes
            val buffer = planes[0].buffer
            val pixelStride = planes[0].pixelStride
            val rowStride = planes[0].rowStride
            val rowPadding = rowStride - pixelStride * screenWidth

            val bitmap = Bitmap.createBitmap(
                screenWidth + rowPadding / pixelStride,
                screenHeight,
                Bitmap.Config.ARGB_8888
            )
            bitmap.copyPixelsFromBuffer(buffer)
            // Crop out padding if needed
            if (rowPadding > 0) {
                Bitmap.createBitmap(bitmap, 0, 0, screenWidth, screenHeight)
            } else {
                bitmap
            }
        } catch (e: Exception) {
            null
        } finally {
            image?.close()
        }
    }

    fun pauseCapture() {
        if (sharingState.value == SharingState.Sharing) {
            sharingState.value = SharingState.Paused
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIFICATION_ID, buildNotification("Screen sharing paused"))
        }
    }

    fun resumeCapture() {
        if (sharingState.value == SharingState.Paused) {
            sharingState.value = SharingState.Sharing
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIFICATION_ID, buildNotification("Screen sharing active with Juliet"))
        }
    }

    fun stopCapture() {
        try {
            virtualDisplay?.release()
            imageReader?.close()
            mediaProjection?.stop()
        } catch (e: Exception) {
            // cleanup
        } finally {
            virtualDisplay = null
            imageReader = null
            mediaProjection = null
            sharingState.value = SharingState.Inactive
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    override fun onDestroy() {
        if (instance === this) {
            instance = null
        }
        stopCapture()
        super.onDestroy()
    }
}
