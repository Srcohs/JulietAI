package com.juliet.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.juliet.ai.data.JulietSummary
import com.juliet.ai.vm.JulietViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SummariesScreen(vm: JulietViewModel) = Page("Juliet Summaries", { vm.back() }) {
    val p = LocalPal.current
    var customContact by remember { mutableStateOf("") }
    val privacyMode = vm.s("ann_privacy") == "1"

    Sub("Concise AI summaries of your WhatsApp conversations and notifications highlighting key points, decisions, and action items.")

    if (privacyMode) {
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                .background(J.Gold.copy(alpha = 0.12f))
                .border(1.dp, J.Gold.copy(alpha = 0.35f), RoundedCornerShape(18.dp))
                .padding(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(Icons.Rounded.Shield, "Privacy", tint = J.Gold, modifier = Modifier.size(22.dp))
                Text(
                    "Privacy Mode Active: Sensitive notification details and private codes will be masked in summaries.",
                    color = p.text, fontSize = 13.sp, lineHeight = 18.sp
                )
            }
        }
        Spacer(Modifier.height(14.dp))
    }

    Sec("QUICK SUMMARIES")
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
        SummaryQuickTile(
            icon = "💬",
            title = "Last 10 WhatsApp",
            sub = "All private chats",
            mod = Modifier.weight(1f)
        ) {
            vm.generateSummary(target = "whatsapp", count = 10, speakResult = true)
        }
        SummaryQuickTile(
            icon = "🔔",
            title = "Notifications",
            sub = "Today's highlights",
            mod = Modifier.weight(1f)
        ) {
            vm.generateSummary(target = "notifications", onlyToday = true, speakResult = true)
        }
    }

    Spacer(Modifier.height(14.dp))
    Sec("SUMMARIZE SPECIFIC CONTACT")
    OutlinedTextField(
        value = customContact,
        onValueChange = { customContact = it },
        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        placeholder = { Text("Enter contact name (e.g. Ahmed, Ammi)", color = p.mu) },
        shape = RoundedCornerShape(20.dp),
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = J.Red,
            unfocusedBorderColor = p.border,
            cursorColor = J.Crim,
            focusedTextColor = p.text,
            unfocusedTextColor = p.text
        )
    )

    GradientButton(
        text = if (vm.isSummarizing) "Generating Summary…" else "Summarize Chat with $customContact".ifBlank { "Summarize WhatsApp Contact" },
        modifier = Modifier.fillMaxWidth()
    ) {
        if (customContact.isNotBlank()) {
            vm.generateSummary(target = "whatsapp", contact = customContact.trim(), speakResult = true)
        }
    }

    Spacer(Modifier.height(20.dp))
    Sec("SAVED SUMMARIES")
    if (vm.summaries.isEmpty()) {
        Text("No summaries generated yet. Tap a quick action above or ask Juliet: \"Summarize my last 10 WhatsApp messages\".", color = p.mu, fontSize = 14.sp, lineHeight = 20.sp)
    } else {
        vm.summaries.forEach { summary ->
            SummaryCard(summary, onSpeak = {
                val spoken = "${summary.title}. " +
                    (summary.keyPoints.firstOrNull()?.let { "Key point: $it. " } ?: "") +
                    (summary.actionItems.firstOrNull()?.let { "Action item: $it." } ?: "")
                vm.speak(spoken)
            }, onDelete = {
                vm.deleteSummary(summary.id)
            })
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun SummaryQuickTile(icon: String, title: String, sub: String, mod: Modifier, onClick: () -> Unit) {
    val p = LocalPal.current
    val sh = RoundedCornerShape(20.dp)
    Column(
        mod.clip(sh).background(p.card).border(1.dp, p.border, sh)
            .clickable(onClick = onClick).padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(42.dp).clip(CircleShape).background(p.card2), Alignment.Center) {
            Text(icon, fontSize = 20.sp)
        }
        Spacer(Modifier.height(8.dp))
        Text(title, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        Text(sub, color = p.mu, fontSize = 12.sp)
    }
}

@Composable
private fun SummaryCard(summary: JulietSummary, onSpeak: () -> Unit, onDelete: () -> Unit) {
    val p = LocalPal.current
    val sh = RoundedCornerShape(22.dp)
    val timeStr = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()).format(Date(summary.timestamp))

    Column(
        Modifier.fillMaxWidth().clip(sh).background(p.card).border(1.dp, p.border, sh).padding(16.dp)
    ) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(summary.title, color = p.text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text(timeStr, color = p.mu, fontSize = 12.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(onClick = onSpeak) {
                    Icon(Icons.Rounded.VolumeUp, "Listen", tint = J.Gold)
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Rounded.Delete, "Delete", tint = J.Red)
                }
            }
        }

        if (summary.keyPoints.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Text("📌 KEY POINTS", color = J.Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            summary.keyPoints.forEach { pt ->
                Text("• $pt", color = p.text, fontSize = 14.sp, lineHeight = 20.sp, modifier = Modifier.padding(top = 2.dp))
            }
        }

        if (summary.decisions.isNotEmpty() && summary.decisions.none { it.contains("None", ignoreCase = true) }) {
            Spacer(Modifier.height(10.dp))
            Text("🤝 DECISIONS MADE", color = J.Ok, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            summary.decisions.forEach { d ->
                Text("• $d", color = p.text, fontSize = 14.sp, lineHeight = 20.sp, modifier = Modifier.padding(top = 2.dp))
            }
        }

        if (summary.actionItems.isNotEmpty() && summary.actionItems.none { it.contains("None", ignoreCase = true) }) {
            Spacer(Modifier.height(10.dp))
            Text("⚡ ACTION ITEMS", color = J.Red, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            summary.actionItems.forEach { act ->
                Text("• $act", color = p.text, fontSize = 14.sp, lineHeight = 20.sp, modifier = Modifier.padding(top = 2.dp))
            }
        }

        if (summary.privacyApplied) {
            Spacer(Modifier.height(8.dp))
            Text("🛡 Privacy filter applied", color = p.mu, fontSize = 11.sp)
        }
    }
}
