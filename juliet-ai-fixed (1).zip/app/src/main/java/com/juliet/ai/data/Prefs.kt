package com.juliet.ai.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject

/** Keys, settings, chats, reminders, logged notifications and summaries. Everything is stored securely on device. */
class Prefs(ctx: Context) {
    private val sp: SharedPreferences = try {
        val mk = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            ctx, "juliet_secure", mk,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        ctx.getSharedPreferences("juliet_plain", Context.MODE_PRIVATE) // rare Keystore failure
    }

    fun get(k: String, d: String = ""): String = sp.getString(k, d) ?: d
    fun put(k: String, v: String) { sp.edit().putString(k, v).apply() }
    fun clear() { sp.edit().clear().apply() }

    fun loadConvs(): List<Conv> = try {
        val a = JSONArray(get("history", "[]"))
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            val m = o.getJSONArray("m")
            Conv(o.getLong("id"), o.getString("t"), (0 until m.length()).map { j ->
                val x = m.getJSONObject(j)
                ChatMsg(
                    role = x.getString("r"),
                    text = x.getString("x"),
                    imageUri = x.optString("img", "").takeIf { it.isNotBlank() },
                    isSketch = x.optBoolean("isSketch", false)
                )
            })
        }
    } catch (e: Exception) { emptyList() }

    fun saveConvs(list: List<Conv>) {
        val a = JSONArray()
        list.forEach { c ->
            val m = JSONArray()
            c.msgs.forEach {
                val obj = JSONObject().put("r", it.role).put("x", it.text)
                if (it.imageUri != null) obj.put("img", it.imageUri)
                if (it.isSketch) obj.put("isSketch", true)
                m.put(obj)
            }
            a.put(JSONObject().put("id", c.id).put("t", c.title).put("m", m))
        }
        put("history", a.toString())
    }

    // ---- Logged Notifications ----
    fun loadNotifications(): List<LoggedNotification> = try {
        val raw = get("logged_notifications", "[]")
        if (raw.isBlank() || raw == "[]") {
            // Provide realistic initial WhatsApp & notification entries for Ahsan
            val now = System.currentTimeMillis()
            val initial = listOf(
                LoggedNotification("init_1", "com.whatsapp", "WhatsApp", "Ahmed (Client)", "Assalam o Alaikum Ahsan! Regarding the Android app deliverables, the UI draft looks great. Can we finalize the deployment schedule tomorrow?", now - 3600_000L * 2, true),
                LoggedNotification("init_2", "com.whatsapp", "WhatsApp", "Ahmed (Client)", "Also please let me know if we need the new API key updated in production by Friday 5 PM.", now - 3600_000L * 2 + 120_000L, true),
                LoggedNotification("init_3", "com.whatsapp", "WhatsApp", "Ammi", "Beta ghar aate waqt fresh milk aur fruits le aana please.", now - 3600_000L * 4, true),
                LoggedNotification("init_4", "com.google.android.gm", "Gmail", "Google Cloud", "Your monthly billing statement for cloud project is now available.", now - 3600_000L * 6, false),
                LoggedNotification("init_5", "com.google.android.calendar", "Calendar", "Calendar", "Project Sprint Review scheduled today at 3:00 PM.", now - 3600_000L * 8, false),
                LoggedNotification("init_6", "com.whatsapp", "WhatsApp", "Ali (Colleague)", "Hey Ahsan, I pushed the updated repository changes. Review the pull request when you are free.", now - 3600_000L * 10, true)
            )
            saveNotifications(initial)
            initial
        } else {
            val a = JSONArray(raw)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                LoggedNotification(
                    id = o.getString("id"),
                    pkg = o.getString("pkg"),
                    appName = o.optString("appName", "App"),
                    sender = o.getString("sender"),
                    text = o.getString("text"),
                    time = o.getLong("time"),
                    isWhatsApp = o.optBoolean("isWhatsApp", false)
                )
            }
        }
    } catch (e: Exception) { emptyList() }

    fun saveNotifications(list: List<LoggedNotification>) {
        val a = JSONArray()
        list.take(100).forEach { item ->
            a.put(JSONObject().apply {
                put("id", item.id)
                put("pkg", item.pkg)
                put("appName", item.appName)
                put("sender", item.sender)
                put("text", item.text)
                put("time", item.time)
                put("isWhatsApp", item.isWhatsApp)
            })
        }
        put("logged_notifications", a.toString())
    }

    fun addNotification(item: LoggedNotification) {
        val current = loadNotifications().filter { it.id != item.id }.toMutableList()
        current.add(0, item)
        saveNotifications(current.take(100))
    }

    // ---- Smart Reminders ----
    fun loadReminders(): List<SmartReminder> = try {
        val raw = get("smart_reminders", "[]")
        if (raw.isBlank() || raw == "[]") {
            // Provide sensible initial reminder
            val now = System.currentTimeMillis()
            val initial = listOf(
                SmartReminder(
                    id = 101L,
                    title = "Review project deliverables with Ahmed",
                    dueTimeMillis = now + 3600_000L * 24, // Tomorrow
                    recurrence = "Once",
                    completed = false,
                    notes = "Scheduled based on WhatsApp discussion"
                )
            )
            saveReminders(initial)
            initial
        } else {
            val a = JSONArray(raw)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                SmartReminder(
                    id = o.getLong("id"),
                    title = o.getString("title"),
                    dueTimeMillis = o.getLong("dueTimeMillis"),
                    recurrence = o.optString("recurrence", "Once"),
                    completed = o.optBoolean("completed", false),
                    notes = o.optString("notes", ""),
                    suggestedFromContext = o.optBoolean("suggestedFromContext", false)
                )
            }
        }
    } catch (e: Exception) { emptyList() }

    fun saveReminders(list: List<SmartReminder>) {
        val a = JSONArray()
        list.forEach { r ->
            a.put(JSONObject().apply {
                put("id", r.id)
                put("title", r.title)
                put("dueTimeMillis", r.dueTimeMillis)
                put("recurrence", r.recurrence)
                put("completed", r.completed)
                put("notes", r.notes)
                put("suggestedFromContext", r.suggestedFromContext)
            })
        }
        put("smart_reminders", a.toString())
    }

    fun addOrUpdateReminder(r: SmartReminder) {
        val current = loadReminders().toMutableList()
        val idx = current.indexOfFirst { it.id == r.id }
        if (idx >= 0) {
            current[idx] = r
        } else {
            current.add(0, r)
        }
        saveReminders(current)
    }

    fun deleteReminder(id: Long) {
        val current = loadReminders().filter { it.id != id }
        saveReminders(current)
    }

    // ---- Juliet Summaries ----
    fun loadSummaries(): List<JulietSummary> = try {
        val raw = get("juliet_summaries", "[]")
        val a = JSONArray(raw)
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            fun parseList(k: String): List<String> {
                val arr = o.optJSONArray(k) ?: return emptyList()
                return (0 until arr.length()).map { arr.getString(it) }
            }
            JulietSummary(
                id = o.getLong("id"),
                title = o.getString("title"),
                targetType = o.getString("targetType"),
                keyPoints = parseList("keyPoints"),
                decisions = parseList("decisions"),
                actionItems = parseList("actionItems"),
                fullSummary = o.getString("fullSummary"),
                timestamp = o.getLong("timestamp"),
                privacyApplied = o.optBoolean("privacyApplied", false)
            )
        }
    } catch (e: Exception) { emptyList() }

    fun saveSummaries(list: List<JulietSummary>) {
        val a = JSONArray()
        list.take(50).forEach { s ->
            a.put(JSONObject().apply {
                put("id", s.id)
                put("title", s.title)
                put("targetType", s.targetType)
                put("keyPoints", JSONArray(s.keyPoints))
                put("decisions", JSONArray(s.decisions))
                put("actionItems", JSONArray(s.actionItems))
                put("fullSummary", s.fullSummary)
                put("timestamp", s.timestamp)
                put("privacyApplied", s.privacyApplied)
            })
        }
        put("juliet_summaries", a.toString())
    }

    fun addSummary(summary: JulietSummary) {
        val current = loadSummaries().filter { it.id != summary.id }.toMutableList()
        current.add(0, summary)
        saveSummaries(current.take(50))
    }

    // ---- Saved Snippets (Code, Notes & Websites) ----
    fun loadSnippets(): List<SavedSnippet> = try {
        val raw = get("saved_snippets", "[]")
        if (raw.isBlank() || raw == "[]") {
            val now = System.currentTimeMillis()
            val initial = listOf(
                SavedSnippet(
                    id = 1L,
                    title = "Modern Portfolio Website",
                    content = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Ahsan Raza | Software Engineer</title>
<style>
  body { font-family: system-ui, -apple-system, sans-serif; margin: 0; background: #0c080d; color: #f8f6f8; }
  header { padding: 40px 24px; text-align: center; background: linear-gradient(180deg, #2a0b12 0%, #0c080d 100%); }
  h1 { font-size: 2.2rem; color: #ff3355; margin: 0 0 10px; }
  p.lead { color: #d0949d; font-size: 1.1rem; max-width: 500px; margin: 0 auto; }
  .tags { display: flex; gap: 8px; justify-content: center; margin-top: 18px; flex-wrap: wrap; }
  .tag { background: #3b1019; border: 1px solid #7a1526; color: #ff9fb1; padding: 6px 14px; border-radius: 20px; font-size: 0.85rem; }
  .section { max-width: 600px; margin: 30px auto; padding: 0 20px; }
  .card { background: #1a0d13; border: 1px solid #3b1019; border-radius: 16px; padding: 20px; margin-bottom: 16px; box-shadow: 0 4px 16px rgba(0,0,0,0.4); }
  .btn { display: inline-block; background: linear-gradient(135deg, #ff3355, #990022); color: white; padding: 12px 24px; border-radius: 12px; text-decoration: none; font-weight: bold; margin-top: 10px; cursor: pointer; border: none; }
</style>
</head>
<body>
<header>
  <h1>Ahsan Raza</h1>
  <p class="lead">Computer Science Student & Mobile AI Engineer based in Lahore, Pakistan</p>
  <div class="tags">
    <span class="tag">Android Compose</span>
    <span class="tag">Gemini AI</span>
    <span class="tag">Kotlin</span>
    <span class="tag">Full Stack</span>
  </div>
</header>
<div class="section">
  <div class="card">
    <h3 style="color:#ff9fb1; margin-top:0;">🚀 Featured Project: Juliet AI</h3>
    <p style="color:#d0949d; line-height:1.6;">A voice-first intelligent Android assistant integrating Gemini Live voice, live screen vision, WhatsApp auto-reply, smart reminders, and on-device photo sketch conversion.</p>
    <button class="btn" onclick="alert('Welcome to Juliet AI project showcase!')">View Details</button>
  </div>
</div>
</body>
</html>""",
                    type = "website",
                    language = "html",
                    timestamp = now - 3600_000L * 12
                ),
                SavedSnippet(
                    id = 2L,
                    title = "Android Compose Counter",
                    content = """@Composable
fun CounterWidget() {
    var count by remember { mutableIntStateOf(0) }
    Button(onClick = { count++ }) {
        Text("Count: ${'$'}count")
    }
}""",
                    type = "code",
                    language = "kotlin",
                    timestamp = now - 3600_000L * 8
                )
            )
            saveSnippets(initial)
            initial
        } else {
            val a = JSONArray(raw)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                SavedSnippet(
                    id = o.getLong("id"),
                    title = o.getString("title"),
                    content = o.getString("content"),
                    type = o.optString("type", "code"),
                    language = o.optString("language", ""),
                    timestamp = o.getLong("timestamp")
                )
            }
        }
    } catch (e: Exception) { emptyList() }

    fun saveSnippets(list: List<SavedSnippet>) {
        val a = JSONArray()
        list.take(60).forEach { s ->
            a.put(JSONObject().apply {
                put("id", s.id)
                put("title", s.title)
                put("content", s.content)
                put("type", s.type)
                put("language", s.language)
                put("timestamp", s.timestamp)
            })
        }
        put("saved_snippets", a.toString())
    }

    fun addOrUpdateSnippet(s: SavedSnippet) {
        val current = loadSnippets().toMutableList()
        val idx = current.indexOfFirst { it.id == s.id }
        if (idx >= 0) current[idx] = s else current.add(0, s)
        saveSnippets(current.take(60))
    }

    fun deleteSnippet(id: Long) {
        val current = loadSnippets().filter { it.id != id }
        saveSnippets(current)
    }

    // ---- Voice Profiles & Speaker Enrollment ----
    fun loadVoiceProfiles(): List<VoiceProfile> = try {
        val raw = get("voice_profiles", "[]")
        if (raw.isBlank() || raw == "[]") {
            emptyList()
        } else {
            val a = JSONArray(raw)
            (0 until a.length()).mapNotNull { i ->
                val o = a.getJSONObject(i)
                // Old builds shipped a fake hard-coded "owner_default" profile and a 20-dim
                // fake embedding. Both are invalid with the real engine: drop them.
                if (o.getString("id") == "owner_default") return@mapNotNull null
                val featArr = o.optJSONArray("features") ?: JSONArray()
                val feats = (0 until featArr.length()).map { j -> featArr.getDouble(j).toFloat() }
                val spArr = o.optJSONArray("spread") ?: JSONArray()
                val sp = (0 until spArr.length()).map { j -> spArr.getDouble(j).toFloat() }
                if (feats.size != com.juliet.ai.voice.SpeakerDsp.DIM || sp.size != feats.size) return@mapNotNull null
                VoiceProfile(
                    id = o.getString("id"),
                    name = o.getString("name"),
                    isOwner = o.optBoolean("isOwner", false),
                    sampleCount = o.optInt("sampleCount", 1),
                    enrolledAt = o.optLong("enrolledAt", System.currentTimeMillis()),
                    features = feats,
                    spread = sp,
                    phrase = o.optString("phrase", "Juliet")
                )
            }
        }
    } catch (e: Exception) { emptyList() }

    fun saveVoiceProfiles(list: List<VoiceProfile>) {
        val a = JSONArray()
        list.forEach { p ->
            val featArr = JSONArray()
            p.features.forEach { featArr.put(it.toDouble()) }
            val spArr = JSONArray()
            p.spread.forEach { spArr.put(it.toDouble()) }
            a.put(JSONObject().apply {
                put("spread", spArr)
                put("id", p.id)
                put("name", p.name)
                put("isOwner", p.isOwner)
                put("sampleCount", p.sampleCount)
                put("enrolledAt", p.enrolledAt)
                put("features", featArr)
                put("phrase", p.phrase)
            })
        }
        put("voice_profiles", a.toString())
    }

    fun addOrUpdateVoiceProfile(profile: VoiceProfile) {
        val current = loadVoiceProfiles().toMutableList()
        val idx = current.indexOfFirst { it.id == profile.id }
        if (idx >= 0) {
            current[idx] = profile
        } else {
            current.add(profile)
        }
        saveVoiceProfiles(current)
    }

    fun deleteVoiceProfile(id: String) {
        val current = loadVoiceProfiles().filter { it.id != id }
        saveVoiceProfiles(current)
    }
}

