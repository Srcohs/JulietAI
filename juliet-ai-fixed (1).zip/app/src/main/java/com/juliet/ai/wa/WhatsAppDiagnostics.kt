package com.juliet.ai.wa

/**
 * Live diagnostic tracking for Juliet's WhatsApp Auto-Reply bot.
 * Provides real-time visibility into incoming messages and response dispatch.
 */
object WhatsAppDiagnostics {
    @Volatile
    var isListenerConnected: Boolean = false

    @Volatile
    var lastCheckTime: Long = System.currentTimeMillis()

    @Volatile
    var lastReceivedSender: String = ""

    @Volatile
    var lastReceivedTime: Long = 0L

    @Volatile
    var lastReceivedText: String = ""

    @Volatile
    var lastReplySender: String = ""

    @Volatile
    var lastReplyText: String = ""

    @Volatile
    var lastReplyTime: Long = 0L

    @Volatile
    var lastStatus: String = "Bot initialized and waiting for messages"

    @Volatile
    var lastError: String? = null

    @Volatile
    var totalProcessed: Int = 0

    @Volatile
    var totalReplied: Int = 0

    fun recordIncoming(sender: String, text: String) {
        lastReceivedSender = sender
        lastReceivedText = text.take(150)
        lastReceivedTime = System.currentTimeMillis()
        totalProcessed++
    }

    fun recordReply(sender: String, reply: String) {
        lastReplySender = sender
        lastReplyText = reply.take(150)
        lastReplyTime = System.currentTimeMillis()
        lastStatus = "Reply sent successfully to $sender"
        lastError = null
        totalReplied++
    }

    fun recordStatus(status: String, error: String? = null) {
        lastStatus = status
        if (error != null) lastError = error
        lastCheckTime = System.currentTimeMillis()
    }
}
