package com.juliet.ai.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.juliet.ai.phone.AudioRoute
import com.juliet.ai.screen.JulietAccessibilityService
import com.juliet.ai.screen.JulietScreenCaptureService
import com.juliet.ai.screen.SharingState
import com.juliet.ai.vm.JulietViewModel

@Composable
fun ScreenControlScreen(vm: JulietViewModel) = Page("Screen Control", { vm.back() }) {
    val p = LocalPal.current
    val ctx = LocalContext.current
    val sharingState by vm.sharingState.collectAsState()
    val sharingErr by vm.sharingError.collectAsState()

    var query by remember { mutableStateOf("") }
    var consentDialog by remember { mutableStateOf(false) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        vm.permTick++
        vm.refreshAudioState()
    }
    val tick = vm.permTick

    val a11yReady = remember(tick) { JulietAccessibilityService.isRunning() }
    val fullControl = vm.isFullScreenControlEnabled()
    val sessionActive = vm.isControlSessionActive()

    val mediaProjectionManager = remember {
        ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    }

    val captureLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val serviceIntent = Intent(ctx, JulietScreenCaptureService::class.java).apply {
                action = JulietScreenCaptureService.ACTION_START
                putExtra(JulietScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(JulietScreenCaptureService.EXTRA_RESULT_DATA, result.data)
            }
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                ctx.startForegroundService(serviceIntent)
            } else {
                ctx.startService(serviceIntent)
            }
        } else {
            vm.toast = "Screen capture permission was not granted"
        }
    }

    Sub("Assist Ahsan with real-time screen navigation, visible text analysis, and live Gemini vision understanding.")

    // Status Banner
    val statusBg = when {
        sharingState == SharingState.Sharing -> J.Ok.copy(alpha = 0.15f)
        sharingState == SharingState.Paused -> J.Gold.copy(alpha = 0.15f)
        sessionActive -> J.Red.copy(alpha = 0.15f)
        else -> p.card
    }
    val statusText = when {
        sharingState == SharingState.Sharing -> "● Live Screen Sharing ACTIVE"
        sharingState == SharingState.Paused -> "⏸ Screen Sharing PAUSED"
        sessionActive -> "● Screen Control Session RUNNING"
        else -> "○ Screen Control Inactive"
    }
    val statusColor = when {
        sharingState == SharingState.Sharing -> J.Ok
        sharingState == SharingState.Paused -> J.Gold
        sessionActive -> J.Red
        else -> p.mu
    }

    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
            .background(statusBg).border(1.dp, statusColor.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
            .padding(16.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(statusColor))
                Text(statusText, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "Accessibility Service: ${if (a11yReady) "Enabled ✔" else "Disabled"}\n" +
                    "AI Vision Connection: ${if (vm.geminiKey().isNotBlank()) "Ready ✔" else "Needs Gemini Key"}\n" +
                    "Full Screen Control: ${if (fullControl) "Allowed" else "Off"}",
                color = p.mu, fontSize = 13.sp, lineHeight = 18.sp
            )
            sharingErr?.let {
                Spacer(Modifier.height(6.dp))
                Text("Error: $it", color = J.Red, fontSize = 13.sp)
            }
        }
    }

    Spacer(Modifier.height(14.dp))
    Sec("CONTROL SESSION")
    Group {
        ToggleItem(
            "⚡", "Enable Full Screen Control",
            "Allow Juliet to tap buttons, scroll, and assist in authorized apps",
            fullControl
        ) { vm.toggleFullScreenControl(it) }

        if (!sessionActive) {
            Item("▶", "Start Control Session", "Activates Juliet screen assistance") {
                vm.startControlSession()
            }
        } else {
            Item("⏹", "Stop Control Session", "Immediately halts all screen interactions") {
                vm.stopControlSession()
            }
        }

        Item(
            "♿", "Accessibility Service",
            if (a11yReady) "Granted - Juliet can read interface text" else "Tap to open Accessibility settings and enable Juliet"
        ) {
            ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    Spacer(Modifier.height(14.dp))
    Sec("LIVE SCREEN SHARING (GEMINI VISION)")
    Group {
        when (sharingState) {
            SharingState.Inactive -> {
                Item("📺", "Share Screen with Juliet", "Starts real-time screen understanding using Gemini Vision") {
                    consentDialog = true
                }
            }
            SharingState.Sharing -> {
                Item("⏸", "Pause Sharing", "Temporarily freeze screen capture transmission") {
                    vm.pauseScreenSharing()
                }
                Item("⏹", "Stop Sharing", "Stop live screen capture immediately") {
                    vm.stopScreenSharing()
                }
            }
            SharingState.Paused -> {
                Item("▶", "Resume Sharing", "Continue streaming frames to Juliet") {
                    vm.resumeScreenSharing()
                }
                Item("⏹", "Stop Sharing", "Stop live screen capture immediately") {
                    vm.stopScreenSharing()
                }
            }
        }
    }

    Spacer(Modifier.height(14.dp))
    Sec("ASK JULIET ABOUT YOUR SCREEN")
    OutlinedTextField(
        value = query,
        onValueChange = { query = it },
        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        placeholder = { Text("e.g. Juliet, what is showing on my screen?", color = p.mu) },
        shape = RoundedCornerShape(20.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = J.Red,
            unfocusedBorderColor = p.border,
            cursorColor = J.Crim,
            focusedTextColor = p.text,
            unfocusedTextColor = p.text
        )
    )

    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        SuggestionChip(
            onClick = { query = "Juliet, what is showing on my screen?" },
            label = { Text("What's on screen?", fontSize = 12.sp) }
        )
        SuggestionChip(
            onClick = { query = "Juliet, explain this screen" },
            label = { Text("Explain screen", fontSize = 12.sp) }
        )
        SuggestionChip(
            onClick = { query = "Juliet, find the setting I need" },
            label = { Text("Find setting", fontSize = 12.sp) }
        )
    }

    Spacer(Modifier.height(8.dp))
    GradientButton(
        text = if (vm.isVisionBusy) "Analyzing Screen…" else "Ask Juliet",
        modifier = Modifier.fillMaxWidth()
    ) {
        if (query.isNotBlank()) {
            vm.askScreenVision(query, speakOutput = true)
        }
    }

    vm.visionAnswer?.let { ans ->
        Spacer(Modifier.height(12.dp))
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                .background(p.card).border(1.dp, p.border, RoundedCornerShape(18.dp))
                .padding(14.dp)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Rounded.Visibility, "Vision", tint = J.Gold, modifier = Modifier.size(20.dp))
                    Text("Juliet's Screen Analysis", color = J.Gold, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(6.dp))
                Text(ans, color = p.text, fontSize = 15.sp, lineHeight = 22.sp)
            }
        }
    }

    Spacer(Modifier.height(16.dp))
    Sec("CALLING SPEAKER & VOLUME CONTROL")
    Group {
        ToggleItem(
            "🔊", "Speaker ON/OFF",
            "Current route: ${vm.currentAudioRoute.label}",
            vm.currentAudioRoute == AudioRoute.Speaker
        ) { vm.setSpeaker(it) }

        Item("📞", "Phone Earpiece", "Switch call audio to earpiece") {
            vm.setAudioRoute(AudioRoute.Earpiece)
        }
        Item("🎧", "Bluetooth Device", "Switch call audio to connected Bluetooth headset") {
            vm.setAudioRoute(AudioRoute.Bluetooth)
        }
        Item("🔈", "Call Volume: ${vm.currentCallVolume}", "Tap to adjust call volume") {
            vm.adjustCallVolume(true)
        }
    }

    if (consentDialog) {
        AlertDialog(
            onDismissRequest = { consentDialog = false },
            title = { Text("Start Live Screen Sharing?") },
            text = {
                Text(
                    "Juliet will capture frames of your screen to answer visual questions and guide you through apps using Gemini Vision. " +
                        "Sensitive fields such as passwords, OTPs, or banking PINs are never saved. " +
                        "A system permission prompt will appear to authorize screen capture. You can pause or stop sharing at any time."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    consentDialog = false
                    val captureIntent = mediaProjectionManager.createScreenCaptureIntent()
                    captureLauncher.launch(captureIntent)
                }) {
                    Text("Proceed", color = J.Red)
                }
            },
            dismissButton = {
                TextButton(onClick = { consentDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
