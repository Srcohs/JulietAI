package com.juliet.ai.reminders

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.juliet.ai.MainActivity
import com.juliet.ai.R
import com.juliet.ai.ann.Announcer
import com.juliet.ai.data.Prefs
import java.util.Calendar

class ReminderReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_TRIGGER = "com.juliet.ai.reminders.TRIGGER"
        const val ACTION_COMPLETE = "com.juliet.ai.reminders.COMPLETE"
        const val ACTION_SNOOZE = "com.juliet.ai.reminders.SNOOZE"

        const val EXTRA_ID = "reminder_id"
        const val EXTRA_TITLE = "reminder_title"
        const val EXTRA_RECURRENCE = "reminder_recurrence"

        const val CHANNEL_ID = "juliet_reminders"
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        val prefs = Prefs(ctx)
        val id = intent.getLongExtra(EXTRA_ID, 0L)
        val title = intent.getStringExtra(EXTRA_TITLE) ?: "Reminder"
        val recurrence = intent.getStringExtra(EXTRA_RECURRENCE) ?: "Once"

        when (intent.action) {
            ACTION_COMPLETE -> {
                val list = prefs.loadReminders().map {
                    if (it.id == id) it.copy(completed = true) else it
                }
                prefs.saveReminders(list)
                val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.cancel(id.toInt())
                return
            }
            ACTION_SNOOZE -> {
                val manager = ReminderManager(ctx, prefs)
                val snoozedTime = System.currentTimeMillis() + 10 * 60_000L
                val reminder = prefs.loadReminders().firstOrNull { it.id == id }?.copy(dueTimeMillis = snoozedTime)
                if (reminder != null) {
                    manager.scheduleAlarm(reminder)
                }
                val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.cancel(id.toInt())
                return
            }
            ACTION_TRIGGER -> {
                showNotification(ctx, id, title)

                // Voice announcement if enabled
                if (prefs.get("ann_on", "0") == "1") {
                    Announcer.speak(ctx, "Juliet reminder: $title", force = true)
                }

                // Handle recurrence
                val manager = ReminderManager(ctx, prefs)
                if (recurrence != "Once") {
                    val nextDue = calculateNextRecurrence(recurrence)
                    val reminder = prefs.loadReminders().firstOrNull { it.id == id }?.copy(dueTimeMillis = nextDue)
                    if (reminder != null) {
                        prefs.addOrUpdateReminder(reminder)
                        manager.scheduleAlarm(reminder)
                    }
                } else {
                    val list = prefs.loadReminders().map {
                        if (it.id == id) it.copy(completed = true) else it
                    }
                    prefs.saveReminders(list)
                }
            }
        }
    }

    private fun showNotification(ctx: Context, id: Long, title: String) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Smart Reminders",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alerts for Juliet scheduled reminders"
                enableVibration(true)
            }
            nm.createNotificationChannel(channel)
        }

        val openAppIntent = Intent(ctx, MainActivity::class.java)
        val openPending = PendingIntent.getActivity(
            ctx, id.toInt(), openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val completeIntent = Intent(ctx, ReminderReceiver::class.java).apply {
            action = ACTION_COMPLETE
            putExtra(EXTRA_ID, id)
        }
        val completePending = PendingIntent.getBroadcast(
            ctx, (id + 1000).toInt(), completeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val snoozeIntent = Intent(ctx, ReminderReceiver::class.java).apply {
            action = ACTION_SNOOZE
            putExtra(EXTRA_ID, id)
            putExtra(EXTRA_TITLE, title)
        }
        val snoozePending = PendingIntent.getBroadcast(
            ctx, (id + 2000).toInt(), snoozeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val n = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(R.drawable.juliet_emblem)
            .setContentTitle("Juliet Reminder")
            .setContentText(title)
            .setContentIntent(openPending)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .addAction(android.R.drawable.checkbox_on_background, "Mark Done", completePending)
            .addAction(android.R.drawable.ic_lock_idle_alarm, "Snooze 10m", snoozePending)
            .build()

        nm.notify(id.toInt(), n)
    }

    private fun calculateNextRecurrence(recurrence: String): Long {
        val cal = Calendar.getInstance()
        when (recurrence) {
            "Daily" -> cal.add(Calendar.DAY_OF_YEAR, 1)
            "Weekly" -> cal.add(Calendar.WEEK_OF_YEAR, 1)
            "Weekdays" -> {
                do {
                    cal.add(Calendar.DAY_OF_YEAR, 1)
                } while (cal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY || cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY)
            }
        }
        return cal.timeInMillis
    }
}
