package com.juliet.ai.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

// =========================================================================
// 1. LARGE TITLE SCAFFOLD (iOS Large Title Nav Bar)
// =========================================================================

/**
 * Native iOS Large Title Scaffold.
 * Displays a 34sp Bold Large Title that shrinks into an inline navigation bar
 * when the user scrolls, with a frosted glass navigation header and trailing action buttons.
 */
@Composable
fun LargeTitleScaffold(
    title: String,
    onBack: (() -> Unit)? = null,
    trailingActions: @Composable RowScope.() -> Unit = {},
    content: @Composable ColumnScope.() -> Unit
) {
    val scrollState = rememberScrollState()
    val colors = IOSTheme.colors
    val typography = IOSTheme.typography

    // Show compact title in top bar when scrolled past 40dp
    val showInlineTitle by remember {
        derivedStateOf { scrollState.value > 80 }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
    ) {
        // Scrollable Content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .statusBarsPadding()
                .padding(top = 56.dp, bottom = 120.dp, start = 16.dp, end = 16.dp)
        ) {
            // Large Title
            Text(
                text = title,
                style = typography.largeTitle,
                color = colors.text,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            )

            // Screen Content
            content()
        }

        // Frosted Top Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(colors.frostedBar)
                .statusBarsPadding()
                .height(52.dp)
                .border(
                    width = 0.5.dp,
                    color = if (showInlineTitle) colors.hairline else Color.Transparent
                )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Leading (Back Button)
                Box(modifier = Modifier.width(48.dp), contentAlignment = Alignment.CenterStart) {
                    if (onBack != null) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .clickable(onClick = onBack),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back",
                                tint = colors.systemBlue,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }

                // Inline Title (Cross-fades on scroll)
                AnimatedVisibility(
                    visible = showInlineTitle,
                    enter = fadeIn(tween(180)),
                    exit = fadeOut(tween(120))
                ) {
                    Text(
                        text = title,
                        style = typography.headline,
                        color = colors.text,
                        maxLines = 1
                    )
                }

                // Trailing Actions
                Row(
                    modifier = Modifier.widthIn(min = 48.dp),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically,
                    content = trailingActions
                )
            }
        }
    }
}

// =========================================================================
// 2. GROUPED SECTION & 3. GROUPED ROW (iOS TableView Style)
// =========================================================================

/**
 * iOS Grouped Section Container with optional uppercase header and footer caption.
 */
@Composable
fun GroupedSection(
    modifier: Modifier = Modifier,
    header: String? = null,
    footer: String? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val colors = IOSTheme.colors
    val typography = IOSTheme.typography

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        // Uppercase Header
        if (!header.isNullOrBlank()) {
            Text(
                text = header.uppercase(),
                style = typography.footnote,
                color = colors.textSecondary,
                modifier = Modifier.padding(start = 16.dp, bottom = 6.dp)
            )
        }

        // Inset Grouped Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(colors.card)
                .border(0.5.dp, colors.hairline, RoundedCornerShape(16.dp))
        ) {
            content()
        }

        // Footnote / Caption
        if (!footer.isNullOrBlank()) {
            Text(
                text = footer,
                style = typography.caption1,
                color = colors.textTertiary,
                modifier = Modifier.padding(start = 16.dp, top = 6.dp)
            )
        }
    }
}

/**
 * iOS Grouped Row item.
 * Supports:
 * - Icon: emoji or image vector in a colored rounded square or bare
 * - Title and optional subtitle/value
 * - Trailing accessory: Chevron, Switch, Value text, or Custom
 * - Hairline separator
 * - iOS touch press feedback without Material ripple
 */
@Composable
fun GroupedRow(
    title: String,
    subtitle: String? = null,
    value: String? = null,
    icon: @Composable (() -> Unit)? = null,
    trailingAccessory: @Composable (() -> Unit)? = { IOSChevron() },
    showDivider: Boolean = true,
    onClick: (() -> Unit)? = null
) {
    val colors = IOSTheme.colors
    val typography = IOSTheme.typography
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val rowAlpha by animateFloatAsState(
        targetValue = if (isPressed && onClick != null) 0.6f else 1f,
        label = "ios_row_press"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (onClick != null) {
                    Modifier.clickable(
                        interactionSource = interactionSource,
                        indication = null,
                        onClick = onClick
                    )
                } else Modifier
            )
            .alpha(rowAlpha)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Icon slot
            if (icon != null) {
                Box(
                    modifier = Modifier.size(30.dp),
                    contentAlignment = Alignment.Center
                ) {
                    icon()
                }
            }

            // Title & Subtitle
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = typography.body,
                    color = colors.text
                )
                if (!subtitle.isNullOrBlank()) {
                    Text(
                        text = subtitle,
                        style = typography.footnote,
                        color = colors.textSecondary,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }

            // Value text
            if (!value.isNullOrBlank()) {
                Text(
                    text = value,
                    style = typography.body,
                    color = colors.textSecondary
                )
            }

            // Trailing Accessory
            if (trailingAccessory != null) {
                trailingAccessory()
            }
        }

        // Hairline Divider
        if (showDivider) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = if (icon != null) 58.dp else 16.dp)
                    .height(0.5.dp)
                    .background(colors.hairline)
            )
        }
    }
}

/**
 * Standard iOS rounded icon container (colored square with rounded corners).
 */
@Composable
fun IOSIconBox(
    backgroundColor: Color,
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .size(30.dp)
            .clip(RoundedCornerShape(7.dp))
            .background(backgroundColor),
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}

@Composable
fun IOSChevron() {
    Icon(
        imageVector = Icons.Rounded.ChevronRight,
        contentDescription = null,
        tint = IOSTheme.colors.textTertiary,
        modifier = Modifier.size(20.dp)
    )
}

// =========================================================================
// 4. IOS SWITCH (Exact Apple HIG Toggle)
// =========================================================================

/**
 * Native Apple HIG Switch.
 * 51x31dp container, smooth sliding 27dp thumb, green (#34C759) or accent active track,
 * dark gray (#39393D) inactive track, with spring physics.
 */
@Composable
fun IOSSwitch(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    activeColor: Color = IOSColors.Green,
    inactiveColor: Color = Color(0xFF39393D)
) {
    val thumbOffset by animateDpAsState(
        targetValue = if (checked) 22.dp else 2.dp,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "ios_switch_thumb"
    )

    Box(
        modifier = modifier
            .size(width = 51.dp, height = 31.dp)
            .clip(CircleShape)
            .background(if (checked) activeColor else inactiveColor)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onCheckedChange(!checked) }
            .padding(2.dp)
    ) {
        Box(
            modifier = Modifier
                .offset(x = thumbOffset)
                .size(27.dp)
                .shadow(elevation = 3.dp, shape = CircleShape)
                .clip(CircleShape)
                .background(Color.White)
        )
    }
}

// =========================================================================
// 5. SEGMENTED CONTROL (iOS Sliding Pill Picker)
// =========================================================================

/**
 * iOS Segmented Control.
 * Sliding selection indicator with soft shadow, active label contrast, and spring motion.
 */
@Composable
fun SegmentedControl(
    items: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = IOSTheme.colors
    val typography = IOSTheme.typography

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .height(38.dp)
            .clip(RoundedCornerShape(9.dp))
            .background(colors.cardSecondary)
            .padding(2.dp)
    ) {
        val segmentWidth = maxWidth / items.size
        val indicatorOffset by animateDpAsState(
            targetValue = segmentWidth * selectedIndex,
            animationSpec = spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMedium),
            label = "segment_indicator"
        )

        // Sliding Active Indicator
        Box(
            modifier = Modifier
                .offset(x = indicatorOffset)
                .width(segmentWidth)
                .fillMaxHeight()
                .shadow(2.dp, RoundedCornerShape(7.dp))
                .clip(RoundedCornerShape(7.dp))
                .background(if (colors.isDark) Color(0xFF322A48) else Color.White)
        )

        // Items Row
        Row(modifier = Modifier.fillMaxSize()) {
            items.forEachIndexed { index, item ->
                val isSelected = index == selectedIndex
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onSelect(index) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = item,
                        style = typography.subheadline,
                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                        color = if (isSelected) colors.text else colors.textSecondary
                    )
                }
            }
        }
    }
}

// =========================================================================
// 6. BOTTOM SHEET (iOS Modal Sheet with Drag Handle)
// =========================================================================

/**
 * iOS Style Modal Bottom Sheet with translucent blurred backdrop and top centered drag handle.
 */
@Composable
fun IOSBottomSheet(
    visible: Boolean,
    onDismiss: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    val colors = IOSTheme.colors

    if (visible) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.5f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onDismiss
                ),
            contentAlignment = Alignment.BottomCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = {} // Intercept clicks so sheet doesn't close
                    )
                    .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                    .background(colors.sheetBackground)
                    .border(
                        0.5.dp,
                        colors.hairline,
                        RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
                    )
                    .navigationBarsPadding()
                    .padding(bottom = 16.dp)
            ) {
                // Drag Handle
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp, bottom = 14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(width = 36.dp, height = 5.dp)
                            .clip(CircleShape)
                            .background(colors.textTertiary.copy(alpha = 0.4f))
                    )
                }

                content()
            }
        }
    }
}

// =========================================================================
// 7. ACTION SHEET (iOS Action Sheet Dialog)
// =========================================================================

data class ActionSheetItem(
    val title: String,
    val isDestructive: Boolean = false,
    val onClick: () -> Unit
)

/**
 * Native iOS Action Sheet with grouped actions and separate Cancel button.
 */
@Composable
fun IOSActionSheet(
    visible: Boolean,
    title: String? = null,
    message: String? = null,
    actions: List<ActionSheetItem>,
    cancelText: String = "Cancel",
    onDismiss: () -> Unit
) {
    val colors = IOSTheme.colors
    val typography = IOSTheme.typography

    if (visible) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.55f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onDismiss
                )
                .padding(horizontal = 10.dp, vertical = 14.dp)
                .navigationBarsPadding(),
            contentAlignment = Alignment.BottomCenter
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Actions Container
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(colors.card)
                        .border(0.5.dp, colors.hairline, RoundedCornerShape(14.dp))
                ) {
                    // Header Description
                    if (!title.isNullOrBlank() || !message.isNullOrBlank()) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            if (!title.isNullOrBlank()) {
                                Text(
                                    text = title,
                                    style = typography.footnote,
                                    fontWeight = FontWeight.SemiBold,
                                    color = colors.textSecondary
                                )
                            }
                            if (!message.isNullOrBlank()) {
                                Text(
                                    text = message,
                                    style = typography.caption1,
                                    color = colors.textTertiary,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(0.5.dp)
                                .background(colors.hairline)
                        )
                    }

                    // Action Rows
                    actions.forEachIndexed { index, action ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    action.onClick()
                                    onDismiss()
                                }
                                .padding(vertical = 16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = action.title,
                                style = typography.title3,
                                color = if (action.isDestructive) colors.systemRed else colors.systemBlue
                            )
                        }

                        if (index < actions.size - 1) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(0.5.dp)
                                    .background(colors.hairline)
                            )
                        }
                    }
                }

                // Separate Cancel Button
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(colors.card)
                        .border(0.5.dp, colors.hairline, RoundedCornerShape(14.dp))
                        .clickable(onClick = onDismiss)
                        .padding(vertical = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = cancelText,
                        style = typography.title3,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.systemBlue
                    )
                }
            }
        }
    }
}

// =========================================================================
// 8. SWIPE ACTION ROW (iOS Swipe to Reveal: Pin / Delete)
// =========================================================================

/**
 * iOS Table row with swipe-to-reveal action buttons (Pin / Delete).
 */
@Composable
fun SwipeActionRow(
    onDelete: () -> Unit,
    onPin: (() -> Unit)? = null,
    isPinned: Boolean = false,
    content: @Composable () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val density = LocalDensity.current
    val maxSwipePx = with(density) { (if (onPin != null) 140.dp else 70.dp).toPx() }
    val offsetX = remember { Animatable(0f) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
    ) {
        // Background Actions revealed on swipe
        Row(
            modifier = Modifier
                .matchParentSize()
                .padding(end = 2.dp),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (onPin != null) {
                Box(
                    modifier = Modifier
                        .width(70.dp)
                        .fillMaxHeight()
                        .background(IOSColors.Orange)
                        .clickable {
                            coroutineScope.launch { offsetX.animateTo(0f) }
                            onPin()
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.PushPin,
                        contentDescription = "Pin",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Box(
                modifier = Modifier
                    .width(70.dp)
                    .fillMaxHeight()
                    .background(IOSColors.Red)
                    .clickable {
                        coroutineScope.launch { offsetX.animateTo(0f) }
                        onDelete()
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.Delete,
                    contentDescription = "Delete",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        // Foreground Content
        Box(
            modifier = Modifier
                .offset { IntOffset(offsetX.value.roundToInt(), 0) }
                .fillMaxWidth()
                .background(IOSTheme.colors.card)
                .draggable(
                    state = rememberDraggableState { delta ->
                        val target = (offsetX.value + delta).coerceIn(-maxSwipePx, 0f)
                        coroutineScope.launch { offsetX.snapTo(target) }
                    },
                    orientation = Orientation.Horizontal,
                    onDragStopped = {
                        val snapTo = if (offsetX.value < -maxSwipePx / 2) -maxSwipePx else 0f
                        coroutineScope.launch {
                            offsetX.animateTo(snapTo, spring(stiffness = Spring.StiffnessMedium))
                        }
                    }
                )
        ) {
            content()
        }
    }
}

// =========================================================================
// 9. GLASS CARD (iOS Translucent Glass Surface)
// =========================================================================

/**
 * Translucent Glass Card with subtle border hairline and optional gradient.
 */
@Composable
fun IOSGlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(18.dp),
    backgroundColor: Color = IOSTheme.colors.card.copy(alpha = 0.82f),
    borderColor: Color = IOSTheme.colors.hairline,
    borderWidth: Dp = 0.5.dp,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .clip(shape)
            .background(backgroundColor)
            .border(borderWidth, borderColor, shape),
        content = content
    )
}

// =========================================================================
// 10. TAB BAR (iOS Bottom Navigation Bar)
// =========================================================================

data class IOSTabItem(
    val title: String,
    val icon: ImageVector,
    val badgeCount: Int = 0
)

/**
 * Native iOS Tab Bar with translucent frosted background and hairline border.
 */
@Composable
fun IOSTabBar(
    tabs: List<IOSTabItem>,
    selectedIndex: Int,
    onTabSelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = IOSTheme.colors
    val typography = IOSTheme.typography

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(colors.frostedBar)
            .border(width = 0.5.dp, color = colors.hairline)
            .navigationBarsPadding()
            .height(54.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            tabs.forEachIndexed { index, tab ->
                val isSelected = index == selectedIndex
                val tint = if (isSelected) colors.accentPink else colors.textTertiary

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onTabSelected(index) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box {
                        Icon(
                            imageVector = tab.icon,
                            contentDescription = tab.title,
                            tint = tint,
                            modifier = Modifier.size(24.dp)
                        )
                        if (tab.badgeCount > 0) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .offset(x = 6.dp, y = (-4).dp)
                                    .size(16.dp)
                                    .clip(CircleShape)
                                    .background(colors.systemRed),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (tab.badgeCount > 9) "9+" else tab.badgeCount.toString(),
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = tab.title,
                        style = typography.caption2,
                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                        color = tint
                    )
                }
            }
        }
    }
}
