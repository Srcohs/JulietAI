package com.juliet.ai.wa

import android.app.Notification
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.juliet.ai.ann.Announcer
import com.juliet.ai.data.Prefs
import com.juliet.ai.phone.ContactNames

/**
 * Listens for incoming notifications to power real-time female voice announcements
 * and WhatsApp private chat auto-replies.
 */
class JulietNotificationService : NotificationListenerService() {
    private lateinit var prefs: Prefs
    private lateinit var auto: AutoReply
    private val spoken = LinkedHashSet<String>()
    private val handler = Handler(Looper.getMainLooper())

    private val wa = setOf("com.whatsapp", "com.whatsapp.w4b")
    private val sms = setOf("com.google.android.apps.messaging", "com.android.mms", "com.samsung.android.messaging", "com.android.messaging")

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(applicationContext)
        auto = AutoReply(applicationContext, prefs)
        WhatsAppDiagnostics.isListenerConnected = true
        WhatsAppDiagnostics.recordStatus("Notification listener active")
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        WhatsAppDiagnostics.isListenerConnected = true
        WhatsAppDiagnostics.recordStatus("Notification listener connected to Android system")
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        WhatsAppDiagnostics.isListenerConnected = false
        WhatsAppDiagnostics.recordStatus("Notification listener disconnected", "Service disconnected by system")
    }

    override fun onDestroy() {
        WhatsAppDiagnostics.isListenerConnected = false
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            WhatsAppDiagnostics.lastCheckTime = System.currentTimeMillis()
            process(sbn)
        } catch (_: Exception) {
            // Never crash the system notification listener
        }
    }



    override fun onNotificationRemoved(sbn: StatusBarNotification, rankingMap: RankingMap, reason: Int) {
        try {
            if (sbn.packageName in wa && (reason == REASON_CLICK || reason == REASON_CANCEL)) {
                Incoming.parse(sbn)?.let { if (it.sender.isNotBlank()) auto.markManual(it.sender) }
            }
        } catch (_: Exception) { }
    }

    private fun process(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification ?: return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if ((n.flags and Notification.FLAG_ONGOING_EVENT) != 0) return
        val inc = Incoming.parse(sbn) ?: return

        // Log notification for Juliet Summaries (redacting OTPs)
        if (inc.sender.isNotBlank() || inc.text.isNotBlank()) {
            val appLabel = try {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(inc.pkg, 0)).toString()
            } catch (_: Exception) {
                if (inc.pkg in wa) "WhatsApp" else if (inc.pkg in sms) "SMS" else "App"
            }

            val safeLoggedText = if (Announcer.containsSensitiveCode(inc.text)) {
                "[Sensitive authentication code hidden for privacy]"
            } else {
                inc.text
            }

            prefs.addNotification(
                com.juliet.ai.data.LoggedNotification(
                    id = inc.id,
                    pkg = inc.pkg,
                    appName = appLabel,
                    sender = inc.sender,
                    text = safeLoggedText,
                    time = inc.time,
                    isWhatsApp = inc.pkg in wa
                )
            )
        }

        // WhatsApp Auto-Reply: Active when user enabled wa_auto
        if (inc.pkg in wa && prefs.get("wa_auto", "0") == "1") {
            auto.handle(inc)
        }

        // Voice announcements
        if (prefs.get("ann_on", "0") == "1") {
            announce(inc, n)
        }
    }

    private fun announce(inc: Incoming, n: Notification) {
        val c = n.category
        if (c == Notification.CATEGORY_PROGRESS || c == Notification.CATEGORY_SERVICE || c == Notification.CATEGORY_TRANSPORT ||
            c == Notification.CATEGORY_CALL || c == Notification.CATEGORY_STATUS) return

        val isWa = inc.pkg in wa
        val isSms = inc.pkg in sms
        val allowed = when {
            isWa -> prefs.get("ann_wa", "1") == "1"
            isSms -> prefs.get("ann_sms", "1") == "1"
            else -> prefs.get("ann_apps", "0") == "1" && inc.pkg in prefs.get("ann_pkgs").split(",")
        }
        if (!allowed) return
        if (inc.sender.isBlank() && inc.text.isBlank()) return
        if ((isWa || isSms) && !inc.fromOther) return // Never read outgoing messages

        synchronized(spoken) {
            if (!spoken.add(inc.id)) return
            if (spoken.size > 300) spoken.remove(spoken.first())
        }

        val who = if (ContactNames.looksLikeNumber(inc.sender)) {
            ContactNames.forNumber(this, inc.sender) ?: "an unknown contact"
        } else inc.sender

        val excluded = prefs.get("ann_excl").split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        if (excluded.any { who.lowercase().contains(it) }) return

        val showText = prefs.get("ann_content", "0") == "1" && prefs.get("ann_privacy", "1") != "1" && inc.text.isNotBlank()

        val textToSpeak = when {
            isWa && inc.isGroup -> "New WhatsApp group message" + (inc.groupTitle?.let { " in $it" } ?: "") + "."
            isWa -> if (showText) "WhatsApp message from $who: ${inc.text.take(180)}" else "New WhatsApp message from $who."
            isSms -> if (showText) "Message from $who: ${inc.text.take(180)}" else "New message from $who."
            else -> {
                val app = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(inc.pkg, 0)).toString() } catch (_: Exception) { "an app" }
                if (showText && inc.sender.isNotBlank()) "$app: ${inc.sender}" else "New notification from $app."
            }
        }

        val vol = (prefs.get("ann_vol", "100").toFloatOrNull() ?: 100f) / 100f
        Announcer.speak(applicationContext, textToSpeak, vol)

        if (prefs.get("ann_repeat", "0") == "1") {
            handler.postDelayed({ Announcer.speak(applicationContext, textToSpeak, vol) }, 15_000)
        }
    }
}
