package com.juliet.ai.phone

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract.PhoneLookup

/** Saved-contact name for a phone number. Returns null if not saved or Contacts permission is missing. Never guesses. */
object ContactNames {
    fun forNumber(ctx: Context, number: String?): String? {
        if (number.isNullOrBlank()) return null
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        return try {
            val uri = Uri.withAppendedPath(PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            ctx.contentResolver.query(uri, arrayOf(PhoneLookup.DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (e: Exception) { null }
    }

    fun looksLikeNumber(s: String): Boolean = s.count { it.isDigit() } >= 7 && s.all { it.isDigit() || it in "+ -()" }
}
