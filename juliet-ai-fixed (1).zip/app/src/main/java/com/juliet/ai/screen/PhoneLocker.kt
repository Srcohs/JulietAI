package com.juliet.ai.screen

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context

/** Device-admin receiver: only used as a fallback to lock the phone (Android < 9 or no a11y). */
class JulietAdminReceiver : DeviceAdminReceiver()

object PhoneLocker {
    fun adminComponent(ctx: Context) = ComponentName(ctx, JulietAdminReceiver::class.java)

    fun isAdminActive(ctx: Context): Boolean {
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return dpm.isAdminActive(adminComponent(ctx))
    }

    /** Locks the phone. Tries Accessibility first, then Device Admin. Returns true if a lock was issued. */
    fun lockNow(ctx: Context): Boolean {
        if (JulietAccessibilityService.instance?.lockScreen() == true) return true
        return try {
            val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            if (dpm.isAdminActive(adminComponent(ctx))) { dpm.lockNow(); true } else false
        } catch (_: Exception) { false }
    }
}
