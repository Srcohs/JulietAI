package com.juliet.ai.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Brand color definitions and glass-morphism styling utilities for Juliet AI.
 */
object ThemeConstants {
    // ---- Brand Colors ----
    /** Deep Burgundy brand color (#800020) */
    val Burgundy = Color(0xFF800020)

    /** Vibrant Neon Pink brand accent (#FF007F) */
    val NeonPink = Color(0xFFFF007F)

    // Extended shades for depth and gradients in dark theme
    val BurgundyDark = Color(0xFF4A0013)
    val BurgundyDeep = Color(0xFF26000A)
    val BurgundySurface = Color(0xFF16040A)
    val BurgundyBackground = Color(0xFF070205)

    val NeonPinkLight = Color(0xFFFF3399)
    val NeonPinkGlow = Color(0xFFFF007F).copy(alpha = 0.35f)
    val NeonPinkSubtle = Color(0xFFFF80BF)

    // Common Gradients
    val BrandGradient = Brush.linearGradient(
        listOf(Burgundy, NeonPink)
    )

    val GlassSurfaceGradient = Brush.verticalGradient(
        listOf(
            BurgundySurface.copy(alpha = 0.85f),
            BurgundyDeep.copy(alpha = 0.65f)
        )
    )

    val GlassBorderGradient = Brush.linearGradient(
        listOf(
            NeonPink.copy(alpha = 0.55f),
            Burgundy.copy(alpha = 0.35f),
            NeonPink.copy(alpha = 0.20f)
        )
    )
}

/**
 * Extension modifier to apply a translucent glass-morphism backdrop and border
 * tailored for Juliet AI's dark theme.
 */
fun Modifier.glassmorphism(
    shape: Shape = RoundedCornerShape(24.dp),
    backgroundColor: Color = ThemeConstants.BurgundySurface.copy(alpha = 0.78f),
    borderColor: Color = ThemeConstants.NeonPink.copy(alpha = 0.28f),
    borderWidth: Dp = 1.dp
): Modifier = this
    .clip(shape)
    .background(backgroundColor)
    .border(borderWidth, borderColor, shape)

/**
 * Extension modifier that applies a glass-morphism style with a multi-stop neon gradient border.
 */
fun Modifier.glassmorphismGradient(
    shape: Shape = RoundedCornerShape(24.dp),
    backgroundBrush: Brush = ThemeConstants.GlassSurfaceGradient,
    borderBrush: Brush = ThemeConstants.GlassBorderGradient,
    borderWidth: Dp = 1.dp
): Modifier = this
    .clip(shape)
    .background(backgroundBrush)
    .border(borderWidth, borderBrush, shape)

/**
 * Material 3 Surface wrapper providing a glass-morphism container with
 * translucent surface color, tonal elevation, and neon pink border stroke.
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(24.dp),
    color: Color = ThemeConstants.BurgundySurface.copy(alpha = 0.78f),
    contentColor: Color = MaterialTheme.colorScheme.onSurface,
    border: BorderStroke? = BorderStroke(1.dp, ThemeConstants.NeonPink.copy(alpha = 0.28f)),
    tonalElevation: Dp = 2.dp,
    shadowElevation: Dp = 0.dp,
    content: @Composable () -> Unit
) {
    Surface(
        modifier = modifier,
        shape = shape,
        color = color,
        contentColor = contentColor,
        tonalElevation = tonalElevation,
        shadowElevation = shadowElevation,
        border = border,
        content = content
    )
}

/**
 * Helper Glass Card composable providing an idiomatic translucent container
 * with gradient background and subtle border.
 */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(24.dp),
    backgroundBrush: Brush = ThemeConstants.GlassSurfaceGradient,
    borderBrush: Brush = ThemeConstants.GlassBorderGradient,
    borderWidth: Dp = 1.dp,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .clip(shape)
            .background(backgroundBrush)
            .border(borderWidth, borderBrush, shape),
        content = content
    )
}
