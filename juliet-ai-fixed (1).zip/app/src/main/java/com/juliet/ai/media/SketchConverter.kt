package com.juliet.ai.media

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min

enum class SketchStyle(val label: String) {
    Pencil("Pencil Sketch"),
    Charcoal("Charcoal Art"),
    ColorPencil("Colored Pencil"),
    LineArt("Line Drawing"),
    AiSketch("AI Gemini Sketch")
}

object SketchConverter {

    suspend fun loadBitmapFromUri(ctx: Context, uri: Uri, maxDim: Int = 1080): Bitmap? = withContext(Dispatchers.IO) {
        try {
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, options)
            }

            var scale = 1
            while (options.outWidth / scale > maxDim || options.outHeight / scale > maxDim) {
                scale *= 2
            }

            val decodeOpts = BitmapFactory.Options().apply { inSampleSize = scale }
            ctx.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, decodeOpts)
            }
        } catch (e: Exception) {
            null
        }
    }

    suspend fun processSketch(
        src: Bitmap,
        style: SketchStyle = SketchStyle.Pencil,
        blurRadius: Int = 6,
        contrast: Float = 1.0f
    ): Bitmap = withContext(Dispatchers.Default) {
        val width = src.width
        val height = src.height
        val size = width * height

        val pixels = IntArray(size)
        src.getPixels(pixels, 0, width, 0, 0, width, height)

        val gray = IntArray(size)
        val inverted = IntArray(size)

        for (i in 0 until size) {
            val c = pixels[i]
            val r = (c shr 16) and 0xFF
            val g = (c shr 8) and 0xFF
            val b = c and 0xFF
            val y = (0.299 * r + 0.587 * g + 0.114 * b).toInt().coerceIn(0, 255)
            gray[i] = y
            inverted[i] = 255 - y
        }

        val blurred = fastBoxBlur(inverted, width, height, blurRadius.coerceIn(2, 20))
        val outputPixels = IntArray(size)

        for (i in 0 until size) {
            val base = gray[i]
            val blend = blurred[i]

            // Color Dodge algorithm
            var dodge = if (blend >= 255) 255 else ((base shl 8) / (255 - blend)).coerceAtMost(255)

            when (style) {
                SketchStyle.Pencil -> {
                    if (contrast != 1.0f) {
                        dodge = applyContrast(dodge, contrast)
                    }
                    outputPixels[i] = (0xFF shl 24) or (dodge shl 16) or (dodge shl 8) or dodge
                }
                SketchStyle.Charcoal -> {
                    // Deepen darks and sharpen sketch
                    var charc = applyContrast(dodge, max(1.2f, contrast * 1.3f))
                    if (charc < 140) charc = (charc * 0.75f).toInt()
                    outputPixels[i] = (0xFF shl 24) or (charc shl 16) or (charc shl 8) or charc
                }
                SketchStyle.ColorPencil -> {
                    // Blend sketch lightness with original colors
                    val orig = pixels[i]
                    val or = (orig shr 16) and 0xFF
                    val og = (orig shr 8) and 0xFF
                    val ob = orig and 0xFF
                    val factor = dodge / 255f
                    val nr = (or * factor).toInt().coerceIn(0, 255)
                    val ng = (og * factor).toInt().coerceIn(0, 255)
                    val nb = (ob * factor).toInt().coerceIn(0, 255)
                    outputPixels[i] = (0xFF shl 24) or (nr shl 16) or (ng shl 8) or nb
                }
                SketchStyle.LineArt -> {
                    // High-contrast line art
                    val line = if (dodge < 185) (dodge * 0.5f).toInt() else 255
                    outputPixels[i] = (0xFF shl 24) or (line shl 16) or (line shl 8) or line
                }
                SketchStyle.AiSketch -> {
                    // High-definition graphite sketch fallback
                    var aiDodge = applyContrast(dodge, max(1.15f, contrast * 1.2f))
                    if (aiDodge < 130) aiDodge = (aiDodge * 0.8f).toInt()
                    outputPixels[i] = (0xFF shl 24) or (aiDodge shl 16) or (aiDodge shl 8) or aiDodge
                }
            }
        }

        Bitmap.createBitmap(outputPixels, width, height, Bitmap.Config.ARGB_8888)
    }

    private fun applyContrast(value: Int, contrast: Float): Int {
        val norm = value / 255f
        val adjusted = ((norm - 0.5f) * contrast + 0.5f).coerceIn(0f, 1f)
        return (adjusted * 255).toInt()
    }

    private fun fastBoxBlur(input: IntArray, w: Int, h: Int, r: Int): IntArray {
        val size = w * h
        val hBlurred = IntArray(size)
        val vBlurred = IntArray(size)

        // Horizontal pass
        for (y in 0 until h) {
            val yOffset = y * w
            for (x in 0 until w) {
                var sum = 0
                var count = 0
                for (k in -r..r) {
                    val px = (x + k).coerceIn(0, w - 1)
                    sum += input[yOffset + px]
                    count++
                }
                hBlurred[yOffset + x] = sum / count
            }
        }

        // Vertical pass
        for (x in 0 until w) {
            for (y in 0 until h) {
                var sum = 0
                var count = 0
                for (k in -r..r) {
                    val py = (y + k).coerceIn(0, h - 1)
                    sum += hBlurred[py * w + x]
                    count++
                }
                vBlurred[y * w + x] = sum / count
            }
        }
        return vBlurred
    }

    suspend fun saveBitmapToGallery(ctx: Context, bitmap: Bitmap, title: String): Uri? = withContext(Dispatchers.IO) {
        val fileName = "Juliet_Sketch_${System.currentTimeMillis()}.jpg"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/JulietSketches")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }

        val resolver = ctx.contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return@withContext null

        try {
            resolver.openOutputStream(uri)?.use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
            }
            uri
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            null
        }
    }

    suspend fun saveBitmapToCache(ctx: Context, bitmap: Bitmap): Uri? = withContext(Dispatchers.IO) {
        try {
            val cacheDir = File(ctx.cacheDir, "sketches").apply { mkdirs() }
            val file = File(cacheDir, "sketch_${System.currentTimeMillis()}.jpg")
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
            }
            FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
        } catch (e: Exception) {
            // Fallback file URI
            try {
                val file = File(ctx.cacheDir, "temp_sketch.jpg")
                FileOutputStream(file).use { out -> bitmap.compress(Bitmap.CompressFormat.JPEG, 85, out) }
                Uri.fromFile(file)
            } catch (_: Exception) {
                null
            }
        }
    }
}
