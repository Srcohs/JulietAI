package com.juliet.ai.ann

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.telephony.TelephonyManager
import com.juliet.ai.data.Prefs
import com.juliet.ai.phone.ContactNames

/** Announces an incoming call once. The caller's number is only delivered by Android if READ_CALL_LOG is granted. */
class CallReceiver : BroadcastReceiver() {
    companion object {
        private var announced = false
        private val handler = Handler(Looper.getMainLooper())
        private var fallback: Runnable? = null

        private fun announce(ctx: Context, number: String?) {
            if (announced) return
            announced = true
            fallback?.let { handler.removeCallbacks(it) }
            val prefs = Prefs(ctx)
            val name = ContactNames.forNumber(ctx, number)
            val excluded = prefs.get("ann_excl").split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
            if (name != null && excluded.any { name.lowercase().contains(it) }) return
            val text = when {
                name != null -> "Incoming call from $name."
                !number.isNullOrBlank() -> "Incoming call from an unknown number."
                else -> "Incoming call."
            }
            Announcer.speak(ctx, text, (prefs.get("ann_vol", "100").toFloatOrNull() ?: 100f) / 100f)
        }
    }

    @Suppress("DEPRECATION")
    override fun onReceive(ctx: Context, i: Intent) {
        if (i.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        val state = i.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return


        if (state != TelephonyManager.EXTRA_STATE_RINGING) {
            announced = false
            fallback?.let { handler.removeCallbacks(it) }
            return
        }
        val prefs = Prefs(ctx)
        if (prefs.get("ann_on", "0") != "1" || prefs.get("ann_calls", "1") != "1" || announced) return
        val number = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
        val canSeeNumber = ctx.checkSelfPermission(Manifest.permission.READ_CALL_LOG) == PackageManager.PERMISSION_GRANTED
        if (number.isNullOrBlank() && canSeeNumber) {
            // Android sends RINGING twice; the second one carries the number. Wait briefly for it.
            val app = ctx.applicationContext
            fallback = Runnable { announce(app, null) }
            handler.postDelayed(fallback!!, 1500)
            return
        }
        announce(ctx.applicationContext, number)
    }
}
