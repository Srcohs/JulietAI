package com.juliet.ai.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.juliet.ai.data.Screen
import kotlin.random.Random

// =========================================================================
// iOS DESIGN SYSTEM COMPONENTS FOR JULIET AI
// Preserves exact function signatures so existing screens render in pure iOS HIG style.
// =========================================================================

@Composable
fun SquareBtn(icon: ImageVector, desc: String, onClick: () -> Unit) {
    val p = LocalPal.current
    val sh = RoundedCornerShape(12.dp)
    Box(
        modifier = Modifier
            .size(42.dp)
            .clip(sh)
            .background(p.card)
            .border(0.5.dp, p.hairline, sh)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, desc, tint = J.Blue, modifier = Modifier.size(22.dp))
    }
}

@Composable
fun Header(title: String, onBack: (() -> Unit)?) {
    val p = LocalPal.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (onBack != null) SquareBtn(Icons.AutoMirrored.Rounded.ArrowBack, "Back", onBack)
        Text(title, color = p.text, fontSize = 28.sp, fontWeight = FontWeight.Bold)
    }
}

/**
 * iOS Large Title Page.
 * Renders a 34sp Bold title that collapses smoothly into a frosted header bar on scroll.
 */
@Composable
fun Page(title: String, onBack: (() -> Unit)?, content: @Composable ColumnScope.() -> Unit) {
    val scrollState = rememberScrollState()
    val p = LocalPal.current
    val showInlineTitle by remember { derivedStateOf { scrollState.value > 70 } }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(p.bg)
    ) {
        // Scrollable content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .statusBarsPadding()
                .padding(top = 54.dp, bottom = 120.dp, start = 16.dp, end = 16.dp)
        ) {
            // iOS Large Title (34sp Bold)
            Text(
                text = title,
                color = p.text,
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.37.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            )
            content()
        }

        // Frosted iOS Navigation Top Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(p.nav)
                .statusBarsPadding()
                .height(52.dp)
                .border(
                    width = 0.5.dp,
                    color = if (showInlineTitle) p.hairline else Color.Transparent
                )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Leading back button
                Box(modifier = Modifier.width(44.dp), contentAlignment = Alignment.CenterStart) {
                    if (onBack != null) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .clickable(
                                    interactionSource = remember { MutableInteractionSource() },
                                    indication = null,
                                    onClick = onBack
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back",
                                tint = J.Blue,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }

                // Inline title (visible on scroll)
                AnimatedVisibility(
                    visible = showInlineTitle,
                    enter = fadeIn(tween(160)),
                    exit = fadeOut(tween(120))
                ) {
                    Text(
                        text = title,
                        color = p.text,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold,
                        letterSpacing = (-0.41).sp,
                        maxLines = 1
                    )
                }

                // Trailing empty spacer for symmetry
                Spacer(modifier = Modifier.width(44.dp))
            }
        }
    }
}

/**
 * iOS Subtitle/Footnote.
 */
@Composable
fun Sub(t: String) {
    Text(
        text = t,
        color = LocalPal.current.mu,
        fontSize = 13.sp,
        lineHeight = 18.sp,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 10.dp)
    )
}

/**
 * iOS Grouped Section Header (uppercase small font).
 */
@Composable
fun Sec(t: String) {
    Text(
        text = t.uppercase(),
        color = LocalPal.current.mu,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 0.5.sp,
        modifier = Modifier.padding(start = 16.dp, top = 14.dp, bottom = 6.dp)
    )
}

/**
 * iOS Inset Grouped Section Card.
 */
@Composable
fun Group(content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPal.current
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 16.dp)
            .clip(shape)
            .background(p.card)
            .border(0.5.dp, p.hairline, shape),
        content = content
    )
}

/**
 * iOS-styled rounded square icon container with gradient background.
 */
@Composable
fun TileIcon(icon: String, size: Int = 32) {
    Box(
        modifier = Modifier
            .size(size.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(J.Tile),
        contentAlignment = Alignment.Center
    ) {
        Text(icon, fontSize = (size * 0.52f).sp)
    }
}

/**
 * iOS subtle gray right chevron accessory.
 */
@Composable
fun Chevron() {
    Icon(
        imageVector = Icons.Rounded.ChevronRight,
        contentDescription = null,
        tint = LocalPal.current.mu.copy(alpha = 0.6f),
        modifier = Modifier.size(20.dp)
    )
}

/**
 * iOS Grouped Row Table Cell.
 * Includes opacity press feedback (no Material ripple) and hairline divider.
 */
@Composable
fun Item(
    icon: String,
    title: String,
    sub: String? = null,
    trailing: @Composable () -> Unit = { Chevron() },
    onClick: (() -> Unit)? = null
) {
    val p = LocalPal.current
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val alpha by animateFloatAsState(
        targetValue = if (isPressed && onClick != null) 0.6f else 1f,
        label = "item_press"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (onClick != null) {
                    Modifier.clickable(
                        interactionSource = interactionSource,
                        indication = null,
                        onClick = onClick
                    )
                } else Modifier
            )
            .alpha(alpha)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            TileIcon(icon)
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = p.text, fontSize = 17.sp, fontWeight = FontWeight.Normal)
                if (!sub.isNullOrBlank()) {
                    Text(sub, color = p.mu, fontSize = 13.sp, lineHeight = 17.sp, modifier = Modifier.padding(top = 2.dp))
                }
            }
            trailing()
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 58.dp)
                .height(0.5.dp)
                .background(p.hairline)
        )
    }
}

/**
 * iOS Switch Row with Apple HIG green toggle.
 */
@Composable
fun ToggleItem(icon: String, title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Item(
        icon = icon,
        title = title,
        sub = sub,
        trailing = {
            IOSSwitch(checked = checked, onCheckedChange = onChange)
        },
        onClick = { onChange(!checked) }
    )
}

@Composable
fun Starfield(modifier: Modifier = Modifier) {
    val dots = remember { List(80) { val r = Random(it); Triple(r.nextFloat(), r.nextFloat(), r.nextFloat()) } }
    androidx.compose.foundation.Canvas(modifier) {
        dots.forEach { (x, y, s) ->
            drawCircle(Color(0xFFFF2D8A).copy(alpha = .12f + s * .35f), (.6f + s * 1.5f) * density, Offset(x * size.width, y * size.height))
        }
    }
}

@Composable
fun GradientButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(J.Tile)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .padding(vertical = 15.dp, horizontal = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
    }
}

private fun navIcon(screen: Screen, sel: Boolean): ImageVector = when (screen) {
    Screen.Home -> Icons.Rounded.Home
    Screen.Chat -> Icons.Rounded.Chat
    Screen.History -> Icons.Rounded.History
    else -> Icons.Rounded.Settings
}

@Composable
private fun NavItem(label: String, icon: ImageVector, sel: Boolean, mod: Modifier, onClick: () -> Unit) {
    val tint = if (sel) J.Pink else LocalPal.current.mu
    Column(
        modifier = mod.clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null,
            onClick = onClick
        ),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icon, label, tint = tint, modifier = Modifier.size(24.dp))
        Spacer(Modifier.height(2.dp))
        Text(
            text = label,
            color = tint,
            fontSize = 11.sp,
            fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}

/**
 * Native iOS Translucent Tab Bar with central glowing Juliet Orb.
 */
@Composable
fun BottomNav(
    cur: Screen,
    orb: Int,
    mode: Int = 0,
    audioLevel: Float = 0f,
    animate: Boolean = true,
    onGo: (Screen) -> Unit,
    onCore: () -> Unit
) {
    val p = LocalPal.current
    val tab = if (cur == Screen.Home || cur == Screen.Chat || cur == Screen.History) cur else Screen.Settings

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(p.nav)
                .border(width = 0.5.dp, color = p.hairline)
                .height(60.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxSize(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                NavItem("Home", Icons.Rounded.Home, tab == Screen.Home, Modifier.weight(1f)) { onGo(Screen.Home) }
                NavItem("Chat", Icons.Rounded.Chat, tab == Screen.Chat, Modifier.weight(1f)) { onGo(Screen.Chat) }
                Spacer(Modifier.width(76.dp)) // Space for central glowing orb
                NavItem("History", Icons.Rounded.History, tab == Screen.History, Modifier.weight(1f)) { onGo(Screen.History) }
                NavItem("Settings", Icons.Rounded.Settings, tab == Screen.Settings, Modifier.weight(1f)) { onGo(Screen.Settings) }
            }
        }

        // Center Blue Glowing Juliet Orb with metallic gold ring
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .offset(y = (-20).dp)
                .size(62.dp)
                .clip(CircleShape)
                .background(Brush.sweepGradient(listOf(J.Gold, Color(0xFF8A5A1E), J.Gold, Color(0xFF8A5A1E), J.Gold)))
                .padding(3.dp)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onCore
                )
        ) {
            JOrb(orb, Modifier.fillMaxSize(), mode = mode, animate = animate, bare = true, audioLevel = audioLevel)
        }
    }
}
