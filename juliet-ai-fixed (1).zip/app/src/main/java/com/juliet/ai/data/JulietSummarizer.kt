package com.juliet.ai.data

import android.content.Context
import com.juliet.ai.BuildConfig
import com.juliet.ai.net.GroqClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class JulietSummarizer(private val ctx: Context, private val prefs: Prefs) {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .build()

    private val groq = GroqClient()

    suspend fun generateSummary(
        target: String, // "whatsapp" or "notifications"
        contactFilter: String? = null,
        countLimit: Int = 10,
        onlyToday: Boolean = false
    ): Result<JulietSummary> = withContext(Dispatchers.IO) {
        val all = prefs.loadNotifications()
        val privacyMode = prefs.get("ann_privacy", "1") == "1"

        val startOfToday = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        var filtered = all.filter {
            when (target.lowercase()) {
                "whatsapp" -> it.isWhatsApp
                else -> true
            }
        }

        if (onlyToday) {
            filtered = filtered.filter { it.time >= startOfToday }
        }

        if (!contactFilter.isNullOrBlank()) {
            val q = contactFilter.trim().lowercase()
            filtered = filtered.filter { it.sender.lowercase().contains(q) }
        }

        filtered = filtered.take(countLimit)

        if (filtered.isEmpty()) {
            val msg = if (target == "whatsapp") {
                "No recent WhatsApp messages found to summarize."
            } else {
                "No notifications recorded today to summarize."
            }
            return@withContext Result.failure(IllegalStateException(msg))
        }

        val timeFmt = SimpleDateFormat("h:mm a", Locale.getDefault())
        val messageBuffer = StringBuilder()

        for (item in filtered) {
            val timeStr = timeFmt.format(Date(item.time))
            val safeText = if (privacyMode && !item.isWhatsApp) {
                // In privacy mode for general notifications, mask specific text
                "[Content hidden in Privacy Mode]"
            } else if (privacyMode && item.isWhatsApp) {
                // For WhatsApp, mask potential sensitive patterns (OTPs, passwords)
                item.text.replace(Regex("\\b\\d{4,8}\\b"), "[REDACTED]")
            } else {
                item.text
            }
            messageBuffer.append("- [${item.appName}] ${item.sender} ($timeStr): $safeText\n")
        }

        val title = when {
            !contactFilter.isNullOrBlank() -> "Summary of WhatsApp with $contactFilter"
            target == "whatsapp" -> "WhatsApp Summary (Last ${filtered.size} messages)"
            onlyToday -> "Today's Notification Highlights"
            else -> "Notification Summary (${filtered.size} items)"
        }

        val prompt = buildString {
            append("You are Juliet, an executive AI assistant summarizing messages and notifications for your owner, Ahsan.\n")
            if (privacyMode) {
                append("NOTE: Privacy Mode is ACTIVE. Do not reveal private authentication codes, bank details, or passwords.\n")
            }
            append("Analyze the following items and produce a clear, concise, structured summary.\n\n")
            append("ITEMS TO SUMMARIZE:\n")
            append(messageBuffer.toString())
            append("\nFORMAT REQUIREMENTS:\n")
            append("Your response MUST use these exact section headers with bullets:\n")
            append("📌 KEY POINTS:\n- Point 1\n- Point 2\n\n")
            append("🤝 DECISIONS MADE:\n- Decision or agreement (or 'None recorded' if none)\n\n")
            append("⚡ ACTION ITEMS:\n- Action item with owner/deadline if mentioned (or 'None required' if none)\n")
        }

        val geminiKey = prefs.get("k_gemini").ifBlank { BuildConfig.DEFAULT_GEMINI_KEY }
        val generatedText = if (geminiKey.isNotBlank()) {
            callGemini(geminiKey, prompt) ?: callGroq(prompt)
        } else {
            callGroq(prompt)
        } ?: return@withContext Result.failure(IllegalStateException("Unable to generate summary. Please check your Gemini or Groq key in Settings > Connections."))

        val parsed = parseSections(title, target, generatedText, privacyMode)
        prefs.addSummary(parsed)
        Result.success(parsed)
    }

    private fun parseSections(title: String, target: String, text: String, privacy: Boolean): JulietSummary {
        val keyPoints = mutableListOf<String>()
        val decisions = mutableListOf<String>()
        val actionItems = mutableListOf<String>()

        var currentSection = 0 // 1: key, 2: decisions, 3: actions
        val lines = text.lines()

        for (rawLine in lines) {
            val line = rawLine.trim()
            if (line.contains("KEY POINT", ignoreCase = true)) {
                currentSection = 1
                continue
            } else if (line.contains("DECISION", ignoreCase = true)) {
                currentSection = 2
                continue
            } else if (line.contains("ACTION ITEM", ignoreCase = true)) {
                currentSection = 3
                continue
            }

            if (line.startsWith("-") || line.startsWith("•") || line.startsWith("*")) {
                val cleaned = line.removePrefix("-").removePrefix("•").removePrefix("*").trim()
                if (cleaned.isNotBlank()) {
                    when (currentSection) {
                        1 -> keyPoints.add(cleaned)
                        2 -> decisions.add(cleaned)
                        3 -> actionItems.add(cleaned)
                    }
                }
            }
        }

        // Fallbacks if formatting differed
        if (keyPoints.isEmpty() && decisions.isEmpty() && actionItems.isEmpty()) {
            keyPoints.add(text.take(300))
        }

        return JulietSummary(
            id = System.currentTimeMillis(),
            title = title,
            targetType = target,
            keyPoints = keyPoints,
            decisions = decisions,
            actionItems = actionItems,
            fullSummary = text,
            timestamp = System.currentTimeMillis(),
            privacyApplied = privacy
        )
    }

    private suspend fun callGemini(key: String, prompt: String): String? {
        return try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$key"
            val payload = JSONObject().apply {
                put("contents", JSONArray().put(JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", prompt)))
                }))
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.3)
                    put("maxOutputTokens", 1200)
                })
            }.toString().toRequestBody("application/json".toMediaType())

            val req = Request.Builder().url(url).post(payload).build()
            httpClient.newCall(req).execute().use { res ->
                if (!res.isSuccessful) return null
                val body = res.body?.string().orEmpty()
                val json = JSONObject(body)
                val c = json.optJSONArray("candidates")?.optJSONObject(0)
                val parts = c?.optJSONObject("content")?.optJSONArray("parts")
                parts?.optJSONObject(0)?.optString("text")?.trim()
            }
        } catch (e: Exception) {
            null
        }
    }

    private suspend fun callGroq(prompt: String): String? {
        val keys = prefs.get("k_groq").ifBlank { BuildConfig.DEFAULT_GROQ_KEYS }
            .split(",").map { it.trim() }.filter { it.isNotEmpty() }
        if (keys.isEmpty()) return null
        return groq.chat(keys, "You are a concise executive summarizer.", listOf(GroqClient.Msg("user", prompt))).getOrNull()
    }
}
