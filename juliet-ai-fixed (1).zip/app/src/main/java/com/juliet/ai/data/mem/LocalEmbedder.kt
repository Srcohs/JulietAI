package com.juliet.ai.data.mem

import java.nio.ByteBuffer

/**
 * Tiny on-device text embedder (feature hashing of words + character trigrams).
 * No model, no network, works for Roman Urdu spelling variations ("pasand"/"pasnd").
 * It measures lexical similarity, not deep meaning — good enough to pick relevant memories.
 */
object LocalEmbedder {
    const val DIM = 256

    private val STOP = setOf(
        "hai", "hain", "he", "hun", "hoon", "ka", "ki", "ke", "ko", "se", "me", "mein", "main", "mera", "meri",
        "mujhe", "aur", "ya", "the", "is", "are", "a", "an", "of", "to", "my", "and", "in", "on", "for", "kya",
        "ye", "yeh", "wo", "woh", "nahi", "bhi", "tum", "aap", "you", "it", "that", "this"
    )
    private val SPLIT = Regex("[^\\p{L}\\p{N}]+")

    fun tokens(text: String): List<String> =
        text.lowercase().split(SPLIT).filter { it.length > 1 && it !in STOP }

    fun embed(text: String): FloatArray {
        val v = FloatArray(DIM)
        for (t in tokens(text)) {
            add(v, "w:$t", 1f)
            val p = "^$t$"
            for (i in 0..p.length - 3) add(v, "t:" + p.substring(i, i + 3), 0.4f)
        }
        var n = 0f
        for (x in v) n += x * x
        if (n > 0f) { val inv = 1f / kotlin.math.sqrt(n); for (i in v.indices) v[i] *= inv }
        return v
    }

    private fun add(v: FloatArray, feature: String, w: Float) {
        var h = 0x811C9DC5.toInt()                       // FNV-1a
        for (ch in feature) { h = h xor ch.code; h *= 16777619 }
        val idx = (h ushr 1) % DIM
        v[idx] += if ((h and 1) == 0) w else -w
    }

    fun cosine(a: FloatArray, b: FloatArray): Float {
        var d = 0f
        for (i in 0 until minOf(a.size, b.size)) d += a[i] * b[i]
        return d
    }

    fun toBytes(v: FloatArray): ByteArray {
        val bb = ByteBuffer.allocate(v.size * 4)
        bb.asFloatBuffer().put(v)
        return bb.array()
    }

    fun fromBytes(b: ByteArray): FloatArray {
        val out = FloatArray(b.size / 4)
        ByteBuffer.wrap(b).asFloatBuffer().get(out)
        return out
    }
}
