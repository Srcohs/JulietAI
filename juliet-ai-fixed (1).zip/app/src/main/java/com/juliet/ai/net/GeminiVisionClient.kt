package com.juliet.ai.net

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Handles real-time screen frame understanding, visual QA, and AI photo sketch generation
 * using official Google Gemini API (gemini-2.5-flash, gemini-3.5-flash, gemini-2.5-flash-image).
 */
class GeminiVisionClient {
    private val http = OkHttpClient.Builder()
        .connectTimeout(45, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    // Valid preview models from gemini-api skill (older 1.5/2.0 prohibited)
    private val visionModels = listOf("gemini-2.5-flash", "gemini-3.5-flash", "gemini-flash-latest")
    private val imageGenModels = listOf("gemini-2.5-flash-image", "gemini-nano-banana-2.1")

    suspend fun analyzeScreen(
        apiKey: String,
        bitmap: Bitmap,
        userQuestion: String,
        ocrSummary: String = ""
    ): Result<String> = withContext(Dispatchers.IO) {
        val cleanKey = apiKey.trim()
        if (cleanKey.isBlank()) {
            return@withContext Result.failure(IllegalStateException("Gemini API key is required for Live Screen Understanding. Please add it in Settings > Connections."))
        }

        val base64Image = try {
            val stream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 80, stream)
            Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
        } catch (e: Exception) {
            return@withContext Result.failure(IOException("Failed to encode screen frame: ${e.message}"))
        }

        val prompt = buildString {
            append("You are Juliet, an intelligent, perceptive and respectful female personal AI assistant for Android.\n")
            append("The user is asking about what is currently shown on their mobile screen.\n")
            append("Question: $userQuestion\n\n")
            if (ocrSummary.isNotBlank()) {
                append("Accessibility and OCR text detected on screen:\n$ocrSummary\n\n")
            }
            append("Instructions:\n")
            append("- Describe what is on the screen clearly, concisely and accurately.\n")
            append("- Identify buttons, navigation elements, input fields, and options.\n")
            append("- Help blind or visually impaired users by stating what is centered, focused, or clickable.\n")
            append("- Respond in natural Roman Urdu or English ONLY matching the user's inquiry. Never use Urdu script, Punjabi, or Hindi.\n")
            append("- Do not hallucinate items that are not visible.")
        }

        val payload = JSONObject().apply {
            val parts = JSONArray().apply {
                put(JSONObject().put("text", prompt))
                put(JSONObject().put("inlineData", JSONObject().apply {
                    put("mimeType", "image/jpeg")
                    put("data", base64Image)
                }))
            }
            put("contents", JSONArray().put(JSONObject().put("parts", parts)))
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.4)
                put("maxOutputTokens", 1200)
            })
        }.toString().toRequestBody("application/json".toMediaType())

        var lastError: Exception = IOException("Vision request failed")

        for (model in visionModels) {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$cleanKey"
            val req = Request.Builder().url(url).post(payload).build()

            try {
                http.newCall(req).execute().use { response ->
                    val body = response.body?.string().orEmpty()
                    if (response.isSuccessful) {
                        val json = JSONObject(body)
                        val candidates = json.optJSONArray("candidates")
                        if (candidates != null && candidates.length() > 0) {
                            val candidate = candidates.getJSONObject(0)
                            val content = candidate.optJSONObject("content")
                            val partsArr = content?.optJSONArray("parts")
                            if (partsArr != null && partsArr.length() > 0) {
                                val sb = StringBuilder()
                                for (i in 0 until partsArr.length()) {
                                    val t = partsArr.getJSONObject(i).optString("text")
                                    if (t.isNotBlank()) sb.append(t)
                                }
                                val text = sb.toString().trim()
                                if (text.isNotBlank()) {
                                    return@withContext Result.success(text)
                                }
                            }
                        }
                        return@withContext Result.success("I analyzed the screen frame but could not detect distinct text.")
                    } else {
                        val err = try {
                            val errObj = JSONObject(body).optJSONObject("error")
                            errObj?.optString("message") ?: "HTTP ${response.code}"
                        } catch (_: Exception) {
                            "HTTP ${response.code}"
                        }
                        lastError = IOException("$model failed: $err")
                    }
                }
            } catch (e: Exception) {
                lastError = e
            }
        }

        Result.failure(lastError)
    }

    suspend fun analyzeImage(
        apiKey: String,
        bitmap: Bitmap,
        prompt: String
    ): Result<String> = analyzeScreen(apiKey, bitmap, prompt, "")

    /**
     * Generates an artistic hand-drawn sketch from a photo using Gemini 2.5 Flash Image.
     */
    suspend fun generateAiSketch(
        apiKey: String,
        bitmap: Bitmap,
        stylePrompt: String = "Convert this photograph into an authentic hand-drawn graphite and charcoal sketch with clear contours, pencil crosshatching, shading, and white paper texture."
    ): Result<Bitmap> = withContext(Dispatchers.IO) {
        val cleanKey = apiKey.trim()
        if (cleanKey.isBlank()) {
            return@withContext Result.failure(IllegalStateException("Gemini API key is required for AI sketch generation."))
        }

        val base64Image = try {
            val stream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 85, stream)
            Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
        } catch (e: Exception) {
            return@withContext Result.failure(IOException("Failed to encode image: ${e.message}"))
        }

        val payload = JSONObject().apply {
            val parts = JSONArray().apply {
                put(JSONObject().put("text", stylePrompt))
                put(JSONObject().put("inlineData", JSONObject().apply {
                    put("mimeType", "image/jpeg")
                    put("data", base64Image)
                }))
            }
            put("contents", JSONArray().put(JSONObject().put("parts", parts)))
            put("generationConfig", JSONObject().apply {
                put("responseModalities", JSONArray().put("IMAGE"))
                put("imageConfig", JSONObject().apply {
                    put("aspectRatio", "1:1")
                    put("imageSize", "1K")
                })
            })
        }.toString().toRequestBody("application/json".toMediaType())

        var lastError: Exception = IOException("AI Sketch generation failed")

        for (model in imageGenModels) {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$cleanKey"
            val req = Request.Builder().url(url).post(payload).build()

            try {
                http.newCall(req).execute().use { response ->
                    val body = response.body?.string().orEmpty()
                    if (response.isSuccessful) {
                        val json = JSONObject(body)
                        val candidates = json.optJSONArray("candidates")
                        if (candidates != null && candidates.length() > 0) {
                            val candidate = candidates.getJSONObject(0)
                            val content = candidate.optJSONObject("content")
                            val partsArr = content?.optJSONArray("parts")
                            if (partsArr != null) {
                                for (i in 0 until partsArr.length()) {
                                    val part = partsArr.getJSONObject(i)
                                    val inlineData = part.optJSONObject("inlineData")
                                    val dataStr = inlineData?.optString("data")
                                    if (!dataStr.isNullOrBlank()) {
                                        val bytes = Base64.decode(dataStr, Base64.DEFAULT)
                                        val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                                        if (decoded != null) {
                                            return@withContext Result.success(decoded)
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        val err = try {
                            JSONObject(body).optJSONObject("error")?.optString("message") ?: "HTTP ${response.code}"
                        } catch (_: Exception) {
                            "HTTP ${response.code}"
                        }
                        lastError = IOException("$model: $err")
                    }
                }
            } catch (e: Exception) {
                lastError = e
            }
        }

        Result.failure(lastError)
    }
}
