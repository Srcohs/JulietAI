package com.juliet.ai.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import kotlin.math.*

/**
 * Centralized Orb state system matching voice assistant conversation logic.
 */
enum class OrbState(val id: Int, val label: String) {
    Idle(0, "Idle"),
    Listening(1, "Listening"),
    Speaking(2, "Speaking");

    companion object {
        fun fromMode(mode: Int): OrbState = when (mode) {
            1 -> Listening
            2 -> Speaking
            else -> Idle
        }
    }
}

class OrbDef(
    val name: String,
    val sub: String,
    val glow: Color
)

val ORBS = listOf(
    OrbDef("Classic", "Violet nebula", Color(0xFF9D4EDD)),
    OrbDef("Galaxy", "Spiral of stars", Color(0xFFB5179E)),
    OrbDef("Solar", "A burning sun", Color(0xFFFF9E00)),
    OrbDef("Crystal", "Cut ice gem", Color(0xFF48CAE4)),
    OrbDef("Ocean", "Rolling water", Color(0xFF0077B6)),
    OrbDef("Lava", "Molten rock", Color(0xFFFF4800))
)

// Internal color palette definition for smooth state transitions
private data class OrbStatePalette(
    val glow: Color,
    val haloInner: Color,
    val haloOuter: Color,
    val core: Color,
    val mid1: Color,
    val mid2: Color,
    val deep: Color,
    val highlight: Color,
    val accent: Color
)

private fun getSkinPalette(skinIndex: Int, state: OrbState): OrbStatePalette {
    return when (skinIndex) {
        // 0: Classic (Violet nebula)
        0 -> when (state) {
            OrbState.Idle -> OrbStatePalette(
                glow = Color(0xFF9D4EDD),
                haloInner = Color(0x669D4EDD),
                haloOuter = Color(0x003C096C),
                core = Color(0xFFF3E8FF),
                mid1 = Color(0xFFC77DFF),
                mid2 = Color(0xFF7B2CBF),
                deep = Color(0xFF240046),
                highlight = Color(0xFFFFFFFF),
                accent = Color(0xFFE0AAFF)
            )
            OrbState.Listening -> OrbStatePalette(
                glow = Color(0xFF00F5D4),
                haloInner = Color(0x7700E5FF),
                haloOuter = Color(0x0003045E),
                core = Color(0xFFE0FBFC),
                mid1 = Color(0xFF00F5D4),
                mid2 = Color(0xFF00B4D8),
                deep = Color(0xFF023E8A),
                highlight = Color(0xFFFFFFFF),
                accent = Color(0xFF48CAE4)
            )
            OrbState.Speaking -> OrbStatePalette(
                glow = Color(0xFFFF007F),
                haloInner = Color(0x88FF1493),
                haloOuter = Color(0x00590D22),
                core = Color(0xFFFFF0F5),
                mid1 = Color(0xFFFF4D94),
                mid2 = Color(0xFFD80032),
                deep = Color(0xFF480014),
                highlight = Color(0xFFFFD166),
                accent = Color(0xFFFFB703)
            )
        }
        // 1: Galaxy (Spiral of stars)
        1 -> when (state) {
            OrbState.Idle -> OrbStatePalette(
                glow = Color(0xFFB5179E),
                haloInner = Color(0x667209B7),
                haloOuter = Color(0x000F051D),
                core = Color(0xFFF7E1F5),
                mid1 = Color(0xFFC77DFF),
                mid2 = Color(0xFF560BAD),
                deep = Color(0xFF130026),
                highlight = Color(0xFFFFFFFF),
                accent = Color(0xFFD6A4E8)
            )
            OrbState.Listening -> OrbStatePalette(
                glow = Color(0xFF00D2FF),
                haloInner = Color(0x660099FF),
                haloOuter = Color(0x0004112B),
                core = Color(0xFFDCF6FF),
                mid1 = Color(0xFF00E5FF),
                mid2 = Color(0xFF0052D4),
                deep = Color(0xFF020D26),
                highlight = Color(0xFFFFFFFF),
                accent = Color(0xFF70E1FF)
            )
            OrbState.Speaking -> OrbStatePalette(
                glow = Color(0xFFFF2A85),
                haloInner = Color(0x77FF6584),
                haloOuter = Color(0x002B0314),
                core = Color(0xFFFFF2D6),
                mid1 = Color(0xFFFF5E7E),
                mid2 = Color(0xFFA61C5D),
                deep = Color(0xFF260012),
                highlight = Color(0xFFFFD166),
                accent = Color(0xFFFFB300)
            )
        }
        // 2: Solar (A burning sun)
        2 -> when (state) {
            OrbState.Idle -> OrbStatePalette(
                glow = Color(0xFFFF9E00),
                haloInner = Color(0x66FF6B00),
                haloOuter = Color(0x003D1300),
                core = Color(0xFFFFF9E6),
                mid1 = Color(0xFFFFB703),
                mid2 = Color(0xFFE85D04),
                deep = Color(0xFF6A040F),
                highlight = Color(0xFFFFFFFF),
                accent = Color(0xFFFFE169)
            )
            OrbState.Listening -> OrbStatePalette(
                glow = Color(0xFF00F5D4),
                haloInner = Color(0x6600BBF9),
                haloOuter = Color(0x00003049),
                core = Color(0xFFE8FFF9),
                mid1 = Color(0xFF52B788),
                mid2 = Color(0xFF0077B6),
                deep = Color(0xFF03045E),
                highlight = Color(0xFFFFFFFF),
                accent = Color(0xFF90E0EF)
            )
            OrbState.Speaking -> OrbStatePalette(
                glow = Color(0xFFFF3E00),
                haloInner = Color(0x88FF0054),
                haloOuter = Color(0x003F000C),
                core = Color(0xFFFFF8E7),
                mid1 = Color(0xFFFF5400),
                mid2 = Color(0xFF9E0059),
                deep = Color(0xFF39001D),
                highlight = Color(0xFFFFE066),
                accent = Color(0xFFFFB703)
            )
        }
        // 3: Crystal (Cut ice gem)
        3 -> when (state) {
            OrbState.Idle -> OrbStatePalette(
                glow = Color(0xFF48CAE4),
                haloInner = Color(0x550096C7),
                haloOuter = Color(0x00023E8A),
                core = Color(0xFFF0FDFF),
                mid1 = Color(0xFF90E0EF),
                mid2 = Color(0xFF0096C7),
                deep = Color(0xFF03045E),
                highlight = Color(0xFFFFFFFF),
                accent = Color(0xFFADE8F4)
            )
            OrbState.Listening -> OrbStatePalette(
                glow = Color(0xFF00F5D4),
                haloInner = Color(0x6600E5FF),
                haloOuter = Color(0x00012A4A),
                core = Color(0xFFE6FFFA),
                mid1 = Color(0xFF70E000),
                mid2 = Color(0xFF00A896),
                deep = Color(0xFF023E8A),
                highlight = Color(0xFFFFFFFF),
                accent = Color(0xFF80FFDB)
            )
            OrbState.Speaking -> OrbStatePalette(
                glow = Color(0xFFFF4D94),
                haloInner = Color(0x77E056FD),
                haloOuter = Color(0x002B0038),
                core = Color(0xFFFFF0F7),
                mid1 = Color(0xFFFF85A1),
                mid2 = Color(0xFF9B5DE5),
                deep = Color(0xFF30004A),
                highlight = Color(0xFFFFE5EC),
                accent = Color(0xFFF15BB5)
            )
        }
        // 4: Ocean (Rolling water)
        4 -> when (state) {
            OrbState.Idle -> OrbStatePalette(
                glow = Color(0xFF0077B6),
                haloInner = Color(0x550096C7),
                haloOuter = Color(0x0003045E),
                core = Color(0xFFEDF6F9),
                mid1 = Color(0xFF00B4D8),
                mid2 = Color(0xFF0077B6),
                deep = Color(0xFF03045E),
                highlight = Color(0xFFFFFFFF),
                accent = Color(0xFF83C5BE)
            )
            OrbState.Listening -> OrbStatePalette(
                glow = Color(0xFF00F5D4),
                haloInner = Color(0x6600B4D8),
                haloOuter = Color(0x00002855),
                core = Color(0xFFE0FBFC),
                mid1 = Color(0xFF00F5D4),
                mid2 = Color(0xFF0096C7),
                deep = Color(0xFF023E8A),
                highlight = Color(0xFFFFFFFF),
                accent = Color(0xFF48CAE4)
            )
            OrbState.Speaking -> OrbStatePalette(
                glow = Color(0xFFFF6B6B),
                haloInner = Color(0x77EE5253),
                haloOuter = Color(0x0022092C),
                core = Color(0xFFFFF0EB),
                mid1 = Color(0xFFFF9F43),
                mid2 = Color(0xFFEE5253),
                deep = Color(0xFF5F27CD),
                highlight = Color(0xFFFFEAA7),
                accent = Color(0xFFFFA502)
            )
        }
        // 5: Lava (Molten rock)
        else -> when (state) {
            OrbState.Idle -> OrbStatePalette(
                glow = Color(0xFFFF4800),
                haloInner = Color(0x66D00000),
                haloOuter = Color(0x002B0500),
                core = Color(0xFFFFF3E0),
                mid1 = Color(0xFFFF5400),
                mid2 = Color(0xFF9D0208),
                deep = Color(0xFF1D0003),
                highlight = Color(0xFFFFD166),
                accent = Color(0xFFFF8500)
            )
            OrbState.Listening -> OrbStatePalette(
                glow = Color(0xFF00D2D3),
                haloInner = Color(0x6601A3A4),
                haloOuter = Color(0x000C1D24),
                core = Color(0xFFE8FFFF),
                mid1 = Color(0xFF48DBFB),
                mid2 = Color(0xFF0083B0),
                deep = Color(0xFF0A192F),
                highlight = Color(0xFFFFFFFF),
                accent = Color(0xFF00CEC9)
            )
            OrbState.Speaking -> OrbStatePalette(
                glow = Color(0xFFFF2A42),
                haloInner = Color(0x88FF5252),
                haloOuter = Color(0x00330006),
                core = Color(0xFFFFF9E6),
                mid1 = Color(0xFFFF7675),
                mid2 = Color(0xFFD63031),
                deep = Color(0xFF2D0005),
                highlight = Color(0xFFFFEAA7),
                accent = Color(0xFFFF9F43)
            )
        }
    }
}

/**
 * Procedural 3D Volumetric Living Orb component.
 *
 * Implements:
 * - 3D spherical depth with limb darkening and subsurface glow
 * - Volumetric internal nebula clouds drifting with rotational harmonic noise
 * - Specular highlights with realistic glass curvature & Fresnel rim lighting
 * - Soft atmospheric halo expanding and pulsing with state & audio amplitude
 * - Smooth 700ms color & parameter interpolation between Idle, Listening, and Speaking
 * - Audio-reactive pulsation during microphone capture (Listening) & speech output (Speaking)
 * - Safe fallback & reduced motion support
 */
@Composable
fun JOrb(
    index: Int,
    modifier: Modifier = Modifier,
    mode: Int = 0,
    animate: Boolean = true,
    bare: Boolean = false,
    audioLevel: Float = 0f
) {
    val skinIndex = index.coerceIn(0, ORBS.size - 1)
    val state = OrbState.fromMode(mode)

    // Smooth state transitions: target palette based on active state
    val targetPalette = getSkinPalette(skinIndex, state)
    val animSpec = tween<Color>(durationMillis = 750, easing = FastOutSlowInEasing)

    val glowColor by animateColorAsState(targetPalette.glow, animSpec, label = "glow")
    val haloInner by animateColorAsState(targetPalette.haloInner, animSpec, label = "haloInner")
    val haloOuter by animateColorAsState(targetPalette.haloOuter, animSpec, label = "haloOuter")
    val coreColor by animateColorAsState(targetPalette.core, animSpec, label = "core")
    val mid1Color by animateColorAsState(targetPalette.mid1, animSpec, label = "mid1")
    val mid2Color by animateColorAsState(targetPalette.mid2, animSpec, label = "mid2")
    val deepColor by animateColorAsState(targetPalette.deep, animSpec, label = "deep")
    val highlightColor by animateColorAsState(targetPalette.highlight, animSpec, label = "highlight")
    val accentColor by animateColorAsState(targetPalette.accent, animSpec, label = "accent")

    // State parameter interpolation
    val targetSpeedFactor = when (state) {
        OrbState.Idle -> 1.0f
        OrbState.Listening -> 1.8f
        OrbState.Speaking -> 2.4f
    }
    val speedFactor by animateFloatAsState(
        targetValue = targetSpeedFactor,
        animationSpec = tween(750, easing = FastOutSlowInEasing),
        label = "speed"
    )

    val targetHaloIntensity = when (state) {
        OrbState.Idle -> 0.42f
        OrbState.Listening -> 0.70f
        OrbState.Speaking -> 0.85f
    }
    val haloIntensity by animateFloatAsState(
        targetValue = targetHaloIntensity,
        animationSpec = tween(750, easing = FastOutSlowInEasing),
        label = "haloIntensity"
    )

    // Infinite transition for fluid continuous motion
    val transition = rememberInfiniteTransition(label = "orb_anim")
    val animTime by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 18000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "time"
    )

    val gentleBreath by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "breath"
    )

    val speakingRhythm by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "speakingRhythm"
    )

    Canvas(modifier = modifier) {
        val c = center
        val baseR = if (bare) size.minDimension * 0.48f else size.minDimension * 0.36f
        if (baseR <= 1f) return@Canvas

        // Audio reactivity & dynamic scale
        val reactiveAudio = audioLevel.coerceIn(0f, 1f)
        val breathWave = sin(gentleBreath)
        val speakingWave = (sin(speakingRhythm) * 0.5f + 0.5f)

        val pulseScale = if (!animate) {
            1.0f
        } else {
            when (state) {
                OrbState.Idle -> 1.0f + 0.022f * breathWave
                OrbState.Listening -> 1.0f + (0.015f * breathWave) + (0.08f * reactiveAudio)
                OrbState.Speaking -> 1.0f + (0.035f * speakingWave) + (0.09f * max(reactiveAudio, speakingWave * 0.5f))
            }
        }
        val currentR = baseR * pulseScale
        val t = if (animate) animTime * speedFactor else 0f

        // 1. ATMOSPHERIC HALO (Outer Glow Aura)
        if (!bare) {
            val haloPulse = if (animate) {
                when (state) {
                    OrbState.Idle -> 1.0f + 0.04f * breathWave
                    OrbState.Listening -> 1.0f + 0.08f * max(reactiveAudio, 0.2f * breathWave)
                    OrbState.Speaking -> 1.0f + 0.12f * max(reactiveAudio, speakingWave)
                }
            } else 1.0f

            val haloRadius = currentR * 1.55f * haloPulse
            val dynamicHaloAlpha = (haloIntensity * (if (animate) 0.85f + 0.15f * breathWave else 1.0f))
                .coerceIn(0.1f, 1.0f)

            drawCircle(
                brush = Brush.radialGradient(
                    0.0f to haloInner.copy(alpha = (haloInner.alpha * dynamicHaloAlpha).coerceIn(0f, 1f)),
                    0.45f to glowColor.copy(alpha = (0.45f * dynamicHaloAlpha).coerceIn(0f, 1f)),
                    0.75f to glowColor.copy(alpha = (0.15f * dynamicHaloAlpha).coerceIn(0f, 1f)),
                    1.0f to Color.Transparent,
                    center = c,
                    radius = haloRadius
                ),
                radius = haloRadius,
                center = c
            )
        }

        // 2. 3D SPHERICAL OCCLUSION & VOLUMETRIC INTERIOR (Clipped to sphere silhouette)
        clipPath(Path().apply { addOval(Rect(c.x - currentR, c.y - currentR, c.x + currentR, c.y + currentR)) }) {
            // Spherical base lighting: core light offset towards top-left for 3D volume
            val lightCenter = Offset(c.x - currentR * 0.22f, c.y - currentR * 0.26f)

            // Deep background sphere gradient with limb darkening
            drawCircle(
                brush = Brush.radialGradient(
                    0.00f to coreColor.copy(alpha = 0.95f),
                    0.28f to mid1Color,
                    0.65f to mid2Color,
                    0.90f to deepColor,
                    1.00f to deepColor.copy(alpha = 0.98f),
                    center = lightCenter,
                    radius = currentR * 1.45f
                ),
                radius = currentR,
                center = c
            )

            // Skin-specific internal 3D volumetric layers
            when (skinIndex) {
                // 0: Classic (Violet Nebula with multi-layer swirling gas)
                0 -> {
                    drawClassicNebula(c, currentR, t, mid1Color, mid2Color, accentColor, coreColor)
                }
                // 1: Galaxy (Spiral galaxy arms with star clusters)
                1 -> {
                    drawGalaxySpiral(c, currentR, t, mid1Color, accentColor, highlightColor)
                }
                // 2: Solar (Thermonuclear convective cells & corona)
                2 -> {
                    drawSolarConvection(c, currentR, t, mid1Color, mid2Color, accentColor, highlightColor)
                }
                // 3: Crystal (Faceted caustics & refractive diamond streaks)
                3 -> {
                    drawCrystalFacets(c, currentR, t, mid1Color, mid2Color, highlightColor)
                }
                // 4: Ocean (Rolling fluid wave currents & bioluminescence)
                4 -> {
                    drawOceanCurrents(c, currentR, t, mid1Color, mid2Color, accentColor, highlightColor)
                }
                // 5: Lava (Molten magma core with shifting crust plates)
                else -> {
                    drawLavaMagma(c, currentR, t, mid1Color, mid2Color, accentColor, highlightColor)
                }
            }

            // Universal 3D Inner Core Plasma Source
            val corePulse = if (animate) 1.0f + 0.08f * sin(gentleBreath * 1.5f) else 1.0f
            val coreR = currentR * 0.38f * corePulse
            drawCircle(
                brush = Brush.radialGradient(
                    0.0f to highlightColor.copy(alpha = 0.85f),
                    0.4f to accentColor.copy(alpha = 0.50f),
                    1.0f to Color.Transparent,
                    center = lightCenter,
                    radius = coreR
                ),
                radius = coreR,
                center = lightCenter
            )

            // Limb Darkening Ambient Occlusion: makes the sphere convincingly 3D and spherical
            drawCircle(
                brush = Brush.radialGradient(
                    0.00f to Color.Transparent,
                    0.72f to Color.Transparent,
                    0.92f to Color.Black.copy(alpha = 0.42f),
                    1.00f to Color.Black.copy(alpha = 0.78f),
                    center = c,
                    radius = currentR
                ),
                radius = currentR,
                center = c
            )
        }

        // 3. 3D TRANSLUCENT GLASS SURFACE & SPECULAR HIGHLIGHTS
        // Drawn on top of the sphere silhouette to achieve a realistic glossy crystal lens look:

        // A. Primary Specular Light (Top-Left Gloss)
        val specCenter = Offset(c.x - currentR * 0.30f, c.y - currentR * 0.36f)
        val specRadius = currentR * 0.35f
        drawCircle(
            brush = Brush.radialGradient(
                0.00f to Color.White.copy(alpha = 0.95f),
                0.25f to Color.White.copy(alpha = 0.65f),
                0.60f to Color.White.copy(alpha = 0.18f),
                1.00f to Color.Transparent,
                center = specCenter,
                radius = specRadius
            ),
            radius = specRadius,
            center = specCenter
        )

        // B. Secondary Back-Bounce Reflection (Bottom-Right ambient sheen)
        val bounceCenter = Offset(c.x + currentR * 0.28f, c.y + currentR * 0.32f)
        val bounceRadius = currentR * 0.24f
        drawCircle(
            brush = Brush.radialGradient(
                0.00f to accentColor.copy(alpha = 0.35f),
                0.60f to accentColor.copy(alpha = 0.12f),
                1.00f to Color.Transparent,
                center = bounceCenter,
                radius = bounceRadius
            ),
            radius = bounceRadius,
            center = bounceCenter
        )

        // C. Fresnel Rim Light (Glass edge refraction)
        drawCircle(
            brush = Brush.sweepGradient(
                0.00f to Color.White.copy(alpha = 0.15f),
                0.15f to Color.White.copy(alpha = 0.60f), // Bright highlight near top-left
                0.35f to accentColor.copy(alpha = 0.35f),
                0.65f to Color.White.copy(alpha = 0.12f),
                0.85f to accentColor.copy(alpha = 0.45f),
                1.00f to Color.White.copy(alpha = 0.15f),
                center = c
            ),
            radius = currentR - 0.5f,
            center = c,
            style = Stroke(width = max(1.2f, currentR * 0.038f))
        )

        // D. Delicate Curvature Sheen Arc (simulates the glass dome's reflection)
        drawArc(
            brush = Brush.linearGradient(
                colors = listOf(
                    Color.Transparent,
                    Color.White.copy(alpha = 0.30f),
                    Color.White.copy(alpha = 0.55f),
                    Color.White.copy(alpha = 0.10f),
                    Color.Transparent
                ),
                start = Offset(c.x - currentR * 0.8f, c.y - currentR * 0.8f),
                end = Offset(c.x + currentR * 0.8f, c.y)
            ),
            startAngle = 195f,
            sweepAngle = 75f,
            useCenter = false,
            topLeft = Offset(c.x - currentR * 0.90f, c.y - currentR * 0.90f),
            size = Size(currentR * 1.80f, currentR * 1.80f),
            style = Stroke(width = max(1f, currentR * 0.022f))
        )
    }
}

// ---------------- PROCEDURAL VOLUMETRIC SKIN RENDERERS ----------------

/**
 * Classic Nebula: Layered rotating gaseous filaments and drifting stardust
 */
private fun DrawScope.drawClassicNebula(
    c: Offset,
    r: Float,
    t: Float,
    mid1: Color,
    mid2: Color,
    accent: Color,
    core: Color
) {
    val rad1 = (t * 0.8f) * (Math.PI / 180f).toFloat()
    val rad2 = (-t * 1.2f + 45f) * (Math.PI / 180f).toFloat()

    // Nebula Cloud 1: Swirling primary gas pocket
    val off1 = Offset(c.x + r * 0.28f * cos(rad1), c.y + r * 0.22f * sin(rad1))
    drawCircle(
        brush = Brush.radialGradient(
            0.0f to mid1.copy(alpha = 0.65f),
            0.5f to accent.copy(alpha = 0.35f),
            1.0f to Color.Transparent,
            center = off1,
            radius = r * 0.72f
        ),
        radius = r * 0.72f,
        center = off1
    )

    // Nebula Cloud 2: Counter-rotating secondary filament
    val off2 = Offset(c.x + r * 0.32f * cos(rad2), c.y + r * 0.26f * sin(rad2))
    drawCircle(
        brush = Brush.radialGradient(
            0.0f to accent.copy(alpha = 0.55f),
            0.55f to mid2.copy(alpha = 0.28f),
            1.0f to Color.Transparent,
            center = off2,
            radius = r * 0.68f
        ),
        radius = r * 0.68f,
        center = off2
    )

    // Nebula Cloud 3: Internal harmonic plasma wave
    rotate(degrees = t * 0.5f, pivot = c) {
        drawCircle(
            brush = Brush.sweepGradient(
                0.00f to Color.Transparent,
                0.25f to mid1.copy(alpha = 0.40f),
                0.50f to Color.Transparent,
                0.75f to core.copy(alpha = 0.35f),
                1.00f to Color.Transparent,
                center = c
            ),
            radius = r * 0.88f,
            center = c
        )
    }

    // Drifting sparkling star motes
    val starCoords = listOf(
        0.28f to 0.22f, 0.72f to 0.34f, 0.45f to 0.68f, 0.30f to 0.75f,
        0.80f to 0.70f, 0.58f to 0.18f, 0.16f to 0.48f, 0.85f to 0.52f,
        0.38f to 0.42f, 0.65f to 0.55f
    )
    starCoords.forEachIndexed { idx, (sx, sy) ->
        val drift = sin(rad1 * 2f + idx) * 0.03f
        val px = c.x - r + (sx + drift) * 2 * r
        val py = c.y - r + (sy + drift) * 2 * r
        val starAlpha = (0.45f + 0.45f * sin(rad2 * 2.5f + idx)).coerceIn(0.1f, 1f)
        drawCircle(
            color = Color.White.copy(alpha = starAlpha),
            radius = max(1f, r * (if (idx % 2 == 0) 0.022f else 0.015f)),
            center = Offset(px, py)
        )
    }
}

/**
 * Galaxy: Spiral arms with rotating star clusters and glowing galactic core
 */
private fun DrawScope.drawGalaxySpiral(
    c: Offset,
    r: Float,
    t: Float,
    mid1: Color,
    accent: Color,
    highlight: Color
) {
    val angle = t * 1.5f

    rotate(degrees = angle, pivot = c) {
        // Arm 1
        drawCircle(
            brush = Brush.sweepGradient(
                0.00f to Color.Transparent,
                0.18f to mid1.copy(alpha = 0.75f),
                0.35f to accent.copy(alpha = 0.45f),
                0.50f to Color.Transparent,
                0.68f to mid1.copy(alpha = 0.75f),
                0.85f to accent.copy(alpha = 0.45f),
                1.00f to Color.Transparent,
                center = c
            ),
            radius = r * 0.92f,
            center = c
        )

        // Arm 2 (Inner spiral core)
        drawCircle(
            brush = Brush.sweepGradient(
                0.12f to Color.Transparent,
                0.30f to highlight.copy(alpha = 0.65f),
                0.48f to Color.Transparent,
                0.62f to Color.Transparent,
                0.80f to highlight.copy(alpha = 0.65f),
                1.00f to Color.Transparent,
                center = c
            ),
            radius = r * 0.65f,
            center = c
        )

        // Star clusters distributed in the spiral disk
        val stars = listOf(
            0.35f to 0.25f, 0.65f to 0.75f, 0.40f to 0.70f, 0.60f to 0.30f,
            0.20f to 0.50f, 0.80f to 0.50f, 0.50f to 0.20f, 0.50f to 0.80f,
            0.28f to 0.35f, 0.72f to 0.65f, 0.38f to 0.62f, 0.62f to 0.38f
        )
        stars.forEachIndexed { i, (sx, sy) ->
            val px = c.x - r + sx * 2 * r
            val py = c.y - r + sy * 2 * r
            drawCircle(
                color = Color.White.copy(alpha = 0.75f),
                radius = max(1f, r * 0.02f),
                center = Offset(px, py)
            )
        }
    }
}

/**
 * Solar: Convective plasma granules & radiant solar flare bursts
 */
private fun DrawScope.drawSolarConvection(
    c: Offset,
    r: Float,
    t: Float,
    mid1: Color,
    mid2: Color,
    accent: Color,
    highlight: Color
) {
    val rad = (t * 0.9f) * (Math.PI / 180f).toFloat()

    // Convective boiling granules
    for (i in 0 until 6) {
        val granuleAngle = rad + i * (Math.PI.toFloat() / 3f)
        val dist = r * (0.25f + 0.15f * sin(rad * 2f + i))
        val gPos = Offset(c.x + dist * cos(granuleAngle), c.y + dist * sin(granuleAngle))
        drawCircle(
            brush = Brush.radialGradient(
                0.0f to highlight.copy(alpha = 0.55f),
                0.45f to accent.copy(alpha = 0.35f),
                1.0f to Color.Transparent,
                center = gPos,
                radius = r * 0.38f
            ),
            radius = r * 0.38f,
            center = gPos
        )
    }

    // Solar flares radiating along circumference
    rotate(degrees = t * 1.2f, pivot = c) {
        drawCircle(
            brush = Brush.sweepGradient(
                0.00f to mid1.copy(alpha = 0.65f),
                0.15f to Color.Transparent,
                0.30f to mid2.copy(alpha = 0.75f),
                0.45f to Color.Transparent,
                0.60f to mid1.copy(alpha = 0.65f),
                0.75f to Color.Transparent,
                0.90f to accent.copy(alpha = 0.70f),
                1.00f to mid1.copy(alpha = 0.65f),
                center = c
            ),
            radius = r * 0.95f,
            center = c
        )
    }
}

/**
 * Crystal: Faceted geometric cut caustics with refractive glass prism sheen
 */
private fun DrawScope.drawCrystalFacets(
    c: Offset,
    r: Float,
    t: Float,
    mid1: Color,
    mid2: Color,
    highlight: Color
) {
    val rad = (t * 0.4f) * (Math.PI / 180f).toFloat()

    // Cut gem facets (refractive geometric planes)
    val facetCount = 8
    val angleStep = 360f / facetCount
    for (i in 0 until facetCount) {
        val startAngle = i * angleStep + t * 0.3f
        val sweep = angleStep * 0.88f
        val facetAlpha = 0.20f + 0.30f * abs(sin(rad + i))
        drawArc(
            brush = Brush.radialGradient(
                0.0f to highlight.copy(alpha = facetAlpha),
                0.7f to (if (i % 2 == 0) mid1 else mid2).copy(alpha = facetAlpha * 0.7f),
                1.0f to Color.Transparent,
                center = c,
                radius = r * 0.95f
            ),
            startAngle = startAngle,
            sweepAngle = sweep,
            useCenter = true,
            topLeft = Offset(c.x - r * 0.92f, c.y - r * 0.92f),
            size = Size(r * 1.84f, r * 1.84f)
        )
    }

    // Prismatic diamond cut lines
    rotate(degrees = t * 0.2f, pivot = c) {
        val s = r * 0.62f
        drawLine(Color.White.copy(alpha = 0.35f), Offset(c.x - s, c.y), Offset(c.x + s, c.y), strokeWidth = max(1f, r * 0.02f))
        drawLine(Color.White.copy(alpha = 0.35f), Offset(c.x, c.y - s), Offset(c.x, c.y + s), strokeWidth = max(1f, r * 0.02f))
        drawLine(Color.White.copy(alpha = 0.25f), Offset(c.x - s * 0.7f, c.y - s * 0.7f), Offset(c.x + s * 0.7f, c.y + s * 0.7f), strokeWidth = max(1f, r * 0.015f))
        drawLine(Color.White.copy(alpha = 0.25f), Offset(c.x - s * 0.7f, c.y + s * 0.7f), Offset(c.x + s * 0.7f, c.y - s * 0.7f), strokeWidth = max(1f, r * 0.015f))
    }
}

/**
 * Ocean: Fluid rolling spherical wave bands & abyssal bioluminescence
 */
private fun DrawScope.drawOceanCurrents(
    c: Offset,
    r: Float,
    t: Float,
    mid1: Color,
    mid2: Color,
    accent: Color,
    highlight: Color
) {
    val rad = (t * 0.7f) * (Math.PI / 180f).toFloat()

    // 3 Spherical wave swell layers
    for (i in 0 until 3) {
        val yShift = r * (-0.35f + i * 0.35f + 0.08f * sin(rad + i))
        val swellRadius = r * (0.85f - i * 0.08f)
        drawArc(
            brush = Brush.linearGradient(
                colors = listOf(
                    Color.Transparent,
                    accent.copy(alpha = 0.45f),
                    highlight.copy(alpha = 0.65f),
                    mid1.copy(alpha = 0.45f),
                    Color.Transparent
                ),
                start = Offset(c.x - swellRadius, c.y + yShift),
                end = Offset(c.x + swellRadius, c.y + yShift)
            ),
            startAngle = 10f + i * 20f,
            sweepAngle = 160f,
            useCenter = false,
            topLeft = Offset(c.x - swellRadius, c.y + yShift - swellRadius * 0.5f),
            size = Size(swellRadius * 2, swellRadius),
            style = Stroke(width = max(2f, r * 0.065f), cap = StrokeCap.Round)
        )
    }

    // Bioluminescent current swirls
    rotate(degrees = -t * 0.8f, pivot = c) {
        drawCircle(
            brush = Brush.sweepGradient(
                0.0f to Color.Transparent,
                0.3f to mid1.copy(alpha = 0.45f),
                0.6f to accent.copy(alpha = 0.35f),
                1.0f to Color.Transparent,
                center = c
            ),
            radius = r * 0.85f,
            center = c
        )
    }
}

/**
 * Lava: Molten magma mantle beneath drifting tectonic crust plates
 */
private fun DrawScope.drawLavaMagma(
    c: Offset,
    r: Float,
    t: Float,
    mid1: Color,
    mid2: Color,
    accent: Color,
    highlight: Color
) {
    val rad = (t * 0.6f) * (Math.PI / 180f).toFloat()

    // Liquid molten heat foundation
    drawCircle(
        brush = Brush.radialGradient(
            0.0f to highlight.copy(alpha = 0.85f),
            0.4f to accent.copy(alpha = 0.70f),
            0.7f to mid1.copy(alpha = 0.50f),
            1.0f to Color.Transparent,
            center = Offset(c.x + r * 0.15f * cos(rad), c.y + r * 0.15f * sin(rad)),
            radius = r * 0.85f
        ),
        radius = r * 0.85f,
        center = c
    )

    // Drifting obsidian crust plates (dark patches covering molten magma)
    val plates = listOf(
        0.30f to 0.25f, 0.75f to 0.30f, 0.35f to 0.70f, 0.70f to 0.68f, 0.50f to 0.50f
    )
    plates.forEachIndexed { i, (px, py) ->
        val driftX = cos(rad + i * 1.3f) * 0.05f * r
        val driftY = sin(rad + i * 1.1f) * 0.05f * r
        val centerPos = Offset(c.x - r + px * 2 * r + driftX, c.y - r + py * 2 * r + driftY)
        val plateR = r * (0.28f + 0.04f * sin(rad + i))
        drawCircle(
            brush = Brush.radialGradient(
                0.0f to Color(0xFF150204).copy(alpha = 0.88f),
                0.7f to Color(0xFF38060A).copy(alpha = 0.75f),
                1.0f to Color.Transparent,
                center = centerPos,
                radius = plateR
            ),
            radius = plateR,
            center = centerPos
        )
    }

    // Volcanic fissure streaks
    rotate(degrees = t * 0.5f, pivot = c) {
        drawCircle(
            brush = Brush.sweepGradient(
                0.00f to highlight.copy(alpha = 0.70f),
                0.15f to Color.Transparent,
                0.35f to accent.copy(alpha = 0.65f),
                0.55f to Color.Transparent,
                0.75f to mid1.copy(alpha = 0.70f),
                1.00f to highlight.copy(alpha = 0.70f),
                center = c
            ),
            radius = r * 0.90f,
            center = c,
            style = Stroke(width = max(1.5f, r * 0.035f))
        )
    }
}
