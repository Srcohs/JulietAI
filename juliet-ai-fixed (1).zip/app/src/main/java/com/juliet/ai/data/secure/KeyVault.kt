package com.juliet.ai.data.secure

import android.content.Context
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Hardware-backed key handling.
 *  - A non-exportable AES-256 key lives inside Android Keystore (StrongBox when the phone has it).
 *  - A random 256-bit database passphrase is generated once, wrapped (AES-GCM) by that key,
 *    and only the wrapped blob is stored on disk. The Keystore key never leaves secure hardware.
 */
object KeyVault {
    private const val ALIAS = "juliet_master_v1"
    private const val PREF_FILE = "juliet_vault"
    private const val PREF_KEY = "db_pass_wrapped"
    private const val ANDROID_KS = "AndroidKeyStore"

    @Volatile private var cached: ByteArray? = null

    private fun keyStore(): KeyStore = KeyStore.getInstance(ANDROID_KS).apply { load(null) }

    private fun masterKey(): SecretKey {
        (keyStore().getKey(ALIAS, null) as? SecretKey)?.let { return it }
        fun gen(strongBox: Boolean): SecretKey {
            val b = KeyGenParameterSpec.Builder(
                ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
            if (strongBox && Build.VERSION.SDK_INT >= 28) b.setIsStrongBoxBacked(true)
            val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KS)
            kg.init(b.build())
            return kg.generateKey()
        }
        return try { gen(true) } catch (e: Exception) { gen(false) }   // StrongBox missing -> TEE
    }

    fun encrypt(plain: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, masterKey())
        return c.iv + c.doFinal(plain)               // 12-byte IV + ciphertext
    }

    fun decrypt(blob: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, masterKey(), GCMParameterSpec(128, blob, 0, 12))
        return c.doFinal(blob, 12, blob.size - 12)
    }

    /** Passphrase for SQLCipher (64 hex chars as bytes). Returns a fresh copy each call. */
    @Synchronized
    fun dbPassphrase(ctx: Context): ByteArray {
        cached?.let { return it.copyOf() }
        val sp = ctx.applicationContext.getSharedPreferences(PREF_FILE, Context.MODE_PRIVATE)
        val stored = sp.getString(PREF_KEY, null)
        val pass: ByteArray = if (stored != null) {
            decrypt(Base64.decode(stored, Base64.NO_WRAP))      // throws if Keystore key was lost
        } else {
            val raw = ByteArray(32).also { SecureRandom().nextBytes(it) }
            val hex = raw.joinToString("") { "%02x".format(it) }.toByteArray(Charsets.US_ASCII)
            sp.edit().putString(PREF_KEY, Base64.encodeToString(encrypt(hex), Base64.NO_WRAP)).commit()
            hex
        }
        cached = pass
        return pass.copyOf()
    }

    /** Forget the passphrase and Keystore key (used by "Delete all data"). */
    @Synchronized
    fun reset(ctx: Context) {
        cached = null
        ctx.applicationContext.getSharedPreferences(PREF_FILE, Context.MODE_PRIVATE).edit().clear().commit()
        try { keyStore().deleteEntry(ALIAS) } catch (_: Exception) {}
    }
}
