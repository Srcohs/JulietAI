package com.juliet.ai.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.juliet.ai.screen.JulietAccessibilityService
import com.juliet.ai.screen.JulietScreenCaptureService
import com.juliet.ai.screen.SharingState
import com.juliet.ai.vm.JulietViewModel
import com.juliet.ai.wa.WhatsAppDiagnostics

@Composable
fun DiagnosticsScreen(
    vm: JulietViewModel,
    askPerm: (String, (Boolean) -> Unit) -> Unit
) {
    val ctx = LocalContext.current
    val p = LocalPal.current
    var diagTestResult by remember { mutableStateOf<String?>(null) }
    var isTestingAudio by remember { mutableStateOf(false) }

    fun isGranted(perm: String): Boolean =
        ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED

    val audioGranted = isGranted(Manifest.permission.RECORD_AUDIO)
    val callGranted = isGranted(Manifest.permission.CALL_PHONE)
    val contactsGranted = isGranted(Manifest.permission.READ_CONTACTS)
    val notifGranted = isGranted(Manifest.permission.POST_NOTIFICATIONS)
    val cameraGranted = isGranted(Manifest.permission.CAMERA)
    val a11yActive = JulietAccessibilityService.isRunning()
    val notifServiceActive = WhatsAppDiagnostics.isListenerConnected
    val sharingActive = JulietScreenCaptureService.sharingState.value != SharingState.Inactive

    Page("Diagnostics & Permissions", { vm.back() }) {
        // System Health Summary Card
        val totalIssues = (if (!audioGranted) 1 else 0) +
                (if (!callGranted) 1 else 0) +
                (if (!contactsGranted) 1 else 0) +
                (if (!a11yActive) 1 else 0) +
                (if (!notifServiceActive) 1 else 0)

        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (totalIssues == 0) J.Ok.copy(alpha = 0.12f) else J.Red.copy(alpha = 0.12f)
            ),
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
                .border(1.dp, if (totalIssues == 0) J.Ok.copy(alpha = 0.3f) else J.Red.copy(alpha = 0.3f), RoundedCornerShape(20.dp))
        ) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(44.dp).clip(CircleShape)
                        .background(if (totalIssues == 0) J.Ok.copy(alpha = 0.2f) else J.Red.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (totalIssues == 0) Icons.Rounded.CheckCircle else Icons.Rounded.Warning,
                        contentDescription = null,
                        tint = if (totalIssues == 0) J.Ok else J.Red,
                        modifier = Modifier.size(26.dp)
                    )
                }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text(
                        text = if (totalIssues == 0) "All Systems Operational" else "$totalIssues Permissions / Services Need Attention",
                        color = p.text,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Text(
                        text = if (totalIssues == 0) "Voice control, screen actions & notifications are fully enabled." else "Some features will be restricted until granted.",
                        color = p.mu,
                        fontSize = 13.sp
                    )
                }
            }
        }

        // Core System Services
        Sec("SYSTEM SERVICES")
        Group {
            DiagServiceRow(
                icon = Icons.Rounded.Accessibility,
                title = "Accessibility Service",
                desc = "Required for screen tapping, reading & typing",
                active = a11yActive,
                actionLabel = if (a11yActive) "Running" else "Enable",
                onAction = {
                    ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            )
            HorizontalDivider(color = p.border, thickness = 0.5.dp)
            DiagServiceRow(
                icon = Icons.Rounded.NotificationsActive,
                title = "Notification Listener",
                desc = "Required for reading WhatsApp & system alerts",
                active = notifServiceActive,
                actionLabel = if (notifServiceActive) "Running" else "Enable",
                onAction = {
                    ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            )
            HorizontalDivider(color = p.border, thickness = 0.5.dp)
            DiagServiceRow(
                icon = Icons.Rounded.ScreenShare,
                title = "Screen Sharing & Vision",
                desc = "Required for Gemini live visual screen inspection",
                active = sharingActive,
                actionLabel = if (sharingActive) "Active" else "Control",
                onAction = { vm.navigate(com.juliet.ai.data.Screen.ScreenControl) }
            )
        }

        // Hardware Permissions
        Sec("HARDWARE & ANDROID PERMISSIONS")
        Group {
            DiagPermRow(
                icon = Icons.Rounded.Mic,
                title = "Microphone",
                desc = "Hands-free voice recognition & wake word",
                granted = audioGranted,
                onRequest = { askPerm(Manifest.permission.RECORD_AUDIO) {} }
            )
            HorizontalDivider(color = p.border, thickness = 0.5.dp)
            DiagPermRow(
                icon = Icons.Rounded.Call,
                title = "Phone Calls",
                desc = "Hands-free calling to contacts & dialer",
                granted = callGranted,
                onRequest = { askPerm(Manifest.permission.CALL_PHONE) {} }
            )
            HorizontalDivider(color = p.border, thickness = 0.5.dp)
            DiagPermRow(
                icon = Icons.Rounded.Contacts,
                title = "Contacts",
                desc = "Search & resolve caller / SMS recipients",
                granted = contactsGranted,
                onRequest = { askPerm(Manifest.permission.READ_CONTACTS) {} }
            )
            HorizontalDivider(color = p.border, thickness = 0.5.dp)
            DiagPermRow(
                icon = Icons.Rounded.CameraAlt,
                title = "Camera",
                desc = "Photo sketch & visual queries",
                granted = cameraGranted,
                onRequest = { askPerm(Manifest.permission.CAMERA) {} }
            )
            HorizontalDivider(color = p.border, thickness = 0.5.dp)
            DiagPermRow(
                icon = Icons.Rounded.Notifications,
                title = "Post Notifications",
                desc = "Show reminders, summaries & background alerts",
                granted = notifGranted,
                onRequest = { askPerm(Manifest.permission.POST_NOTIFICATIONS) {} }
            )
        }

        // Interactive Diagnostics
        Sec("RUN INTERACTIVE TESTS")
        Group {
            Item("🎙️", "Test Audio Capture", "Check real microphone input & energy level") {
                isTestingAudio = true
                diagTestResult = "Listening to microphone input..."
                vm.voiceEnrollment.recordSample(
                    durationMillis = 2000L,
                    onLevelUpdate = {},
                    onResult = { embedding, msg ->
                        isTestingAudio = false
                        diagTestResult = if (embedding != null) "✔ Microphone test passed: Audio captured and acoustic features computed successfully!" else "✖ Audio test failed: $msg"
                    }
                )
            }
            Item("🖥️", "Test Screen Reader (Accessibility)", "Inspect visible nodes & text on current view") {
                val a11y = JulietAccessibilityService.instance
                if (a11y != null) {
                    val dump = a11y.dumpScreenText()
                    val lineCount = dump.lines().size
                    diagTestResult = "✔ Screen Reader active! Successfully extracted $lineCount interface elements."
                } else {
                    diagTestResult = "✖ Juliet Accessibility Service is not active. Please enable it in Settings."
                }
            }
            Item("⚙️", "Open Juliet App Info Settings", "Manage all system permissions, battery optimization") {
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.fromParts("package", ctx.packageName, null)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                ctx.startActivity(intent)
            }
        }

        // Test Result Notice Box
        diagTestResult?.let { msg ->
            Spacer(Modifier.height(14.dp))
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = p.card2),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(msg, color = p.text, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    IconButton(onClick = { diagTestResult = null }) {
                        Icon(Icons.Rounded.Close, contentDescription = "Dismiss", tint = p.mu)
                    }
                }
            }
        }
    }
}

@Composable
private fun DiagServiceRow(
    icon: ImageVector,
    title: String,
    desc: String,
    active: Boolean,
    actionLabel: String,
    onAction: () -> Unit
) {
    val p = LocalPal.current
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(36.dp).clip(CircleShape)
                .background(if (active) J.Ok.copy(alpha = 0.2f) else J.Red.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (active) J.Ok else J.Red,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = p.text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text(desc, color = p.mu, fontSize = 12.sp)
        }
        Button(
            onClick = onAction,
            colors = ButtonDefaults.buttonColors(
                containerColor = if (active) p.card2 else J.Red
            ),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Text(actionLabel, color = if (active) p.text else Color.White, fontSize = 13.sp)
        }
    }
}

@Composable
private fun DiagPermRow(
    icon: ImageVector,
    title: String,
    desc: String,
    granted: Boolean,
    onRequest: () -> Unit
) {
    val p = LocalPal.current
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(36.dp).clip(CircleShape)
                .background(if (granted) J.Ok.copy(alpha = 0.2f) else p.card2),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (granted) J.Ok else p.mu,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = p.text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text(desc, color = p.mu, fontSize = 12.sp)
        }
        if (granted) {
            Text("Granted ✔", color = J.Ok, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        } else {
            Button(
                onClick = onRequest,
                colors = ButtonDefaults.buttonColors(containerColor = J.Gold),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text("Grant", color = Color.Black, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
