package com.juliet.ai.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.juliet.ai.ann.Announcer
import com.juliet.ai.data.BotCategories
import com.juliet.ai.data.BotNode
import com.juliet.ai.data.XmlImportResult
import com.juliet.ai.data.KEntry
import com.juliet.ai.data.Prefs
import com.juliet.ai.vm.JulietViewModel
import com.juliet.ai.wa.WhatsAppDiagnostics

@Composable
private fun Field(value: String, onValue: (String) -> Unit, hint: String, single: Boolean = true) {
    val p = LocalPal.current
    OutlinedTextField(
        value, onValue, Modifier.fillMaxWidth().padding(bottom = 10.dp), singleLine = single, minLines = if (single) 1 else 3,
        placeholder = { Text(hint, color = p.mu) }, shape = RoundedCornerShape(22.dp),
        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = J.Red, unfocusedBorderColor = p.border, cursorColor = J.Crim, focusedTextColor = p.text, unfocusedTextColor = p.text)
    )
}

private fun openListenerSettings(ctx: Context) {
    ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

@Composable
fun KnowledgeScreen(vm: JulietViewModel) {
    val p = LocalPal.current
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    var viewingTemplateExample by remember { mutableStateOf(false) }

    if (viewingTemplateExample) {
        XmlTemplateExampleScreen(onBack = { viewingTemplateExample = false })
        return
    }

    Page("Knowledge", { vm.back() }) {
        var selectedTab by remember { mutableIntStateOf(0) } // 0: Categories, 1: Import XML, 2: Export, 3: Live Simulator

        val botCategories = remember(ctx) { BotCategories(Prefs(ctx)) }
        var categoriesVersion by remember { mutableIntStateOf(0) }
        val botNodes = remember(categoriesVersion) { botCategories.all() }
        val rootNodes = botNodes.filter { it.type == "category" && it.enabled }

        var renameNode by remember { mutableStateOf<BotNode?>(null) }
        var renameText by remember { mutableStateOf("") }
        var answerNode by remember { mutableStateOf<BotNode?>(null) }
        var answerText by remember { mutableStateOf("") }
        var showAddCategoryDialog by remember { mutableStateOf(false) }
        var newCategoryName by remember { mutableStateOf("") }
        var showAddSubDialog by remember { mutableStateOf<BotNode?>(null) }
        var newSubName by remember { mutableStateOf("") }
        var showAddOptionDialog by remember { mutableStateOf<BotNode?>(null) }
        var newOptionName by remember { mutableStateOf("") }
        var newOptionAnswer by remember { mutableStateOf("") }

        var xmlErrors by remember { mutableStateOf<List<String>>(emptyList()) }
        val xmlPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) {
                val res = runCatching { BotCategories.importFromUriChecked(ctx, uri, botCategories) }
                    .getOrElse { XmlImportResult(0, listOf("Import failed: ${it.message ?: "unknown error"}")) }
                if (res.errors.isEmpty()) {
                    categoriesVersion++
                    Toast.makeText(ctx, "Imported ${res.imported} items ✔ (existing entries were kept)", Toast.LENGTH_LONG).show()
                } else xmlErrors = res.errors
            }
        }
        if (xmlErrors.isNotEmpty()) AlertDialog(
            onDismissRequest = { xmlErrors = emptyList() },
            title = { Text("Couldn't import this XML") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(6.dp)) { xmlErrors.forEach { Text("• $it", fontSize = 14.sp) }; Text("Nothing was changed. Fix the file and try again.", fontSize = 13.sp) } },
            confirmButton = { TextButton({ xmlErrors = emptyList() }) { Text("OK") } }
        )

        LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.permTick++ }
        val tick = vm.permTick
        val listenerOn = remember(tick) { NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName) }
        val botActive = vm.s("wa_auto") == "1"

        // 3 Segmented Pills: [Categories] [Import XML] [Export] (Matching Reference UI Screen 7)
        Row(
            Modifier.fillMaxWidth().padding(bottom = 18.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            listOf("Categories", "Import XML", "Export", "Live Test").forEachIndexed { index, label ->
                val sel = selectedTab == index
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(30.dp))
                        .then(
                            if (sel) Modifier.background(J.Red)
                            else Modifier.background(p.card).border(1.dp, p.border, RoundedCornerShape(30.dp))
                        )
                        .clickable { selectedTab = index }
                        .padding(vertical = 11.dp),
                    Alignment.Center
                ) {
                    Text(
                        label,
                        color = if (sel) Color.White else p.mu,
                        fontSize = 13.sp,
                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }

        // ==============================================================
        // TAB 0: CATEGORIES (MANAGE MANUALLY & HIERARCHY)
        // ==============================================================
        if (selectedTab == 0) {
            Sec("BOT MODE")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf("category" to "📂 Category Menu", "auto" to "🤖 Auto AI").forEach { (m, label) ->
                    val sel = vm.s("wa_mode") == m
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(16.dp))
                            .then(if (sel) Modifier.background(J.Red) else Modifier.background(p.card).border(1.dp, p.border, RoundedCornerShape(16.dp)))
                            .clickable { vm.set("wa_mode", m) }
                            .padding(vertical = 14.dp),
                        Alignment.Center
                    ) { Text(label, color = if (sel) Color.White else p.mu, fontSize = 14.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium) }
                }
            }
            Sub(if (vm.s("wa_mode") == "auto")
                "Auto AI: reads the whole chat and answers ONLY from your categories and saved knowledge. Anything else gets no reply."
            else
                "Category Menu: Hi/Salam shows your categories first. Senders pick a number or name. Anything not in your menu gets no reply.")
            Group {
                Item("🔕", "When bot is unsure", if (vm.s("wa_unknown") == "menu") "Send the category menu again" else "Stay silent (you get an alert)") {
                    vm.cycle("wa_unknown", listOf("silent", "menu"))
                }
            }
            Spacer(Modifier.height(12.dp))
            Sec("WELCOME MESSAGE")
            Field(vm.s("wa_welcome"), { vm.set("wa_welcome", it) }, "Shown first when someone says Hi (optional)", single = false)
            Spacer(Modifier.height(12.dp))
            Sec("MANAGE MANUALLY")
            Group {
                Item("➕", "Add Category", "Create a new top-level menu category") {
                    newCategoryName = ""
                    showAddCategoryDialog = true
                }
                Item("🤖", "WhatsApp Auto-Reply Status", if (listenerOn && botActive) "Active · Replying to private chats" else "Configure permissions & toggle") {
                    selectedTab = 3
                }
            }

            Spacer(Modifier.height(10.dp))
            Sec("ACTIVE MENU TREE (${rootNodes.size} CATEGORIES)")
            Sub("Incoming messages like 'Hi' or 'Salam' receive these categories. Senders reply with numbers or titles to navigate down to the configured answer.")

            if (rootNodes.isEmpty()) {
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(p.card).border(1.dp, p.border, RoundedCornerShape(22.dp)).padding(24.dp),
                    Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("📋", fontSize = 36.sp)
                        Text("No Categories Configured", color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text("Load the sample template or import an XML sheet to get started.", color = p.mu, fontSize = 13.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        Box(
                            Modifier.clip(RoundedCornerShape(24.dp)).background(J.Red)
                                .clickable {
                                    val count = runCatching { ctx.assets.open("whatsapp-categories-template.xml").use { botCategories.importXml(it) } }.getOrDefault(0)
                                    categoriesVersion++
                                    Toast.makeText(ctx, "Loaded $count sample items ✔", Toast.LENGTH_SHORT).show()
                                }.padding(horizontal = 20.dp, vertical = 10.dp)
                        ) {
                            Text("Load Sample Template", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else {
                rootNodes.forEachIndexed { catIdx, cat ->
                    val subNodes = botNodes.filter { it.type == "subcategory" && it.parentId == cat.id && it.enabled }
                    Column(
                        Modifier.fillMaxWidth().padding(bottom = 12.dp).clip(RoundedCornerShape(22.dp))
                            .background(p.card).border(1.dp, Brush.linearGradient(listOf(Color(0xFFE91E63).copy(alpha = 0.5f), p.border)), RoundedCornerShape(22.dp))
                            .padding(14.dp)
                    ) {
                        // Category Header
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Box(Modifier.size(32.dp).clip(CircleShape).background(J.Red), Alignment.Center) {
                                    Text("${catIdx + 1}", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black)
                                }
                                Text(cat.title, color = p.text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("+ Sub", color = J.Ok, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable { showAddSubDialog = cat; newSubName = "" })
                                Text("Rename", color = J.Crim, fontSize = 12.sp, modifier = Modifier.clickable { renameNode = cat; renameText = cat.title })
                                Text("Delete", color = J.Red, fontSize = 12.sp, modifier = Modifier.clickable { botCategories.delete(cat.id); categoriesVersion++ })
                            }
                        }

                        if (subNodes.isEmpty()) {
                            Text("No subcategories yet under this category.", color = p.mu, fontSize = 12.sp, modifier = Modifier.padding(start = 42.dp, top = 6.dp))
                        } else {
                            subNodes.forEachIndexed { subIdx, sub ->
                                val options = botNodes.filter { it.type == "option" && it.parentId == sub.id && it.enabled }
                                Column(
                                    Modifier.fillMaxWidth().padding(start = 14.dp, top = 10.dp).clip(RoundedCornerShape(16.dp))
                                        .background(p.card2).border(1.dp, p.border, RoundedCornerShape(16.dp))
                                        .padding(12.dp)
                                ) {
                                    // Subcategory Header
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                        Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text("↳ [${catIdx + 1}.${subIdx + 1}]", color = J.Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                            Text(sub.title, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                                        }
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Text("+ Option", color = J.Ok, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable { showAddOptionDialog = sub; newOptionName = ""; newOptionAnswer = "" })
                                            Text("Rename", color = J.Crim, fontSize = 11.sp, modifier = Modifier.clickable { renameNode = sub; renameText = sub.title })
                                            Text("Delete", color = J.Red, fontSize = 11.sp, modifier = Modifier.clickable { botCategories.delete(sub.id); categoriesVersion++ })
                                        }
                                    }

                                    // Options
                                    options.forEachIndexed { optIdx, opt ->
                                        Column(
                                            Modifier.fillMaxWidth().padding(start = 12.dp, top = 8.dp).clip(RoundedCornerShape(12.dp))
                                                .background(p.card).border(1.dp, p.border.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                                                .padding(10.dp)
                                        ) {
                                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                                Text("• Option ${optIdx + 1}: ${opt.title}", color = p.text, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                    Text("Edit Reply", color = J.Crim, fontSize = 11.sp, modifier = Modifier.clickable { answerNode = opt; answerText = opt.answer })
                                                    Text("Delete", color = J.Red, fontSize = 11.sp, modifier = Modifier.clickable { botCategories.delete(opt.id); categoriesVersion++ })
                                                }
                                            }
                                            if (opt.answer.isNotBlank()) {
                                                Box(
                                                    Modifier.fillMaxWidth().padding(top = 6.dp).clip(RoundedCornerShape(10.dp))
                                                        .background(Color(0xFF132A1C)).padding(horizontal = 10.dp, vertical = 6.dp)
                                                ) {
                                                    Text("💬 Reply: \"${opt.answer}\"", color = Color(0xFFB9F6CA), fontSize = 12.sp, lineHeight = 16.sp)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ==============================================================
        // TAB 1: IMPORT XML (Matching Reference UI Screen 7)
        // ==============================================================
        if (selectedTab == 1) {
            // Large Upload XML File Card
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp))
                    .background(p.card).border(1.dp, p.border, RoundedCornerShape(26.dp))
                    .padding(vertical = 32.dp, horizontal = 20.dp),
                Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(Modifier.size(64.dp).clip(CircleShape).background(J.Red.copy(alpha = 0.15f)), Alignment.Center) {
                        Icon(Icons.Rounded.CloudUpload, contentDescription = "Upload", tint = J.Red, modifier = Modifier.size(36.dp))
                    }
                    Text("Upload XML File", color = p.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Add your categories and replies from XML file", color = p.mu, fontSize = 14.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    Spacer(Modifier.height(4.dp))
                    Box(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(30.dp)).background(J.Red)
                            .clickable { xmlPicker.launch(arrayOf("text/xml", "application/xml", "text/*")) }
                            .padding(vertical = 15.dp),
                        Alignment.Center
                    ) {
                        Text("Choose File", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            Sec("PRE-PACKED SAMPLES")
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(p.card2).border(1.dp, p.border, RoundedCornerShape(20.dp))
                    .clickable {
                        val count = runCatching { ctx.assets.open("whatsapp-categories-template.xml").use { botCategories.importXml(it) } }.getOrDefault(0)
                        categoriesVersion++
                        Toast.makeText(ctx, if (count > 0) "Loaded $count sample items (Banking & Education) ✔" else "Template loaded", Toast.LENGTH_SHORT).show()
                    }.padding(16.dp)
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("⚡ Load Banking & Education Sample", color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        Text("Instant 1-tap template with cards, accounts & admissions", color = p.mu, fontSize = 12.sp)
                    }
                    Icon(Icons.Rounded.ChevronRight, null, tint = p.mu)
                }
            }

            Spacer(Modifier.height(12.dp))
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(p.card).border(1.dp, p.border, RoundedCornerShape(20.dp))
                    .clickable { viewingTemplateExample = true }.padding(16.dp)
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("📄", fontSize = 20.sp)
                        Column {
                            Text("View XML Template Example", color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                            Text("Inspect the exact schema format with code preview", color = p.mu, fontSize = 12.sp)
                        }
                    }
                    Icon(Icons.Rounded.ChevronRight, null, tint = p.mu)
                }
            }
        }

        // ==============================================================
        // TAB 2: EXPORT XML
        // ==============================================================
        if (selectedTab == 2) {
            Sec("EXPORT XML SCHEMA")
            Sub("Export your current categories, subcategories, options and answers as a valid XML document that can be shared or re-imported.")

            val exported = remember(categoriesVersion) { botCategories.exportXml() }

            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color(0xFF070408)).border(1.dp, p.border, RoundedCornerShape(20.dp)).padding(14.dp)
            ) {
                Text(exported, color = Color(0xFFFF80AB), fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 16.sp)
            }

            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(26.dp)).background(J.Red)
                        .clickable {
                            clip.setText(AnnotatedString(exported))
                            Toast.makeText(ctx, "XML copied to clipboard ✔", Toast.LENGTH_SHORT).show()
                        }.padding(vertical = 14.dp),
                    Alignment.Center
                ) {
                    Text("Copy XML", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(26.dp)).background(p.card2).border(1.dp, p.border, RoundedCornerShape(26.dp))
                        .clickable {
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/xml"
                                putExtra(Intent.EXTRA_SUBJECT, "juliet-categories.xml")
                                putExtra(Intent.EXTRA_TEXT, exported)
                            }
                            ctx.startActivity(Intent.createChooser(shareIntent, "Share Categories XML"))
                        }.padding(vertical = 14.dp),
                    Alignment.Center
                ) {
                    Text("Share XML", color = p.text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // ==============================================================
        // ==============================================================
        // TAB 3: LIVE SIMULATOR & DIAGNOSTICS (Matching Screens 2, 3, 4, 5)
        // ==============================================================
        if (selectedTab == 3) {
            Sec("WHATSAPP AUTO-REPLY STATUS")
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
                    .background(Brush.horizontalGradient(listOf(Color(0xFF0F261A), Color(0xFF1B3D2A))))
                    .border(1.dp, if (listenerOn && botActive) Color(0xFF25D366) else J.Gold, RoundedCornerShape(22.dp))
                    .padding(16.dp)
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("WhatsApp Bot Status", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text(
                            if (listenerOn && botActive) "🟢 ONLINE · Responding to WhatsApp" else if (!listenerOn) "⚠️ Notification access needed" else "⏸ Paused",
                            color = if (listenerOn && botActive) Color(0xFFB9F6CA) else Color(0xFFFFD54F),
                            fontSize = 12.sp
                        )
                    }
                    Switch(
                        checked = botActive,
                        onCheckedChange = { if (it) vm.setAutoReply(true) else vm.setAutoReply(false) },
                        colors = SwitchDefaults.colors(checkedTrackColor = Color(0xFF25D366), checkedThumbColor = Color.White)
                    )
                }
            }

            Spacer(Modifier.height(14.dp))
            Sec("INTERACTIVE CHAT SIMULATOR (SCREENS 2–5)")
            Sub("Preview and interact with WhatsApp Auto-Reply states from the design reference collage.")

            var simMode by remember { mutableIntStateOf(0) } // 0: Categories (Screen 2), 1: Subcategories (Screen 3), 2: Final Answer (Screen 4), 3: Gemini Fallback (Screen 5), 4: Live Interactive
            var activeCategoryName by remember { mutableStateOf("Banking") }
            var simInput by remember { mutableStateOf("") }

            // Mode Selector Pills
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    "Categories (Screen 2)",
                    "Subcategories (Screen 3)",
                    "Final Answer (Screen 4)",
                    "Gemini Fallback (Screen 5)",
                    "Live Interactive"
                ).forEachIndexed { idx, label ->
                    val sel = simMode == idx
                    Box(
                        Modifier.clip(RoundedCornerShape(18.dp))
                            .then(if (sel) Modifier.background(ThemeConstants.NeonPink) else Modifier.background(p.card2).border(1.dp, p.border, RoundedCornerShape(18.dp)))
                            .clickable { simMode = idx }
                            .padding(horizontal = 12.dp, vertical = 7.dp)
                    ) {
                        Text(label, color = if (sel) Color.White else p.mu, fontSize = 12.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium)
                    }
                }
            }

            // WhatsApp Frame Container with Glassmorphism
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp))
                    .background(ThemeConstants.BurgundyBackground)
                    .border(1.5.dp, ThemeConstants.NeonPink.copy(alpha = 0.35f), RoundedCornerShape(26.dp))
                    .padding(bottom = 12.dp)
            ) {
                Column(Modifier.fillMaxWidth()) {
                    // WhatsApp Chat Header
                    Row(
                        Modifier.fillMaxWidth().background(ThemeConstants.BurgundyDeep)
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = Color.White, modifier = Modifier.size(20.dp).clickable { simMode = 0 })
                        Box(Modifier.size(36.dp).clip(CircleShape).background(ThemeConstants.BrandGradient), Alignment.Center) {
                            Text("🤖", fontSize = 18.sp)
                        }
                        Column(Modifier.weight(1f)) {
                            Text("Juliet", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Box(Modifier.size(7.dp).clip(CircleShape).background(Color(0xFF25D366)))
                                Text("Online", color = Color(0xFF25D366), fontSize = 11.sp)
                            }
                        }
                        Icon(Icons.Rounded.MoreVert, contentDescription = "Menu", tint = Color.White, modifier = Modifier.size(20.dp))
                    }

                    // Simulated Chat Body
                    Column(
                        Modifier.fillMaxWidth().padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        when (simMode) {
                            // -------------------------------------------------------------
                            // SCREEN 2: WhatsApp Categories (after "Hi")
                            // -------------------------------------------------------------
                            0 -> {
                                // Juliet Greeting Bubble
                                Box(
                                    Modifier.fillMaxWidth(0.9f).clip(RoundedCornerShape(16.dp, 16.dp, 16.dp, 4.dp))
                                        .background(ThemeConstants.BurgundySurface)
                                        .border(1.dp, ThemeConstants.NeonPink.copy(alpha = 0.25f), RoundedCornerShape(16.dp, 16.dp, 16.dp, 4.dp))
                                        .padding(14.dp)
                                ) {
                                    Column {
                                        Text("Hi 👋", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                        Spacer(Modifier.height(4.dp))
                                        Text("Assalamu alaikum! Welcome to Juliet. How can I help you today?\n\nPlease select a category below:", color = Color(0xFFF0E6EC), fontSize = 14.sp, lineHeight = 19.sp)
                                        Text("8:57 PM", color = p.mu, fontSize = 10.sp, modifier = Modifier.align(Alignment.End).padding(top = 4.dp))
                                    }
                                }

                                // 2-Column Category Grid
                                val categoriesList = listOf(
                                    Triple("🏛️", "Banking", Icons.Rounded.AccountBalance),
                                    Triple("🎓", "Education", Icons.Rounded.School),
                                    Triple("💖", "Health & Medical", Icons.Rounded.Favorite),
                                    Triple("⚙️", "Services", Icons.Rounded.Settings),
                                    Triple("📱", "Technology", Icons.Rounded.PhoneAndroid),
                                    Triple("ℹ️", "General Info", Icons.Rounded.Info)
                                )

                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    for (i in categoriesList.indices step 2) {
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            val c1 = categoriesList[i]
                                            Box(
                                                Modifier.weight(1f).clip(RoundedCornerShape(16.dp))
                                                    .background(ThemeConstants.BurgundyDark.copy(alpha = 0.5f))
                                                    .border(1.dp, ThemeConstants.NeonPink.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                                                    .clickable {
                                                        activeCategoryName = c1.second
                                                        simMode = 1
                                                    }
                                                    .padding(vertical = 14.dp, horizontal = 10.dp),
                                                Alignment.Center
                                            ) {
                                                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                                    Icon(c1.third, contentDescription = c1.second, tint = ThemeConstants.NeonPink, modifier = Modifier.size(24.dp))
                                                    Text(c1.second, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                                }
                                            }
                                            if (i + 1 < categoriesList.size) {
                                                val c2 = categoriesList[i + 1]
                                                Box(
                                                    Modifier.weight(1f).clip(RoundedCornerShape(16.dp))
                                                        .background(ThemeConstants.BurgundyDark.copy(alpha = 0.5f))
                                                        .border(1.dp, ThemeConstants.NeonPink.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                                                        .clickable {
                                                            activeCategoryName = c2.second
                                                            simMode = 1
                                                        }
                                                        .padding(vertical = 14.dp, horizontal = 10.dp),
                                                    Alignment.Center
                                                ) {
                                                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                                        Icon(c2.third, contentDescription = c2.second, tint = ThemeConstants.NeonPink, modifier = Modifier.size(24.dp))
                                                        Text(c2.second, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                Text("You can also type your question in simple words.", color = p.mu, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 2.dp))
                            }

                            // -------------------------------------------------------------
                            // SCREEN 3: Subcategory Options (Banking)
                            // -------------------------------------------------------------
                            1 -> {
                                // Category Pill Header
                                Box(
                                    Modifier.align(Alignment.End).clip(RoundedCornerShape(20.dp))
                                        .background(ThemeConstants.BurgundyDark)
                                        .border(1.dp, ThemeConstants.NeonPink, RoundedCornerShape(20.dp))
                                        .padding(horizontal = 14.dp, vertical = 7.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Icon(Icons.Rounded.AccountBalance, null, tint = ThemeConstants.NeonPink, modifier = Modifier.size(16.dp))
                                        Text(activeCategoryName, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                // Juliet Subcategory prompt
                                Box(
                                    Modifier.fillMaxWidth(0.9f).clip(RoundedCornerShape(16.dp, 16.dp, 16.dp, 4.dp))
                                        .background(ThemeConstants.BurgundySurface)
                                        .border(1.dp, ThemeConstants.NeonPink.copy(alpha = 0.25f), RoundedCornerShape(16.dp, 16.dp, 16.dp, 4.dp))
                                        .padding(14.dp)
                                ) {
                                    Column {
                                        Text("Please choose a subcategory from the options below:", color = Color.White, fontSize = 14.sp)
                                        Text("8:58 PM", color = p.mu, fontSize = 10.sp, modifier = Modifier.align(Alignment.End).padding(top = 4.dp))
                                    }
                                }

                                // Vertical Subcategory List
                                val subcategories = listOf(
                                    Pair("👥", "Account Services"),
                                    Pair("💳", "Cards"),
                                    Pair("💻", "Internet Banking"),
                                    Pair("💸", "Loans"),
                                    Pair("🏦", "Branches & ATMs"),
                                    Pair("💬", "Complaint / Support")
                                )

                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    subcategories.forEach { (icon, title) ->
                                        Box(
                                            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                                                .background(ThemeConstants.BurgundySurface)
                                                .border(1.dp, ThemeConstants.NeonPink.copy(alpha = 0.25f), RoundedCornerShape(14.dp))
                                                .clickable { simMode = 2 }
                                                .padding(horizontal = 14.dp, vertical = 12.dp)
                                        ) {
                                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                                    Text(icon, fontSize = 18.sp)
                                                    Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                                }
                                                Icon(Icons.Rounded.ChevronRight, null, tint = ThemeConstants.NeonPink, modifier = Modifier.size(18.dp))
                                            }
                                        }
                                    }
                                }
                            }

                            // -------------------------------------------------------------
                            // SCREEN 4: Final Answer Example
                            // -------------------------------------------------------------
                            2 -> {
                                // Breadcrumb Badge
                                Box(
                                    Modifier.align(Alignment.Start).clip(RoundedCornerShape(16.dp))
                                        .background(ThemeConstants.BurgundyDark)
                                        .border(1.dp, ThemeConstants.NeonPink.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text("🏛️ Banking  >  Account Services", color = ThemeConstants.NeonPinkLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }

                                // User Message Bubble
                                Box(
                                    Modifier.align(Alignment.End).clip(RoundedCornerShape(16.dp, 16.dp, 4.dp, 16.dp))
                                        .background(Color(0xFF005C4B))
                                        .padding(horizontal = 14.dp, vertical = 10.dp)
                                ) {
                                    Column {
                                        Text("Mera balance kaise check karun?", color = Color.White, fontSize = 14.sp)
                                        Row(Modifier.align(Alignment.End).padding(top = 2.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Text("8:59 PM", color = Color(0xFFB9F6CA), fontSize = 10.sp)
                                            Text("✓✓", color = Color(0xFF34B7F1), fontSize = 11.sp, fontWeight = FontWeight.Black)
                                        }
                                    }
                                }

                                // Juliet Step-by-Step Answer
                                Box(
                                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp, 16.dp, 16.dp, 4.dp))
                                        .background(ThemeConstants.BurgundySurface)
                                        .border(1.dp, ThemeConstants.NeonPink.copy(alpha = 0.45f), RoundedCornerShape(16.dp, 16.dp, 16.dp, 4.dp))
                                        .padding(14.dp)
                                ) {
                                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text("✦", color = ThemeConstants.NeonPink, fontSize = 14.sp)
                                            Text("Aap apna account balance check karne ke liye in steps ko follow karein:", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                        }
                                        Text(
                                            "1. Apne mobile banking app mein login karein.\n" +
                                                "2. \"Account Balance\" option par click karein.\n" +
                                                "3. Apna PIN enter karein.\n" +
                                                "4. Aapka balance screen par show ho jayega.\n\n" +
                                                "Agar aapko aur madad chahiye to main yahin hoon! ❤️",
                                            color = Color(0xFFF5EBF0), fontSize = 13.sp, lineHeight = 19.sp
                                        )
                                        Text("8:59 PM", color = p.mu, fontSize = 10.sp, modifier = Modifier.align(Alignment.End))
                                    }
                                }

                                // Action Chips
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Box(
                                        Modifier.clip(RoundedCornerShape(16.dp)).background(ThemeConstants.BurgundyDark)
                                            .border(1.dp, ThemeConstants.NeonPink.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                                            .clickable { simMode = 3 }
                                            .padding(horizontal = 12.dp, vertical = 7.dp)
                                    ) {
                                        Text("Aur madad chahiye", color = Color.White, fontSize = 12.sp)
                                    }
                                    Box(
                                        Modifier.clip(RoundedCornerShape(16.dp)).background(ThemeConstants.BurgundyDark)
                                            .border(1.dp, ThemeConstants.NeonPink.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                                            .clickable { simMode = 0 }
                                            .padding(horizontal = 12.dp, vertical = 7.dp)
                                    ) {
                                        Text("Back to categories", color = Color.White, fontSize = 12.sp)
                                    }
                                }
                            }

                            // -------------------------------------------------------------
                            // SCREEN 5: Gemini Fallback (General Chat)
                            // -------------------------------------------------------------
                            3 -> {
                                // User Empathy Message
                                Box(
                                    Modifier.align(Alignment.End).clip(RoundedCornerShape(16.dp, 16.dp, 4.dp, 16.dp))
                                        .background(Color(0xFF005C4B))
                                        .padding(horizontal = 14.dp, vertical = 10.dp)
                                ) {
                                    Column {
                                        Text("Mera aaj tabiyat thik nahi hai", color = Color.White, fontSize = 14.sp)
                                        Row(Modifier.align(Alignment.End).padding(top = 2.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Text("8:01 PM", color = Color(0xFFB9F6CA), fontSize = 10.sp)
                                            Text("✓✓", color = Color(0xFF34B7F1), fontSize = 11.sp, fontWeight = FontWeight.Black)
                                        }
                                    }
                                }

                                // Juliet Caring Gemini Response
                                Box(
                                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp, 16.dp, 16.dp, 4.dp))
                                        .background(ThemeConstants.BurgundySurface)
                                        .border(1.dp, ThemeConstants.NeonPink.copy(alpha = 0.45f), RoundedCornerShape(16.dp, 16.dp, 16.dp, 4.dp))
                                        .padding(14.dp)
                                ) {
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text(
                                            "Aap ki tabiyat ka masla sun kar mujhe afsos hua. Khayal rakhein, zyada aaram karein, pani peete rahen aur agar tabiyat zyada kharab ho to doctor se checkup zaroor karein.\n\nMain hamesha aap ke saath hoon. Aap be fikr rahen. ❤️",
                                            color = Color.White, fontSize = 14.sp, lineHeight = 20.sp
                                        )
                                        Text("9:01 PM", color = p.mu, fontSize = 10.sp, modifier = Modifier.align(Alignment.End))
                                    }
                                }

                                // Gemini Response Badge
                                Box(
                                    Modifier.clip(RoundedCornerShape(16.dp)).background(ThemeConstants.BurgundyDark)
                                        .border(1.dp, ThemeConstants.NeonPink, RoundedCornerShape(16.dp))
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text("✦", color = ThemeConstants.NeonPink, fontSize = 12.sp)
                                        Text("Gemini Response", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            // -------------------------------------------------------------
                            // LIVE INTERACTIVE MODE
                            // -------------------------------------------------------------
                            4 -> {
                                if (vm.testResult.isNotEmpty()) {
                                    Box(
                                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                                            .background(ThemeConstants.BurgundySurface)
                                            .border(1.dp, ThemeConstants.NeonPink, RoundedCornerShape(16.dp))
                                            .padding(14.dp)
                                    ) {
                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                Text("🤖", fontSize = 16.sp)
                                                Text("Juliet WhatsApp Bot Response", color = ThemeConstants.NeonPink, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                            }
                                            Spacer(Modifier.height(6.dp))
                                            Text(vm.testResult, color = Color.White, fontSize = 14.sp, lineHeight = 20.sp)
                                        }
                                    }
                                } else {
                                    Text("Type a message below or tap 'Hi' to start navigating your active categories live.", color = p.mu, fontSize = 13.sp)
                                }
                            }
                        }
                    }

                    // Simulated WhatsApp Input Bar
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            Modifier.weight(1f).clip(RoundedCornerShape(24.dp))
                                .background(ThemeConstants.BurgundySurface)
                                .border(1.dp, ThemeConstants.NeonPink.copy(alpha = 0.25f), RoundedCornerShape(24.dp))
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("😊", fontSize = 18.sp, modifier = Modifier.padding(end = 8.dp))
                            TextField(
                                value = simInput,
                                onValueChange = { simInput = it },
                                placeholder = { Text("Type a message...", color = p.mu, fontSize = 14.sp) },
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent,
                                    focusedIndicatorColor = Color.Transparent,
                                    unfocusedIndicatorColor = Color.Transparent,
                                    cursorColor = ThemeConstants.NeonPink,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            Icon(Icons.Rounded.AttachFile, "Attach", tint = p.mu, modifier = Modifier.size(20.dp))
                        }
                        Box(
                            Modifier.size(46.dp).clip(CircleShape).background(Color(0xFF25D366))
                                .clickable {
                                    val txt = simInput.trim()
                                    if (txt.isNotEmpty()) {
                                        simMode = 4
                                        vm.testReply(txt, "Customer")
                                        simInput = ""
                                    }
                                },
                            Alignment.Center
                        ) {
                            Icon(Icons.Rounded.Send, "Send", tint = Color.White, modifier = Modifier.size(22.dp))
                        }
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
            Sec("LIVE DIAGNOSTICS")
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(p.card).border(1.dp, p.border, RoundedCornerShape(20.dp)).padding(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("• Status: ${WhatsAppDiagnostics.lastStatus}", color = p.text, fontSize = 13.sp)
                    Text("• Total Processed: ${WhatsAppDiagnostics.totalProcessed} messages", color = p.text, fontSize = 13.sp)
                    Text("• Total Replies: ${WhatsAppDiagnostics.totalReplied} dispatched", color = p.text, fontSize = 13.sp)
                    Text("• Language Policy: Roman Urdu & English ONLY (Zero Hindi, Urdu Script, or Punjabi)", color = Color(0xFFB9F6CA), fontSize = 12.sp)
                }
            }
        }

        // Dialogs for CRUD
        if (showAddCategoryDialog) AlertDialog(
            onDismissRequest = { showAddCategoryDialog = false },
            title = { Text("Add Main Category") },
            text = { Field(newCategoryName, { newCategoryName = it }, "Category name e.g. Banking, Support") },
            confirmButton = {
                TextButton(onClick = {
                    if (botCategories.add(newCategoryName, "category")) {
                        showAddCategoryDialog = false
                        categoriesVersion++
                    } else Toast.makeText(ctx, "Enter a unique category name", Toast.LENGTH_SHORT).show()
                }) { Text("Add", color = J.Red) }
            },
            dismissButton = { TextButton(onClick = { showAddCategoryDialog = false }) { Text("Cancel") } }
        )

        showAddSubDialog?.let { parentCat ->
            AlertDialog(
                onDismissRequest = { showAddSubDialog = null },
                title = { Text("Add Subcategory under ${parentCat.title}") },
                text = { Field(newSubName, { newSubName = it }, "Subcategory name e.g. Cards, Account Services") },
                confirmButton = {
                    TextButton(onClick = {
                        if (botCategories.add(newSubName, "subcategory", parentCat.id)) {
                            showAddSubDialog = null
                            categoriesVersion++
                        } else Toast.makeText(ctx, "Enter a unique subcategory name", Toast.LENGTH_SHORT).show()
                    }) { Text("Add", color = J.Red) }
                },
                dismissButton = { TextButton(onClick = { showAddSubDialog = null }) { Text("Cancel") } }
            )
        }

        showAddOptionDialog?.let { parentSub ->
            AlertDialog(
                onDismissRequest = { showAddOptionDialog = null },
                title = { Text("Add Option under ${parentSub.title}") },
                text = {
                    Column {
                        Field(newOptionName, { newOptionName = it }, "Option name e.g. Debit Card")
                        Field(newOptionAnswer, { newOptionAnswer = it }, "Reply sent when selected", single = false)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        if (botCategories.add(newOptionName, "option", parentSub.id, newOptionAnswer)) {
                            showAddOptionDialog = null
                            categoriesVersion++
                        } else Toast.makeText(ctx, "Enter option name and answer", Toast.LENGTH_SHORT).show()
                    }) { Text("Add", color = J.Red) }
                },
                dismissButton = { TextButton(onClick = { showAddOptionDialog = null }) { Text("Cancel") } }
            )
        }

        if (renameNode != null) AlertDialog(
            onDismissRequest = { renameNode = null },
            title = { Text("Rename item") },
            text = { Field(renameText, { renameText = it }, "New name") },
            confirmButton = { TextButton(onClick = { renameNode?.let { botCategories.rename(it.id, renameText) }; renameNode = null; categoriesVersion++ }) { Text("Save", color = J.Red) } },
            dismissButton = { TextButton(onClick = { renameNode = null }) { Text("Cancel") } }
        )

        if (answerNode != null) AlertDialog(
            onDismissRequest = { answerNode = null },
            title = { Text("Edit reply") },
            text = { Field(answerText, { answerText = it }, "Reply", single = false) },
            confirmButton = { TextButton(onClick = { answerNode?.let { botCategories.updateAnswer(it.id, answerText) }; answerNode = null; categoriesVersion++ }) { Text("Save", color = J.Red) } },
            dismissButton = { TextButton(onClick = { answerNode = null }) { Text("Cancel") } }
        )
    }
}

/**
 * Screen 8 of reference UI: XML Template Example
 */
@Composable
fun XmlTemplateExampleScreen(onBack: () -> Unit) = Page("XML Template Example", onBack) {
    val p = LocalPal.current
    val sampleXml = """
1  <?xml version="1.0" encoding="UTF-8"?>
2  <juliet>
3    <categories>
4      <category name="Banking">
5        <subcategories>
6          <subcategory name="Account Services">
7            <options>
8              <option name="Balance Inquiry">
9                <reply>
10                 To check your balance...
11               </reply>
12             </option>
13           </options>
14         </subcategory>
15       </subcategories>
16     </category>
17   </categories>
18 </juliet>
    """.trimIndent()

    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Color(0xFF09040A)).border(1.dp, p.border, RoundedCornerShape(22.dp)).padding(16.dp)
    ) {
        Text(sampleXml, color = Color(0xFFFF80AB), fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 17.sp)
    }

    Spacer(Modifier.height(16.dp))
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(p.card).border(1.dp, p.border, RoundedCornerShape(18.dp)).padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.size(28.dp).clip(CircleShape).background(J.Red), Alignment.Center) {
                Text("i", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            Text(
                "You can create your own XML file using this template. Then upload it in the app to add your custom categories and replies.",
                color = p.text,
                fontSize = 13.sp,
                lineHeight = 18.sp
            )
        }
    }
}

private val APPS = listOf(
    "📧" to ("Gmail" to "com.google.android.gm"),
    "📅" to ("Calendar" to "com.google.android.calendar"),
    "✈️" to ("Telegram" to "org.telegram.messenger"),
    "📷" to ("Instagram" to "com.instagram.android"),
    "📘" to ("Facebook" to "com.facebook.katana")
)

@Composable
fun AnnounceScreen(vm: JulietViewModel, askPerm: (String, (Boolean) -> Unit) -> Unit) = Page("Voice announcements", { vm.back() }) {
    val p = LocalPal.current
    val ctx = LocalContext.current
    var excl by remember { mutableStateOf(vm.s("ann_excl")) }
    val isPaused = Announcer.isPaused

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.permTick++ }
    val tick = vm.permTick
    val listenerOn = remember(tick) { NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName) }
    fun granted(perm: String) = ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED
    val callsReady = granted(Manifest.permission.READ_PHONE_STATE) && granted(Manifest.permission.READ_CALL_LOG) && granted(Manifest.permission.READ_CONTACTS)
    val vol = (vm.s("ann_vol").toIntOrNull() ?: 100) / 100f
    fun flag(k: String) = vm.s(k) == "1"

    Sub("Juliet speaks out loud when someone calls or sends you a message.")

    Box(
        Modifier.fillMaxWidth().padding(bottom = 14.dp).clip(RoundedCornerShape(22.dp))
            .background(p.card).border(1.dp, p.border, RoundedCornerShape(22.dp)).padding(16.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("Voice Announcement Engine", color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(if (isPaused) "PAUSED ⏸" else if (flag("ann_on")) "ACTIVE 🔊" else "DISABLED ○", color = if (isPaused) J.Gold else if (flag("ann_on")) J.Ok else p.mu, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Switch(
                    checked = flag("ann_on"),
                    onCheckedChange = { vm.set("ann_on", if (it) "1" else "0") },
                    colors = SwitchDefaults.colors(checkedTrackColor = J.Ok, checkedThumbColor = Color.White)
                )
            }
            Text(
                "• Voice: Juliet's own voice (same as voice chat; change it in Voice & language)\n" +
                    "• Privacy Guard: OTPs, Passwords & Banking codes are hidden automatically ✔\n" +
                    "• Current State: ${if (isPaused) "Paused ⏸" else if (flag("ann_on")) "Active 🔊" else "Disabled ○"}",
                color = p.mu, fontSize = 13.sp, lineHeight = 18.sp
            )
        }
    }

    Group {
        ToggleItem("📞", "Announce Incoming Calls", "Speaks the saved contact name", flag("ann_calls")) { vm.set("ann_calls", if (it) "1" else "0") }
        ToggleItem("💬", "Announce WhatsApp Messages", "Sender name and message", flag("ann_wa")) { vm.set("ann_wa", if (it) "1" else "0") }
        ToggleItem("✉", "Announce SMS Messages", "Sender name only", flag("ann_sms")) { vm.set("ann_sms", if (it) "1" else "0") }
        ToggleItem("🔔", "Announce App Notifications", "Only the apps you select below", flag("ann_apps")) { vm.set("ann_apps", if (it) "1" else "0") }
        ToggleItem("📖", "Read Message Content", "Only works when Privacy Mode is off", flag("ann_content")) { vm.set("ann_content", if (it) "1" else "0") }
        ToggleItem("🛡", "Privacy Mode", "Never reads message text aloud", flag("ann_privacy")) { vm.set("ann_privacy", if (it) "1" else "0") }
        ToggleItem("🌙", "Quiet Hours (10 PM - 7 AM)", "Silences voice announcements at night", flag("ann_quiet_hours")) { vm.set("ann_quiet_hours", if (it) "1" else "0") }
        ToggleItem("🔁", "Repeat Announcement", "Says it once more after 15 seconds", flag("ann_repeat")) { vm.set("ann_repeat", if (it) "1" else "0") }
        Item("🔊", "Announcement Volume", vm.s("ann_vol") + "%") { vm.cycle("ann_vol", listOf("100", "80", "60", "40")) }
    }

    Sec("CONTROLS & PLAYBACK")
    Group {
        Item("▶", "Test Juliet Announcement", "Plays a sample now in Juliet's voice") {
            val why = Announcer.speak(ctx, "Assalam o Alaikum, main Juliet hoon. Ab main aap ki notifications isi awaz mein announce karungi.", vol, force = true)
            if (why != null) vm.toast = "Not spoken: $why"
        }
        if (!isPaused) {
            Item("⏸", "Pause Announcements", "Temporarily pause all voice alerts") {
                Announcer.pause()
                vm.toast = "Voice announcements paused"
            }
        } else {
            Item("▶", "Resume Announcements", "Resume spoken voice announcements") {
                Announcer.resume()
                vm.toast = "Voice announcements resumed"
            }
        }
        Item("⏹", "Stop Announcement", "Stops current speech playback immediately") {
            Announcer.stop()
        }
    }

    Sec("SELECT APPS")
    Group {
        val sel = vm.s("ann_pkgs").split(",").filter { it.isNotBlank() }.toSet()
        APPS.forEach { (icon, a) ->
            ToggleItem(icon, a.first, "", a.second in sel) { on -> vm.set("ann_pkgs", (if (on) sel + a.second else sel - a.second).joinToString(",")) }
        }
    }

    Sec("EXCLUDED CONTACTS")
    Field(excl, { excl = it }, "Names separated by commas")
    GradientButton("Save excluded contacts", Modifier.fillMaxWidth()) { vm.set("ann_excl", excl); vm.toast = "Saved" }

    Spacer(Modifier.height(16.dp))
    Sec("PERMISSIONS")
    Group {
        Item("🔔", "Notification access", if (listenerOn) "Allowed ✔" else "Needed for message and app announcements. Tap to allow.") { openListenerSettings(ctx) }
        Item("📞", "Call announcements", if (callsReady) "Allowed ✔" else "Needs Phone, Call log and Contacts permission. Tap to allow.") {
            askPerm(Manifest.permission.READ_PHONE_STATE) {
                askPerm(Manifest.permission.READ_CALL_LOG) { askPerm(Manifest.permission.READ_CONTACTS) { vm.permTick++ } }
            }
        }
    }
}
