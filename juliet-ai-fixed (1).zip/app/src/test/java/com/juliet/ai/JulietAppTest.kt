package com.juliet.ai

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.juliet.ai.ann.Announcer
import com.juliet.ai.data.Prefs
import com.juliet.ai.phone.ContactNames
import com.juliet.ai.reminders.ReminderManager
import com.juliet.ai.screen.JulietAccessibilityService
import com.juliet.ai.wa.AutoReply
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class JulietAppTest {

    @Test
    fun testLooksLikeNumber() {
        assertTrue(ContactNames.looksLikeNumber("+923001234567"))
        assertTrue(ContactNames.looksLikeNumber("03001234567"))
        assertTrue(ContactNames.looksLikeNumber("12345678"))
        assertFalse(ContactNames.looksLikeNumber("Ahsan"))
        assertFalse(ContactNames.looksLikeNumber("Ammi"))
        assertFalse(ContactNames.looksLikeNumber("Client Contact"))
    }

    @Test
    fun testGreetingRegex() {
        val greet = Regex("(?i)(\\bhi\\b|\\bhello\\b|\\bhey\\b|good morning|good evening|good afternoon|assalam\\w*(\\s*o?\\s*alaikum)?|a?salam\\s*o\\s*alaikum|aslam\\s*o\\s*alaikum|salaam|salam|\\baoa\\b|a\\.o\\.a|السلام\\s*علیکم|السلام\\s*عليكم|سلام)")
        assertTrue(greet.containsMatchIn("Hi"))
        assertTrue(greet.containsMatchIn("Hello"))
        assertTrue(greet.containsMatchIn("Assalamualaikum"))
        assertTrue(greet.containsMatchIn("Aslam o Alaikum"))
        assertTrue(greet.containsMatchIn("AOA kaise ho?"))
        assertTrue(greet.containsMatchIn("Salam"))
        assertTrue(greet.containsMatchIn("السلام علیکم"))
    }

    @Test
    fun testHandoverPhrases() {
        val romanUrduHandover = "Please wait karein, owner khud aapko jawab dein ge."
        val englishHandover = "Please wait, the owner will respond to you shortly."

        assertTrue(romanUrduHandover.isNotBlank())
        assertEquals("Please wait, the owner will respond to you shortly.", englishHandover)
    }

    @Test
    fun testReminderParsing() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val prefs = Prefs(ctx)
        val manager = ReminderManager(ctx, prefs)

        val reminder1 = manager.parseNaturalLanguageReminder("remind me to call Mom tomorrow at 2 PM")
        assertNotNull(reminder1)
        assertTrue(reminder1!!.title.contains("Call Mom", ignoreCase = true))
        assertTrue(reminder1.dueTimeMillis > System.currentTimeMillis())

        val reminder2 = manager.parseNaturalLanguageReminder("remind me in 30 minutes to take medicine")
        assertNotNull(reminder2)
        assertTrue(reminder2!!.title.contains("medicine", ignoreCase = true))
        assertTrue(reminder2.dueTimeMillis > System.currentTimeMillis())
    }

    @Test
    fun testProactiveReminderDetection() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val prefs = Prefs(ctx)
        val manager = ReminderManager(ctx, prefs)

        val proactive = manager.detectProactiveReminder("I need to submit the project assignment tomorrow")
        assertNotNull(proactive)
        assertTrue(proactive!!.suggestedFromContext)
        assertTrue(proactive.title.contains("submit", ignoreCase = true))
    }

    @Test
    fun testBotCategoriesAndAutoReplyMenu() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val prefs = Prefs(ctx)
        val categories = com.juliet.ai.data.BotCategories(prefs)

        // Clear existing categories for test isolation
        categories.all().forEach { categories.delete(it.id) }

        val xmlData = """
            <?xml version="1.0" encoding="UTF-8"?>
            <bot>
                <category name="Banking">
                    <subcategory name="Cards">
                        <option name="Debit Card" answer="Please tell me what help you need with your debit card." />
                    </subcategory>
                </category>
                <category name="Education">
                    <subcategory name="Admissions">
                        <option name="Admission Details" answer="Please share the course name you are interested in." />
                    </subcategory>
                </category>
            </bot>
        """.trimIndent()

        val importedCount = categories.importXml(java.io.ByteArrayInputStream(xmlData.toByteArray()))
        assertTrue(importedCount >= 4)

        val roots = categories.menu("")
        assertEquals(2, roots.size)
        assertTrue(roots.any { it.title == "Banking" })
        assertTrue(roots.any { it.title == "Education" })

        val banking = roots.first { it.title == "Banking" }
        val subcategories = categories.menu(banking.id)
        assertEquals(1, subcategories.size)
        assertEquals("Cards", subcategories.first().title)

        val cards = subcategories.first()
        val options = categories.menu(cards.id)
        assertEquals(1, options.size)
        assertEquals("Debit Card", options.first().title)
        assertEquals("Please tell me what help you need with your debit card.", options.first().answer)

        // Test AutoReply preview with menu navigation
        val autoReply = AutoReply(ctx, prefs)
        kotlinx.coroutines.runBlocking {
            // 1. Greeting returns main menu
            val replyGreeting = autoReply.preview("Customer1", "Hi")
            assertTrue(replyGreeting.contains("Assalam o Alaikum"))
            assertTrue(replyGreeting.contains("Banking"))
            assertTrue(replyGreeting.contains("Education"))

            // 2. Select option 1 (Banking)
            val replyBanking = autoReply.preview("Customer1", "1")
            assertTrue(replyBanking.contains("Cards"))

            // 3. Select option 1 (Cards)
            val replyCards = autoReply.preview("Customer1", "1")
            assertTrue(replyCards.contains("Debit Card"))

            // 4. Select option 1 (Debit Card) -> returns defined answer
            val replyAnswer = autoReply.preview("Customer1", "1")
            assertTrue(replyAnswer.contains("Please tell me what help you need with your debit card."))

            // 5. "menu" resets state to main menu
            val replyReset = autoReply.preview("Customer1", "menu")
            assertTrue(replyReset.contains("category select karein"))
            assertTrue(replyReset.contains("Banking"))
        }
    }

    @Test
    fun testDeviceControlRouting() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val actions = com.juliet.ai.phone.PhoneActions(ctx)

        // YouTube search routing
        val yt1 = actions.route("Atif Aslam ke songs search karo")
        assertNotNull(yt1)
        assertTrue(yt1!!.contains("YouTube", ignoreCase = true))

        val yt2 = actions.route("YouTube par latest songs search karo")
        assertNotNull(yt2)
        assertTrue(yt2!!.contains("YouTube", ignoreCase = true))

        // Media controls routing
        val mPlay = actions.route("Music play karo")
        assertNotNull(mPlay)

        val mPause = actions.route("Song pause karo")
        assertNotNull(mPause)

        val mNext = actions.route("Next song chalao")
        assertNotNull(mNext)

        val mPrev = actions.route("Previous song chalao")
        assertNotNull(mPrev)

        // Volume routing
        val vDown = actions.route("Volume kam karo")
        assertNotNull(vDown)

        val vUp = actions.route("Volume badhao")
        assertNotNull(vUp)

        // Flashlight routing
        val torch = actions.route("Torch on karo")
        assertNotNull(torch)

        // Navigation routing
        val home = actions.route("Home screen par jao")
        assertNotNull(home)

        val back = actions.route("Back jao")
        assertNotNull(back)

        val recents = actions.route("Recent apps kholo")
        assertNotNull(recents)
    }

    @Test
    fun testSensitiveCodeDetection() {
        assertTrue(Announcer.containsSensitiveCode("Your HBL bank OTP is 482910. Do not share."))
        assertTrue(Announcer.containsSensitiveCode("Use verification code 59281 to login to your account"))
        assertTrue(Announcer.containsSensitiveCode("Your security code is 8492"))
        assertTrue(Announcer.containsSensitiveCode("One time password: 382941"))
        assertFalse(Announcer.containsSensitiveCode("Hey Ahsan, are we meeting at 5 PM today?"))
        assertFalse(Announcer.containsSensitiveCode("I will call you in 10 minutes."))
    }

    @Test
    fun testConsequentialActionKeywords() {
        assertTrue(JulietAccessibilityService.CONSEQUENTIAL_KEYWORDS.containsMatchIn("Delete conversation"))
        assertTrue(JulietAccessibilityService.CONSEQUENTIAL_KEYWORDS.containsMatchIn("Confirm payment"))
        assertTrue(JulietAccessibilityService.CONSEQUENTIAL_KEYWORDS.containsMatchIn("Transfer money"))
        assertTrue(JulietAccessibilityService.CONSEQUENTIAL_KEYWORDS.containsMatchIn("Clear all data"))
        assertFalse(JulietAccessibilityService.CONSEQUENTIAL_KEYWORDS.containsMatchIn("Open settings"))
        assertFalse(JulietAccessibilityService.CONSEQUENTIAL_KEYWORDS.containsMatchIn("Next page"))
    }

    @Test
    fun testVoiceEnrollmentAndSpeakerVerification() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val prefs = Prefs(ctx)
        val manager = com.juliet.ai.voice.VoiceEnrollmentManager(ctx, prefs)

        // Synthetic "speech": 0.5 s voiced bursts separated by quiet gaps
        fun voice(f0: Double): ShortArray = ShortArray(48000) { i ->
            val burst = (i / 8000) % 2 == 0
            if (!burst) 0 else {
                val t = i / 16000.0
                var v = 0.0
                for (h in 1..8) v += Math.sin(2.0 * Math.PI * f0 * h * t) / h
                (v * 6000).toInt().toShort()
            }
        }
        val a = com.juliet.ai.voice.SpeakerDsp.embed(voice(120.0))
        val b = com.juliet.ai.voice.SpeakerDsp.embed(voice(210.0))
        assertNotNull(a); assertNotNull(b)
        assertEquals(com.juliet.ai.voice.VoiceEnrollmentManager.EMBEDDING_DIM, a!!.size)
        val (mean, spread) = com.juliet.ai.voice.SpeakerDsp.buildProfile(listOf(a, a.copyOf()))
        val dSelf = com.juliet.ai.voice.SpeakerDsp.distance(a, mean, spread)
        val dOther = com.juliet.ai.voice.SpeakerDsp.distance(b!!, mean, spread)
        assertTrue(dSelf < 0.01f)
        assertTrue(dOther > dSelf + 0.5f)

        val verification = manager.verifySpeaker(a.toList())
        assertNotNull(verification)
        assertTrue(verification.details.isNotBlank())
    }

    @Test
    fun testNaturalVoiceCommands() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val actions = com.juliet.ai.phone.PhoneActions(ctx)

        // "Juliet, volume kam kar do."
        val volDown = actions.route("volume kam kar do")
        assertNotNull(volDown)
        assertTrue(volDown!!.contains("volume", ignoreCase = true))

        // "Juliet, flashlight on kar do."
        val flashOn = actions.route("flashlight on kar do")
        assertNotNull(flashOn)
        assertTrue(flashOn!!.contains("torch", ignoreCase = true) || flashOn.contains("flash", ignoreCase = true))


        // "YouTube kholo aur Atif Aslam ka song chalao"
        val ytPlay = actions.route("YouTube kholo aur Atif Aslam ka song chalao")
        assertNotNull(ytPlay)
        assertTrue(ytPlay!!.contains("YouTube", ignoreCase = true))

        // "agla video chalao"
        val nextMedia = actions.route("agla video chalao")
        assertNotNull(nextMedia)

        // "back jao"
        val back = actions.route("back jao")
        assertNotNull(back)

        // "mujhe batao mere saamne kaunsa option hai"
        val focused = actions.route("mujhe batao mere saamne kaunsa option hai")
        assertNotNull(focused)
    }
}



