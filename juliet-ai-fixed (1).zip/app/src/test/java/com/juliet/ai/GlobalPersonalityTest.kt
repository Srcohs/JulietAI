package com.juliet.ai

import com.juliet.ai.persona.GlobalPersonality
import com.juliet.ai.persona.GlobalPersonality.Trigger
import org.junit.Assert.*
import org.junit.Test

class GlobalPersonalityTest {
    private fun settings(vararg kv: Pair<String, String>): (String) -> String {
        val m = mapOf("personality" to "Normal", "name" to "Ahsan Raza", "jealousy_level" to "Medium").plus(kv)
        return { k -> m[k] ?: "" }
    }

    @Test fun informationalMentionDoesNotTrigger() {
        assertEquals(Trigger.None, GlobalPersonality.analyse("ChatGPT kya hota hai?").trigger)
        assertEquals(Trigger.None, GlobalPersonality.analyse("Gemini api key kaise banate hain").trigger)
    }
    @Test fun personalSituationsTrigger() {
        assertEquals(Trigger.Comparison, GlobalPersonality.analyse("ChatGPT tumse zyada intelligent hai").trigger)
        assertEquals(Trigger.Testing, GlobalPersonality.analyse("Main Gemini test kar raha tha").trigger)
        assertEquals(Trigger.PraiseOther, GlobalPersonality.analyse("Gemini ne mera kaam achha kiya").trigger)
        assertEquals(Trigger.Switching, GlobalPersonality.analyse("I will switch to Claude").trigger)
    }
    @Test fun seriousOrTechnicalSuppressesJealousy() {
        val s = GlobalPersonality.analyse("ChatGPT se code error fix karwana hai")
        assertTrue(s.serious); assertEquals(Trigger.None, s.trigger)
    }
    @Test fun jealousyIsGlobalInEveryMode() {
        for (m in listOf("Normal", "Friendly", "Playful", "Calm", "Professional", "GF Mood", "SomeFutureMode")) {
            val b = GlobalPersonality.block(settings("personality" to m, "jealousy_on" to "1"), "Main Gemini test kar raha tha")
            assertTrue(m, b.contains("jealousy now"))
        }
    }
    @Test fun professionalNeverFlirts() {
        val b = GlobalPersonality.block(settings("personality" to "Professional", "flirt_on" to "1"), "hello")
        assertTrue(b.contains("Do not flirt"))
    }
    @Test fun jealousyOffAndEmotionsOffAreHonoured() {
        assertFalse(GlobalPersonality.block(settings("jealousy_on" to "0"), "Gemini test kar raha tha").contains("jealousy now"))
        assertTrue(GlobalPersonality.block(settings("emotions_on" to "0"), "x").contains("EMOTIONAL EXPRESSION IS OFF"))
    }
    @Test fun longBreakIsNoticed() {
        assertTrue(GlobalPersonality.analyse("hi", 400).returnedAfterBreak)
    }
}
